# Ground-turn visual audit

**PASS** - independent visual audit of the native hips/spine ground-turn batching change. The auditor made none of the implementation changes. Default was FAIL until all required visual evidence was available and inspected.

Read the whole candidate `ART_STYLE.md`, including dated scoped exceptions; inspected `scripts/humanoid_ground_turn_native.gd` and the `scripts/presentation.ts` diff against `fd67ee8f5` only to establish visual scope. This is a visual-equivalence/style judgment, not a code review.

Personally inspected all four actual PNGs through `view_image`:

- Baseline `../perf-enemy-brains-20261020/artifacts/ground-turn-before-r3-normal.png`
- Baseline `../perf-enemy-brains-20261020/artifacts/ground-turn-before-r3-ads.png`
- Candidate `artifacts/ground-turn-after-r1-normal.png`
- Candidate `artifacts/ground-turn-after-r1-ads.png`

Both capture receipts report PASS, 65 living enemies in both views, matching camera position `[-404, -15.6004991531372, -414]`, FOVs 75 and 32, and matching fixed-camera scenario coordinates/yaw/pitch. The candidate receipt arrived within the allowed wait.

At play distance, the candidate retains coherent hips/torso alignment, bent-leg and foot poses, readable soldier silhouettes, and believable chest-level weapon/hand alignment. I see no new twisted limbs, detached body parts, conspicuous ground penetration, or weapon/body clipping relative to baseline. Clothing, skin, equipment colours/materials, scene lighting and faceted environment presentation remain visually consistent. Crowd locations, individual pose phases, one muzzle flash, timer and chat differ between captures; these are distinct gameplay moments and do not show an appearance regression from this change.

Supporting evidence `artifacts/native-ground-turn-equivalence/result.json` reports PASS for 360 poses and 177120 global bone component comparisons, maxDelta 0. This supports the visual result but did not replace inspection of any screenshot.

Limitations: stills cannot establish motion cadence, temporal foot sliding, or every possible turn state. PASS is scoped to visible pose/style equivalence in the supplied normal and ADS captures, with the pose-equivalence receipt as additional support. No Godot, GPU hold, build, test, source edit, or other agent was started by this auditor.
