import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { writeFileSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);
const {enemyAimJobs}=require('../.godot/GodotJS/scripts/enemy_aim_catalog.js');
const execute=promisify(execFile), cli='tools/godot-cli/dist/src/index.js', instance='perf-enemy-aim-numeric';
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function call(args){const{stdout}=await execute(process.execPath,[cli,...args,'--project','.','--session','perf-enemy-aim-numeric-20261020','--json'],{windowsHide:true,timeout:90000,maxBuffer:20e6});const r=JSON.parse(stdout);if(!r.ok)throw Error(r.message);return r.data;}
let launch;
try{
 launch=await call(['game','run','--instance',instance,'--headless','--scene','res://tests/fixtures/enemy_aim_review.tscn','--inspect','--allow-actions']);
 await sleep(5000);
 const rows=[];
 for(const {kind,scene} of enemyAimJobs().filter(job=>!process.env.GODMODE_AIM_PROBE_FILTER||job.kind===process.env.GODMODE_AIM_PROBE_FILTER).slice(0,Number(process.env.GODMODE_AIM_PROBE_LIMIT)||999))
  for(const pitch of [-1.2,-Math.PI/4,-17.5*Math.PI/180,0,2.5*Math.PI/180,Math.PI/4,47.5*Math.PI/180,1.2])
   for(const action of ['aim','shoot','walk','sprint','crouch']){
    await call(['runtime','action','--instance',instance,'--name','enemy_aim_review','--payload',JSON.stringify({kind,scene,pitch,shooting:action==='shoot',walking:action==='walk',sprinting:action==='sprint',crouching:action==='crouch'})]);
    await sleep(80);
    const {store}=await call(['runtime','inspect','--instance',instance,'--store-only']);
    rows.push({kind,scene,pitch,action,...store});
    if(action==='sprint'&&!String(store.clip).includes('Sprint'))throw Error('Fixture did not enter the actual sprint clip');
    if(action==='crouch'&&!String(store.clip).includes('Crouch'))throw Error('Fixture did not enter the actual crouch clip');
    writeFileSync('artifacts/aim-residuals.json',JSON.stringify(rows,null,2));
   }
 writeFileSync('artifacts/aim-probe-engine.log',readFileSync(launch.logPath));
 const contact=rows.filter(r=>!(r.kind==='shotgun'&&r.action==='shoot'));
 const worstLeft=contact.reduce((a,b)=>(b.residuals?.Left||0)>(a.residuals?.Left||0)?b:a,contact[0]);
 const worstRight=rows.reduce((a,b)=>(b.residuals?.Right||0)>(a.residuals?.Right||0)?b:a,rows[0]);
 const summary={cases:rows.length,inactive:rows.filter(r=>!r.bakedAimActive).length,worstLeft,worstRight,maxShield:Math.max(...rows.map(r=>r.residuals?.Shield||0)),maxBoreError:Math.max(...rows.filter(r=>r.action!=='shoot'&&r.borePitch!==null).map(r=>Math.abs(r.borePitch-r.pitch))),errors:/SCRIPT ERROR|GODMODE_FRAME_ERROR|Parse Error/.test(readFileSync(launch.logPath,'utf8'))};
 writeFileSync('artifacts/aim-contact-summary.json',JSON.stringify(summary,null,2));
 if(summary.errors||summary.inactive||summary.maxBoreError>0.04||(worstLeft.residuals?.Left||0)>0.005||(worstRight.residuals?.Right||0)>0.0001||summary.maxShield>0.0001)throw Error('Baked native contact/direction gate failed; see artifacts/aim-contact-summary.json');
 console.log(JSON.stringify(rows.map(r=>({kind:r.kind,pitch:r.pitch,action:r.action,residuals:r.residuals})),null,2));
}catch(e){console.error(e.stdout?.slice(0,1200)??e.message);process.exitCode=1;}
finally{if(launch)await call(['game','stop','--instance',instance]);}
