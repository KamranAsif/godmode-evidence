import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { readFileSync, writeFileSync } from 'node:fs';
const execute=promisify(execFile), instance='perf-enemy-aim-specials', cli='tools/godot-cli/dist/src/index.js';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function call(args){const{stdout}=await execute(process.execPath,[cli,...args,'--project','.','--session','perf-enemy-aim-specials-20261020','--json'],{windowsHide:true,timeout:90000,maxBuffer:10e6});const r=JSON.parse(stdout);if(!r.ok)throw Error(r.message);return r.data;}
const action=(name,payload)=>call(['runtime','action','--instance',instance,'--name',name,'--payload',JSON.stringify(payload)]);
const inspect=async()=> (await call(['runtime','inspect','--instance',instance,'--store-only'])).store;
let launch;
try{
 launch=await call(['game','run','--headless','--instance',instance,'--scene','res://tests/fixtures/enemy_aim_review.tscn','--inspect','--allow-actions']);
 await sleep(5000);
 await action('enemy_aim_review',{kind:'officer'});
 await sleep(300);
 const rows=[];
 for(const special of ['radio','none','stun','none','air','none','cover','none']){
  await action('enemy_aim_special',{special}); await sleep(800);
  const state=await inspect(); rows.push(state);
  if(['radio','stun','air'].includes(special)&&state.bakedAimActive)throw Error(`Baked layer stole ${special} ownership`);
  if(special==='radio'&&!String(state.mountHand).endsWith('LeftHand'))throw Error('Radio did not retain left-hand carry');
  if(special==='none'&&(!state.bakedAimActive||!String(state.mountHand).endsWith('RightHand')||Object.values(state.residuals).some(v=>v>0.005)))throw Error('Ordinary baked grip did not recover after special');
 }
 for(const kind of ['minigun','cloaker']){
  await action('enemy_aim_review',{kind}); await sleep(300);
  const state=await inspect(); rows.push(state);
  if(state.bakedAimActive)throw Error(`${kind} unexpectedly entered baked gun path`);
 }
 const log=readFileSync(launch.logPath,'utf8');
 if(/SCRIPT ERROR|GODMODE_FRAME_ERROR|Parse Error/.test(log))throw Error('Native special smoke logged script errors');
 writeFileSync('artifacts/aim-specials-engine.log',log);
 writeFileSync('artifacts/aim-specials.json',JSON.stringify({passed:true,rows},null,2));
 console.log('Native special ownership/recovery PASS: radio, stun gate, air, cover cleanup, rotary, melee');
}catch(e){console.error(e.stdout?.slice(0,1200)??e.message);process.exitCode=1;}
finally{if(launch)await call(['game','stop','--instance',instance]);}
