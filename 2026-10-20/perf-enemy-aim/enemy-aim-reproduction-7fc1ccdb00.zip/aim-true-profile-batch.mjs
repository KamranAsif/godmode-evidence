import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
const execute=promisify(execFile), root=process.cwd(), baseline='D:/work/godmode-roguelite-worktrees/perf-enemy-aim-baseline';
const env={...process.env,GODMODE_AIM_CPU_GATE:root+'/artifacts'};
try{
 for(const [cwd,label,args] of [[baseline,'before-verified-uninstrumented',['--uninstrumented']],[root,'after-verified-uninstrumented',['--uninstrumented']],[baseline,'before-verified-uninstrumented-bracket',['--uninstrumented']]]){
  console.log('START',label,new Date().toISOString());
  const r=await execute(process.execPath,['artifacts/enemy-profile.mjs',label,...args],{cwd,env,windowsHide:true,maxBuffer:16e6});
  console.log(r.stdout);console.error(r.stderr);console.log('DONE',label,new Date().toISOString());
 }
}catch(e){console.error(e.stdout?.slice(-4000)??e.message);console.error(e.stderr?.slice(-3000)??'');process.exitCode=1;}
finally{const r=await execute(process.execPath,['tools/godot-cli/dist/src/index.js','session','end','--session',env.GODMODE_SESSION_ID,'--project',root,'--json'],{windowsHide:true,maxBuffer:4e6});console.log(r.stdout);}
