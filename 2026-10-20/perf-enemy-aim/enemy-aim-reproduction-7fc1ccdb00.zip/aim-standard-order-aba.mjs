import{execFile}from'node:child_process';import{promisify}from'node:util';import{writeFileSync,mkdirSync}from'node:fs';import path from'node:path';
const execute=promisify(execFile),root=process.cwd(),baseline='D:/work/godmode-roguelite-worktrees/perf-enemy-aim-baseline';mkdirSync('artifacts/performance',{recursive:true});
try{
 for(const [project,label]of [[baseline,'before-1'],[root,'after-1'],[baseline,'before-2']]){
  console.log('START standard',label,new Date().toISOString());
  const r=await execute(process.execPath,['tools/performance/gameplay-benchmark.mjs','run','--project',project,'--enemies','24','--taa','off','--resolution','1440p','--subset','shopping-street,firefight','--output',`artifacts/performance/standard-order-${label}.json`],{cwd:root,env:process.env,windowsHide:true,maxBuffer:32e6});
  writeFileSync(`artifacts/performance/standard-order-${label}.driver.log`,r.stdout+'\n'+r.stderr);console.log(r.stdout.slice(-1500));console.error(r.stderr.slice(-1500));console.log('DONE standard',label,new Date().toISOString());
 }
}catch(e){console.error(e.stdout?.slice(-5000)??e.message);console.error(e.stderr?.slice(-3000)??'');process.exitCode=1;}
finally{const r=await execute(process.execPath,['tools/godot-cli/dist/src/index.js','session','end','--session',process.env.GODMODE_SESSION_ID,'--project',root,'--json'],{windowsHide:true,maxBuffer:4e6});console.log(r.stdout);}
