import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { writeFileSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);
const {enemyAimJobs}=require('../.godot/GodotJS/scripts/enemy_aim_catalog.js');
const execute=promisify(execFile), cli='tools/godot-cli/dist/src/index.js', instance='perf-enemy-aim-numeric-auto';
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function call(args){const{stdout}=await execute(process.execPath,[cli,...args,'--project','.','--session','perf-enemy-aim-automatic-cpu-20261020','--json'],{windowsHide:true,timeout:90000,maxBuffer:20e6});const r=JSON.parse(stdout);if(!r.ok)throw Error(r.message);return r.data;}
let launch;
try{
 launch=await call(['game','run','--instance',instance,'--headless','--scene','res://tests/fixtures/enemy_aim_review.tscn','--inspect','--allow-actions']);
 await sleep(5000);
 const rows=[];
 for(const {kind,scene} of enemyAimJobs().filter(job=>!process.env.GODMODE_AIM_PROBE_FILTER||job.kind===process.env.GODMODE_AIM_PROBE_FILTER).slice(0,Number(process.env.GODMODE_AIM_PROBE_LIMIT)||999))
  for(const pitch of (process.env.GODMODE_AIM_PROBE_PITCHES?JSON.parse(process.env.GODMODE_AIM_PROBE_PITCHES):[-1.2,-Math.PI/4,-17.5*Math.PI/180,0,2.5*Math.PI/180,Math.PI/4,47.5*Math.PI/180,1.2]))
   for(const action of (process.env.GODMODE_AIM_PROBE_ACTIONS||'aim,shoot,walk,sprint,crouch').split(',')){
    const requested={kind,scene,pitch,automatic:true,shooting:action.includes('shoot'),walking:action.includes('walk'),sprinting:action.includes('sprint'),crouching:action==='crouch',airPhase:action==='air'?'loop':action==='land'?'land':''};
    await call(['runtime','action','--instance',instance,'--name','enemy_aim_review','--payload',JSON.stringify(requested)]);
    await sleep(true?1000:80);
    const {store}=await call(['runtime','inspect','--instance',instance,'--store-only']);
    writeFileSync('artifacts/aim-auto-last-inspection.json',JSON.stringify({requested,action,...store},null,2));
    for(const key of Object.keys(requested)){
      if(key==='pitch'?Math.abs(store[key]-requested[key])>1e-10:store[key]!==requested[key])throw Error(`Stale fixture state ${key}: requested ${requested[key]}, got ${store[key]}`);
    }
    const native=store.grips?.grips?.[0]?.nativeBaked;
    if(!native?.active||!native.enabled||!native.state||native.state!==native.clip)throw Error('Upper native state inactive or mismatched');
    if(true&&(native.callback!==1||native.sourceCallback!==1||(native.rate<=0&&action!=='land')))throw Error('Automatic playback is not active');
    if(['air','land'].includes(action)&&!String(store.clip).includes('Jump'+(action==='land'?'Land':'Loop')))throw Error('Armed air clip missing');
    if(action==='sprint'&&!String(store.clip).includes('Sprint'))throw Error('Fixture did not enter the actual sprint clip');
    if(action==='crouch'&&!String(store.clip).includes('Crouch'))throw Error('Fixture did not enter the actual crouch clip');
    if(action.includes('walk')&&!String(store.clip).includes('Walk'))throw Error('Fixture did not enter the actual walk clip');
    if(action.includes('walk')&&!String(native.clip).includes('Walk'))throw Error('Upper native pose did not retain the gait');
    rows.push({requested,action,...store});
    writeFileSync('artifacts/aim-auto-residuals.json',JSON.stringify(rows,null,2));
   }
 writeFileSync('artifacts/aim-auto-engine.log',readFileSync(launch.logPath));
 const contact=rows.filter(r=>!(r.kind==='shotgun'&&r.action==='shoot'));
 const worstLeft=contact.reduce((a,b)=>(b.residuals?.Left||0)>(a.residuals?.Left||0)?b:a,contact[0]);
 const worstRight=rows.reduce((a,b)=>(b.residuals?.Right||0)>(a.residuals?.Right||0)?b:a,rows[0]);
 const summary={requestedIdentityValidated:true,automatic:true,cases:rows.length,inactive:rows.filter(r=>!r.bakedAimActive).length,worstLeft,worstRight,maxShield:Math.max(...rows.map(r=>r.residuals?.Shield||0)),maxBoreError:Math.max(...rows.filter(r=>!r.action.startsWith('walk-')&&(!r.action.includes('shoot')||!['shotgun','rifle'].includes(r.kind))&&r.borePitch!==null).map(r=>Math.abs(r.borePitch-r.pitch))),maxMovingShotBoreError:Math.max(0,...rows.filter(r=>r.action==='walk-shoot'&&r.borePitch!==null).map(r=>Math.abs(r.borePitch-(r.grips?.grips?.[0]?.aimPitchRadians??r.pitch)))),errors:/SCRIPT ERROR|GODMODE_FRAME_ERROR|Parse Error/.test(readFileSync(launch.logPath,'utf8'))};
 writeFileSync('artifacts/aim-auto-contact-summary.json',JSON.stringify(summary,null,2));
 if(summary.errors||summary.inactive||summary.maxBoreError>0.04||summary.maxMovingShotBoreError>0.07||(worstLeft.residuals?.Left||0)>0.005||(worstRight.residuals?.Right||0)>0.0001||summary.maxShield>0.0001)throw Error('Baked native contact/direction gate failed; see artifacts/aim-auto-contact-summary.json');
 console.log(JSON.stringify(rows.map(r=>({kind:r.kind,pitch:r.pitch,action:r.action,residuals:r.residuals})),null,2));
}catch(e){console.error(e.stdout?.slice(0,1200)??e.message);process.exitCode=1;}
finally{if(launch)await call(['game','stop','--instance',instance]);}
