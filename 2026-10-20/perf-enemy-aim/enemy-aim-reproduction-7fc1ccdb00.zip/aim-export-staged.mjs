import {execFile,spawnSync}from'node:child_process';import{promisify}from'node:util';import{writeFileSync}from'node:fs';import path from'node:path';
const execute=promisify(execFile),root=process.cwd(),session='perf-enemy-aim-export-staged-final-20261020',cli=path.resolve('tools/godot-cli/dist/src/index.js');
process.env.GODMODE_SESSION_ID=session;process.env.GODMODE_PREBUILT_PUBLISH='0';
const{findGodot,exportGame,endSession}=await import('../tools/godot-cli/dist/src/cli.js');
let held=false;
try{
 const result=await exportGame(root,await findGodot(),{preset:'Windows Playtest',output:'artifacts/playtest/BattleDuty.exe'},message=>{
  process.stdout.write(message);
  if(message.startsWith('[export] ')&&!held){
   for(const [name,args]of [['gpu-before-staged-export',['gpu','status']],['processes-before-staged-export',['game','ps','--all']]]){
    const r=spawnSync(process.execPath,[cli,...args,'--project',root,'--session',session,'--json'],{windowsHide:true,encoding:'utf8'});if(r.status!==0)throw Error(r.stderr||r.stdout);writeFileSync(`artifacts/${name}.json`,r.stdout);
   }
   const r=spawnSync(process.execPath,[cli,'gpu','hold','--project',root,'--session',session,'--mode','capture','--ttl','6m','--timeout-ms','3600000','--reason','perf-enemy-aim-421 final Windows shader packaging and normal Playtest check; CPU preparation complete;6min'],{windowsHide:true,encoding:'utf8',stdio:['ignore','pipe','inherit'],maxBuffer:4e6});if(r.status!==0)throw Error(r.stdout||'GPU hold failed');process.stdout.write(r.stdout);held=true;
  }
 });
 writeFileSync('artifacts/playtest-export-native-receipt.json',JSON.stringify(result,null,2));if(!result.ok)throw Error(result.message);
 const checked=await execute(process.execPath,['artifacts/aim-playtest-check.mjs'],{windowsHide:true,maxBuffer:16e6,env:process.env});console.log(checked.stdout);console.error(checked.stderr);
}catch(e){console.error(e.stdout?.slice(-4000)??e.stack??e.message);console.error(e.stderr?.slice(-2000)??'');process.exitCode=1;}
finally{console.log(JSON.stringify(await endSession(session)));}
