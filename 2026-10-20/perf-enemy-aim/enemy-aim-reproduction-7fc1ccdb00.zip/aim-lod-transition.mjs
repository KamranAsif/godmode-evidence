import{execFile}from'node:child_process';import{promisify}from'node:util';import{writeFileSync,readFileSync}from'node:fs';
const run=promisify(execFile),cli='tools/godot-cli/dist/src/index.js',instance='perf-enemy-aim-lod-transition',session='perf-enemy-aim-lod-transition-cpu-20261020',rows=[];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));let launch;
async function call(args){const{stdout}=await run(process.execPath,[cli,...args,'--session',session,'--project','.','--json'],{windowsHide:true,maxBuffer:20e6,timeout:90000});const r=JSON.parse(stdout);if(!r.ok)throw Error(r.message);return r.data;}
try{
 launch=await call(['game','run','--instance',instance,'--headless','--scene','res://tests/fixtures/enemy_aim_review.tscn','--inspect','--allow-actions']);await sleep(1500);
 for(const config of [{kind:'rifle',pitch:.6,walking:true,shooting:true},{kind:'rifle',pitch:-.6,airPhase:'loop'},{kind:'marksman',scene:'res://assets/characters/stream-snipers/character-stream-sniper-marksman-a.glb',pitch:.6,sprinting:true}]){
  await call(['runtime','action','--instance',instance,'--name','enemy_aim_review','--payload',JSON.stringify({...config,automatic:true})]);await sleep(1000);
  for(let step=0;step<8;step++){
   const manual=step%2===0;
   await call(['runtime','action','--instance',instance,'--name','enemy_aim_callback','--payload',JSON.stringify({manual})]);await sleep(500);
   const {store}=await call(['runtime','inspect','--instance',instance,'--store-only']);const native=store.grips?.grips?.[0]?.nativeBaked;
   rows.push({config,step,...store});writeFileSync('artifacts/aim-lod-transition-results.json',JSON.stringify(rows,null,2));
   if(!store.automatic||store.lodManual!==manual||!native?.active||!native.enabled||native.state!==native.clip||native.state==='Start'||native.callback!==(manual?2:1)||native.sourceCallback!==(manual?2:1)||(store.residuals.Left??0)>.005||(store.residuals.Right??0)>.0001)throw Error('LOD callback transition lost native hold: '+JSON.stringify(rows.at(-1)));
  }
 }
 const log=readFileSync(launch.logPath,'utf8');writeFileSync('artifacts/aim-lod-transition-engine.log',log);if(/SCRIPT ERROR|GODMODE_FRAME_ERROR|Parse Error/.test(log))throw Error('Native LOD transition script error');
 writeFileSync('artifacts/aim-lod-transition-summary.json',JSON.stringify({passed:true,cases:rows.length,worstLeft:Math.max(...rows.map(r=>r.residuals.Left??0)),worstRight:Math.max(...rows.map(r=>r.residuals.Right??0)),configs:rows.filter(r=>r.step===0).map(r=>r.config)},null,2));console.log('PASS native manual/automatic callback transitions',rows.length);
}catch(e){console.error(e.stdout??e.message);process.exitCode=1;}finally{if(launch)console.log(await call(['game','stop','--instance',instance]));}
