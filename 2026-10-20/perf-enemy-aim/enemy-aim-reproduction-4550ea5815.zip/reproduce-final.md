All runs use the pinned engine and godot-cli. These scratch harnesses are evidence,
not runtime product code. Replace the absolute root and baseline paths for another
machine. Both worktrees need pnpm install, native imports, and compiled scripts.

65-enemy A/B/A: enemy-profile.mjs exists in both worktrees. Set GODMODE_SESSION_ID
to a unique perf-enemy-aim-* session. Set GODMODE_AIM_CPU_GATE to the root artifacts
directory containing the completed CPU logs. Check gpu status and game ps --all,
then execute aim-true-profile-batch.mjs under a godot-cli gpu hold --mode timing.
The batch sets --uninstrumented on all three runs. Each run waits 15 s then captures
two 8 s windows with runtime frames. Settings/manifests and original raw samples are
in enemy-aim-final-receipts.zip. No image capture or file processing runs during
these windows. The baseline is e6e64ec6c; the baked version is 878e6b852.

Standard A/B/A: run aim-standard-order-aba.mjs under its own exclusive timing hold.
The exact standard command is node tools/performance/gameplay-benchmark.mjs run
--project PROJECT --enemies 24 --taa off --resolution 1440p
--subset shopping-street,firefight --output OUTPUT. The actual argument arrays
in the harness contain separated option/value tokens. The main harness defaults
to 10000 ms warmup and forces instrumentation. Compare with the standard compare
subcommand; the two original comparison reports are included in the receipts ZIP.

Leaf attribution: aim-leaf-profile-batch.mjs calls enemy-profile.mjs without
--uninstrumented for both sides. Its unstable baseline is diagnostic only.

Native automatic proof: aim-probe-auto.mjs uses the enemy_aim_review fixture and
observes native evaluation without manually advancing poses. aim-lod-transition.mjs
checks the native idle/manual callback changes. Both are CPU headless checks.

Export: aim-export-staged.mjs uses godot-cli's public exportGame API. CPU preparation
precedes its GPU capture hold. The normal binary check has inspectionUrl:null;
the public receipt includes its SHA256 and 37.081 s active observation. The executable
and paid source assets are intentionally absent from this evidence archive.
