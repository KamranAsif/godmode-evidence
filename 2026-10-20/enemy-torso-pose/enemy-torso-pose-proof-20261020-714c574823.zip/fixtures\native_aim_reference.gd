# Frozen aim solver from origin/main 2b28eeab5; only the factory path differs.
# Keep quaternion/skeleton operations inside the engine; the aim grid stays in TypeScript.
extends RefCounted

var root: Node3D
var skeleton: Skeleton3D
var player: AnimationPlayer
var samples: Dictionary = {}
var hips: int
var spine: int

static func create(body: Node3D, rig: Skeleton3D, animations: AnimationPlayer) -> RefCounted:
	var state = load("res://tests/fixtures/native_aim_reference.gd").new()
	state.root = body
	state.skeleton = rig
	state.player = animations
	state.hips = rig.find_bone("mixamorig_Hips")
	state.spine = rig.find_bone("mixamorig_Spine")
	return state

# TypeScript owns clip choice, time, weight and the matched local-pose track order.
func blend_pose_tracks(clip_name: String, time: float, weight: float, tracks: PackedInt32Array) -> void:
	var clip := player.get_animation(clip_name)
	for index in range(0, tracks.size(), 3):
		var bone := tracks[index]
		var track := tracks[index + 1]
		if tracks[index + 2] == Animation.TYPE_ROTATION_3D:
			skeleton.set_bone_pose_rotation(bone, skeleton.get_bone_pose_rotation(bone).slerp(clip.rotation_track_interpolate(track, time), weight))
		else:
			skeleton.set_bone_pose_position(bone, skeleton.get_bone_pose_position(bone).lerp(clip.position_track_interpolate(track, time), weight))
	skeleton.force_update_all_bone_transforms()

func sample_clip(clip_name: String) -> Dictionary:
	if samples.has(clip_name):
		return samples[clip_name]
	var values: Dictionary = {}
	var clip = player.get_animation(clip_name)
	for track in clip.get_track_count():
		if clip.track_get_type(track) != Animation.TYPE_ROTATION_3D:
			continue
		var path = clip.track_get_path(track)
		if path.get_subname_count() == 0:
			continue
		var joint = path.get_subname(path.get_subname_count() - 1)
		if joint not in ["mixamorig_Hips", "mixamorig_Spine", "mixamorig_Spine1", "mixamorig_Spine2", "mixamorig_Neck", "mixamorig_Head"]:
			continue
		var bone = skeleton.find_bone(joint)
		if bone >= 0:
			values[bone] = clip.rotation_track_interpolate(track, 0)
	samples[clip_name] = values
	return values

func blended(bone: int, neutral: Dictionary, corners: Array, yaw_weight: float, pitch_weight: float) -> Variant:
	var a = corners[0].get(bone, neutral.get(bone))
	var b = corners[1].get(bone, neutral.get(bone))
	var c = corners[2].get(bone, neutral.get(bone))
	var d = corners[3].get(bone, neutral.get(bone))
	if a == null or b == null or c == null or d == null:
		return null
	return a.slerp(b, yaw_weight).slerp(c.slerp(d, yaw_weight), pitch_weight)

func apply(pitch: float, yaw: float, a: String, b: String, c: String, d: String, yaw_weight: float, pitch_weight: float) -> bool:
	root.set_meta("nativeAimActive", false)
	var neutral_name = "GroundRifleAimH50D50"
	for clip_name in [neutral_name, a, b, c, d]:
		if not player.has_animation(clip_name):
			return false
	var neutral = sample_clip(neutral_name)
	var corners = [sample_clip(a), sample_clip(b), sample_clip(c), sample_clip(d)]
	var hip = blended(hips, neutral, corners, yaw_weight, pitch_weight)
	var neutral_hip = neutral.get(hips)
	var tracks = 0
	for bone in neutral:
		if bone == hips:
			continue
		var target = blended(bone, neutral, corners, yaw_weight, pitch_weight)
		if target == null:
			continue
		if bone == spine and hip != null and neutral_hip != null:
			target = (neutral_hip.inverse() * hip) * target
		var delta: Quaternion = target * neutral[bone].inverse()
		var parent = skeleton.get_bone_parent(bone)
		var parent_rotation = Quaternion() if parent < 0 else skeleton.get_bone_global_pose(parent).basis.get_rotation_quaternion()
		var pose = skeleton.get_bone_global_pose(bone)
		var current_local = parent_rotation.inverse() * pose.basis.get_rotation_quaternion()
		var local = (delta * current_local).normalized()
		pose.basis = Basis.from_euler((parent_rotation * local).get_euler()).scaled(pose.basis.get_scale())
		skeleton.set_bone_global_pose_override(bone, pose, 1, true)
		tracks += 1
	if tracks > 0:
		skeleton.force_update_all_bone_transforms()
	root.set_meta("nativeAimActive", tracks > 0)
	root.set_meta("nativeAimPitch", pitch)
	root.set_meta("nativeAimYaw", yaw)
	root.set_meta("nativeAimTracks", tracks)
	return tracks > 0
