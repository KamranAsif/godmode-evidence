import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";

const execute = promisify(execFile);
const session = process.env.GODMODE_SESSION_ID;
assert.ok(session?.startsWith("perf-enemy-"), "Use an explicitly owned enemy session");
const cli = path.resolve("tools/godot-cli/dist/src/index.js");
const out = path.resolve("artifacts/native-aim-equivalence");
mkdirSync(out, { recursive: true });
async function call(args, env = process.env) {
    const { stdout } = await execute(process.execPath, [cli, ...args, "--project", process.cwd(), "--session", session, "--json"], {
        env,
        windowsHide: true,
        timeout: 180000,
        maxBuffer: 8e6,
    });
    const reply = JSON.parse(stdout);
    assert.ok(reply.ok, reply.message);
    return reply.data;
}
const results = [];
for (const control of [true, false]) {
    const name = control ? "control" : "native";
    const instance = `aim-equivalence-${name}-${process.pid}`;
    const file = path.join(out, name + ".json");
    rmSync(file, { force: true });
    let launch;
    try {
        launch = await call(["game", "run", "--headless", "--instance", instance, "--scene", "res://tests/fixtures/native_aim_equivalence.tscn"], {
            ...process.env,
            GODMODE_AIM_EQUIVALENCE_CONTROL: control ? "1" : "0",
        });
        writeFileSync(path.join(out, name + "-launch.json"), JSON.stringify(launch, null, 2));
        const deadline = Date.now() + 90000;
        while (!existsSync(file) && Date.now() < deadline) {
            if (existsSync(launch.logPath)) assert.doesNotMatch(readFileSync(launch.logPath, "utf8"), /^ERROR:|SCRIPT ERROR|Parse Error/m);
            await new Promise((resolve) => setTimeout(resolve, 250));
        }
        assert.ok(existsSync(file), "fixture completed");
        const result = JSON.parse(readFileSync(file, "utf8"));
        assert.equal(result.result, "PASS", JSON.stringify(result));
        assert.equal(result.control, control);
        assert.equal(result.cases, 900);
        assert.equal(result.comparisons, 453600);
        assert.ok(result.maxBoneDelta <= 0.00002);
        assert.ok(result.maxAttachmentDelta <= 0.0001);
        assert.deepEqual(result.failures, []);
        const log = readFileSync(launch.logPath, "utf8");
        assert.doesNotMatch(log, /^ERROR:|SCRIPT ERROR|Parse Error|GODMODE_FRAME_ERROR/m);
        if (!control) assert.match(log, /GODMODE_NATIVE_WEAPON_TORSO/);
        writeFileSync(path.join(out, name + "-engine.log"), log);
        results.push(result);
        console.log(JSON.stringify(result));
    } finally {
        if (launch) await call(["game", "stop", "--instance", instance]);
    }
}
const sources = ["scripts/game_world.ts", "scripts/presentation.ts", "scripts/humanoid_aim_native.gd", "scripts/humanoid_aim_native_api.ts"];
writeFileSync(
    path.join(out, "summary.json"),
    JSON.stringify(
        {
            result: "PASS",
            results,
            sourceSha256: Object.fromEntries(sources.map((file) => [file, createHash("sha256").update(readFileSync(file)).digest("hex")])),
        },
        null,
        2,
    ),
);
