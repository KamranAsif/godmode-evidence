extends Node

var comparisons := 0
var cases := 0
var max_bone_delta := 0.0
var max_attachment_delta := 0.0
var failures: Array = []
var mode_errors: Dictionary = {}
var control := false

func make_rig(path: String, reference: bool) -> Dictionary:
	var scene: Node3D
	if ResourceLoader.exists(path, "PackedScene"):
		scene = load(path).instantiate()
	else:
		var document := GLTFDocument.new()
		var state := GLTFState.new()
		assert(document.append_from_file(path, state) == OK)
		scene = document.generate_scene(state)
	add_child(scene)
	scene.position = Vector3(-404, -16.23, -414)
	scene.rotation = Vector3(0.03, 0.47, -0.02)
	scene.scale = Vector3(1.1, 0.9, 1.2)
	var skeleton: Skeleton3D = scene.find_children("*", "Skeleton3D", true, false)[0]
	var player: AnimationPlayer = scene.find_children("*", "AnimationPlayer", true, false)[0]
	player.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
	var script = load("res://tests/fixtures/native_aim_reference.gd" if reference else "res://scripts/humanoid_aim_native.gd")
	var solver = script.create(scene, skeleton, player)
	var attachment := BoneAttachment3D.new()
	attachment.bone_name = "mixamorig_RightHand"
	skeleton.add_child(attachment)
	attachment.bone_idx = skeleton.find_bone("mixamorig_RightHand")
	var socket := Node3D.new()
	attachment.add_child(socket)
	socket.position = Vector3(0.08, -0.01, 0.22)
	return {"scene": scene, "skeleton": skeleton, "player": player, "solver": solver, "socket": socket}

func prepare(rig: Dictionary, clip: String, progress: float, mode: int) -> void:
	var skeleton: Skeleton3D = rig.skeleton
	var player: AnimationPlayer = rig.player
	skeleton.show_rest_only = false
	for bone in skeleton.get_bone_count():
		skeleton.set_bone_enabled(bone, true)
	skeleton.clear_bones_global_pose_override()
	skeleton.reset_bone_poses()
	player.play(clip, 0)
	player.seek(player.get_animation(clip).length * progress, true)
	var spine := skeleton.find_bone("mixamorig_Spine1")
	if mode == 1:
		skeleton.set_bone_pose_scale(spine, Vector3(1.15, 0.85, 1.07))
	elif mode == 3:
		skeleton.set_bone_enabled(spine, false)
	elif mode == 4:
		skeleton.show_rest_only = true
	skeleton.force_update_all_bone_transforms()
	if mode == 2:
		var pose := skeleton.get_bone_global_pose(spine)
		pose.basis = Basis.from_euler(Vector3(0.1, -0.2, 0.15)) * pose.basis
		pose.origin += Vector3(0.02, 0.01, 0)
		skeleton.set_bone_global_pose_override(spine, pose, 0.8, true)
		skeleton.force_update_all_bone_transforms()

func difference(a: Transform3D, b: Transform3D) -> float:
	var error := 0.0
	var av := [a.basis.x, a.basis.y, a.basis.z, a.origin]
	var bv := [b.basis.x, b.basis.y, b.basis.z, b.origin]
	for column in 4:
		for row in 3:
			var delta: float = absf(av[column][row] - bv[column][row])
			if not is_finite(delta):
				return INF
			error = maxf(error, delta)
			comparisons += 1
	return error

func _ready() -> void:
	control = OS.get_environment("GODMODE_AIM_EQUIVALENCE_CONTROL") == "1"
	var rows: Array = []
	var reference = load("res://tests/fixtures/native_torso_reference.ts").new()
	add_child(reference)
	for model in ["rifle", "smg", "shotgun", "medic"]:
		var path := "res://assets/characters/mixamo/character-enemy-%s.glb" % model
		var before := make_rig(path, true)
		var after := make_rig(path, control)
		await get_tree().process_frame
		var model_cases := 0
		for clip in ["RifleIdle", "RifleWalk", "CrouchIdle"]:
			assert(before.player.has_animation(clip))
			for progress in [0.0, 0.37, 0.83]:
				for h in [0, 25, 50, 75, 100]:
					for d in [0, 25, 50, 75, 100]:
						var mode := (cases + int(cases / 5.0)) % 5
						prepare(before, clip, progress, mode)
						prepare(after, clip, progress, mode)
						var low_h := 0 if h < 50 else 50
						var low_d := 0 if d < 50 else 50
						var a := "GroundRifleAimH%dD%d" % [low_h, low_d]
						var b := "GroundRifleAimH%dD%d" % [low_h, low_d + 50]
						var c := "GroundRifleAimH%dD%d" % [low_h + 50, low_d]
						var e := "GroundRifleAimH%dD%d" % [low_h + 50, low_d + 50]
						var pitch: float = (h - 50) * PI / 200.0
						var yaw: float = (50 - d) * PI / 200.0
						var yw: float = (d - low_d) / 50.0
						var pw: float = (h - low_h) / 50.0
						var old_result: bool = before.solver.apply(pitch, yaw, a, b, c, e, yw, pw)
						var new_result: bool = after.solver.apply(pitch, yaw, a, b, c, e, yw, pw)
						var blade: float = [-0.8, -0.35, 0.0, 0.35, 0.8][cases % 5]
						var native_aim: bool = cases % 2 == 0
						var support: bool = int(cases / 2.0) % 2 == 0
						var old_hands: Vector2i = reference.twist(before.skeleton, pitch, blade, native_aim, support)
						var new_hands: Vector2i = reference.twist(after.skeleton, pitch, blade, native_aim, support) if control else after.solver.twist_weapon(pitch, blade, native_aim, support)
						if old_hands != new_hands:
							failures.append("hand indices differ")
						await get_tree().process_frame
						if not old_result or old_result != new_result:
							failures.append("%s/%s: aim unavailable or result differs" % [model, clip])
						var bone_error := 0.0
						for bone in before.skeleton.get_bone_count():
							bone_error = maxf(bone_error, difference(before.skeleton.get_bone_global_pose(bone), after.skeleton.get_bone_global_pose(bone)))
						var attachment_error := difference(before.socket.global_transform, after.socket.global_transform)
						max_bone_delta = maxf(max_bone_delta, bone_error)
						max_attachment_delta = maxf(max_attachment_delta, attachment_error)
						mode_errors[mode] = maxf(mode_errors.get(mode, 0), bone_error)
						if (bone_error > 0.00002 or attachment_error > 0.0001) and failures.size() < 20:
							failures.append({"model": model, "clip": clip, "progress": progress, "h": h, "d": d, "mode": mode, "bone": bone_error, "attachment": attachment_error})
						for key in ["nativeAimActive", "nativeAimPitch", "nativeAimYaw", "nativeAimTracks"]:
							if before.scene.get_meta(key) != after.scene.get_meta(key) and failures.size() < 20:
								failures.append("metadata differs: " + key)
						cases += 1
						model_cases += 1
		rows.append({"model": model, "cases": model_cases, "bones": before.skeleton.get_bone_count()})
		before.scene.queue_free()
		after.scene.queue_free()
		await get_tree().process_frame
	var result := {"result": "PASS" if failures.is_empty() else "FAIL", "control": control, "cases": cases, "comparisons": comparisons,
		"maxBoneDelta": max_bone_delta, "maxAttachmentDelta": max_attachment_delta, "modeErrors": mode_errors, "failures": failures, "models": rows,
		"modes": ["clean", "nonuniform bone scale", "existing partial global layer (original path)", "disabled spine bone", "rest-only (original path)"],
		"note": "Headless native torso twist compared with frozen original TypeScript over identical original aim poses. Not frame timing or visual evidence."}
	var file := FileAccess.open("res://artifacts/native-aim-equivalence/%s.json" % ("control" if control else "native"), FileAccess.WRITE)
	file.store_string(JSON.stringify(result, "  "))
	file.close()
	print("GODMODE_NATIVE_AIM_EQUIVALENCE=", JSON.stringify(result))
	get_tree().quit(0 if failures.is_empty() else 1)
