# Crowd torso pose measurement notes

Base main: 2b28eeab580b9f143b21cc2148edb4e9bdc7573f (#2148 merged).
Candidate: b791b170a (full SHA in measured manifests).
No map, mesh, material, shadow, animation cadence, AI or navigation changes.

The initial diagnostic measured native animation advance plus forced bone update
at about0.87-0.99 ms per engine frame, native aim at about1.6 ms and torso twist
at about0.74 ms. These diagnostic spans overlap outer pose costs. The GPU region
enclosing skinning is about0.05 ms and is not an isolated skinning kernel or a
total character draw/skinning/shadow budget. The estimated3-6 ms saving is not
fully attributed by these probes. The optimization targets the torso
span's repeated JavaScript/engine calls, preserving its exact operation order.

The native helper caches fixed bone indices for the imported skeleton and copies
the original ordered global overrides in one call. It does not cache poses or
change update frequency. Native aim calculation, animation rates and clips are
unchanged. Animation stays at its existing full rate inside30m.

The real-engine comparison uses the frozen original TypeScript torso operation,
with identical original aim poses. It checks all41 global bone matrices and an
actual right-hand BoneAttachment3D world transform across900 cases on four rigs,
including nonuniform scales, existing partial layers, disabled bones and rest-only.
Reference/reference control and native/reference each pass453600 comparisons;
maximum matrix and hand attachment differences are both0. Returned hand indices
also match. Exact fixture comparison is not frame timing or visual evidence.

Same65 living riflemen, seed1136293662, camera[-404,-15.58,-414], yawPI, FOV75.
Production D3D12 Forward+, scale1, TAAoff, uncapped VSync0, physics60Hz.
15s encounter settle and an8s first window preceded by2s warmup. This selection
was declared before any valid replacement result: compare only normal-1 from
the original controls. Their second windows remain supplemental data only.
Separate exclusive timing holds for1080p and1440p, released between runs.
Every window asserts65 enemies before/after, correct dimensions, no dropped
samples and equal engine/frame sample counts. Arena receipt is pinned to
 e4a4f09bae0f2f98e162c084fa7b7d259b43679cbacde9b15abda667fa64278a.

Whole-frame statistics pool all retained samples. Script results use unique
hitch-context frames with exact coverage stated. CPU and GPU overlap; do not add
them. Other live combat work varies; do not attribute the whole-frame difference
to this helper. GPU columns separate main render and other GPU work.

Before capture accepted: wide.png, grip.png and distance-20.png. The8m selected
target is partly hidden by a tree;35m target is not cleanly isolated. Exclude
these two from targeted fidelity claims. Live-fight images have different poses;
stills alone do not establish temporal smoothness. Actual Windows Playtest
verification is separate from the65-enemy development benchmark.

ART_STYLE.md including dated exceptions was read. Geometry and art inputs are
unchanged; no style conflict identified. Authored notes and code are ASCII.
