import { Basis, Node, Skeleton3D, Transform3D, Vector2i, Vector3 } from "godot";
import { characterBoneName } from "../../scripts/character_bones";

/** Frozen TypeScript torso operation from main 2b28eeab5, before changing its engine boundary. */
export default class NativeTorsoReference extends Node {
    twist(skeleton: Skeleton3D, pitch: number, bladeRadians: number, nativeAim: boolean, supportHand: boolean): Vector2i {
        const upperChest = skeleton.find_bone(characterBoneName("UpperChest"));
        const rightHand = skeleton.find_bone(characterBoneName("RightHand"));
        if (upperChest < 0 || rightHand < 0) return new Vector2i(-1, -1);
        const spine = ["Spine", "Chest", "UpperChest"].map((joint) => skeleton.find_bone(characterBoneName(joint))).filter((bone) => bone >= 0);
        const turn = axisAngle(0, 1, 0, bladeRadians / spine.length);
        const pitched = Basis.MULTIPLY(Basis.from_euler(new Vector3(nativeAim ? 0 : -pitch, 0, 0)), turn);
        for (const bone of spine) {
            const pose = skeleton.get_bone_global_pose(bone);
            const aim = bone === upperChest ? pitched : turn;
            const override = new Transform3D();
            override.basis = Basis.MULTIPLY(aim, pose.basis);
            override.origin = pose.origin;
            skeleton.set_bone_global_pose_override(bone, override, 1, true);
        }
        return new Vector2i(rightHand, supportHand ? skeleton.find_bone(characterBoneName("LeftHand")) : -1);
    }
}

function axisAngle(x: number, y: number, z: number, angle: number): Basis {
    const c = Math.cos(angle),
        s = Math.sin(angle),
        t = 1 - c;
    const basis = new Basis();
    basis.x = new Vector3(c + x * x * t, x * y * t + z * s, x * z * t - y * s);
    basis.y = new Vector3(x * y * t - z * s, c + y * y * t, y * z * t + x * s);
    basis.z = new Vector3(x * z * t + y * s, y * z * t - x * s, c + z * z * t);
    return basis;
}
