Matched 65-enemy movement comparison and Windows Playtest verification.

Each timing run used full 1080p detail, a fixed seed/camera/arena, uncapped rendering and its own exclusive hold. comparison.json reports context coverage and actual-call denominators. Inclusive script timers overlap. Whole-frame differences are not attributed entirely to the helper.

The Windows Playtest was exported from the frozen measured candidate and its verified arena. All ten measured enemy runtime files are byte-identical on the rebased PR; source-parity.json records this scope. The exported build has no inspection bridge or fixture scene override. Ordinary moving enemies and their footsteps exercise the shipped helper, including cues over 10 m listener distance. Listener distance is not a direct AI scheduler counter. Exact physics equivalence and 65-enemy timings are separate checks.

Actual executable captures were inspected by the primary and independent visual auditor. Only gameplay-a.png is accepted as gameplay. B/C show the ordinary audience-zero summary and are excluded as combat evidence. Stills do not establish temporal animation quality. The visual audit states its limits.

Only whitelisted source hashes, numeric evidence and movement playback receipts are included. No process-watch logs, peer command lines, arbitrary runtime stores or private raw engine logs are included.
