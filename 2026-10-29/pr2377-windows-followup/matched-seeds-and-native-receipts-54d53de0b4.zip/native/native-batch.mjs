import {spawn} from 'node:child_process';
import {writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
import {acquireWindowLock,gpuMeasurementLock} from '../../tools/godot-cli/dist/src/cli.js';
const out=resolve('artifacts/crate-tiers-windows');
const session='verify-2377-native-'+randomUUID().replaceAll('-','');
const gpu=gpuMeasurementLock();
let releaseWindow,hold;
try {
  while(!releaseWindow){
    hold=await gpu.hold(session,'Crate Windows native input batch',15*60*1000,Infinity,line=>process.stderr.write(line+'\n'),'capture');
    try {releaseWindow=await acquireWindowLock(0);}
    catch(error){
      await gpu.release(session,true,hold.id);
      console.log('Waiting for native window queue without an engine or GPU hold.');
      const release=await acquireWindowLock(Infinity);await release();
    }
  }
  await writeFile(resolve(out,'native-batch-admission.json'),JSON.stringify({session,hold,windowOwnerPid:process.pid,plan:process.argv[2]}));
  const child=spawn('powershell',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',resolve(out,'ui-batch.ps1'),'-Plan',resolve(process.argv[2])],{stdio:'inherit',windowsHide:true,env:{...process.env,GODMODE_SESSION_ID:session,GODMODE_REVIEW_ADMITTED:'1',GODMODE_REVIEW_WINDOW_BATCH_PID:String(process.pid)}});
  process.exitCode=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',code=>resolve(code??1));});
} finally {if(releaseWindow)await releaseWindow();await gpu.release(session,true,hold?.id);}
