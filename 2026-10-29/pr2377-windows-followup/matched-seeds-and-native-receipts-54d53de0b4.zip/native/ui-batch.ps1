param([Parameter(Mandatory=$true)][string]$Plan)
$ErrorActionPreference='Stop'
$env:GODMODE_GPU_CAPTURE_LIMIT='3'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
$out=$PSScriptRoot
$env:GODMODE_NATIVE_REVIEW_HELPER=Join-Path $out 'windows_window-review.ps1'
$cli='tools/godot-cli/dist/src/index.js'

if($env:GODMODE_REVIEW_ADMITTED -ne '1'){$env:GODMODE_SESSION_ID='verify-2377-batch-'+[guid]::NewGuid().ToString('N')}
[IO.File]::WriteAllText((Join-Path $out 'ui-session.txt'),$env:GODMODE_SESSION_ID)
$cliFile=(Resolve-Path tools/godot-cli/dist/src/cli.js).Path
$text=[IO.File]::ReadAllText($cliFile)
$old='executablePath = firstFlag < 0 ? trimmed : trimmed.slice(0, firstFlag);'
$new='executablePath = /^(.+?\.exe)(?:\s|$)/i.exec(trimmed)?.[1] ?? (firstFlag < 0 ? trimmed : trimmed.slice(0, firstFlag));'
if($text.Contains($old)){[IO.File]::WriteAllText($cliFile,$text.Replace($old,$new))}
if($env:GODMODE_REVIEW_ADMITTED -ne '1'){
node (Join-Path $out 'wait-window.mjs')
if($LASTEXITCODE -ne 0){throw 'Native window admission failed before launch'}
do {
    node (Join-Path $out 'hold.mjs')|Set-Content (Join-Path $out 'batch-hold.json')
    if($LASTEXITCODE -ne 0){throw 'Batch capture hold failed'}
    $admissionMemory=Get-CimInstance Win32_OperatingSystem
    if($admissionMemory.FreePhysicalMemory -lt 4*1024*1024){
        node $cli gpu release --json
        throw 'RAM admission lost; requeue with ram:4'
    }
} while($admissionMemory.FreePhysicalMemory -lt 4*1024*1024)
}
. (Join-Path $out 'control.ps1')
. (Join-Path $out 'offer-sequence.ps1')
$planData=Get-Content -LiteralPath $Plan -Raw|ConvertFrom-Json
try {
    $m=Get-CimInstance Win32_OperatingSystem
    @{utc=[DateTime]::UtcNow.ToString('o');freeKiB=$m.FreePhysicalMemory;plan=$Plan}|ConvertTo-Json -Compress|Add-Content (Join-Path $out 'batch-memory-gates.jsonl')
    if($m.FreePhysicalMemory -lt 4*1024*1024){throw 'Below 4 GiB: defer batch launch'}
    $profile=if($planData.profile){Join-Path $out $planData.profile}else{Join-Path $out 'review.settings.cfg'}
    $binary=if($planData.binary){if([IO.Path]::IsPathRooted($planData.binary)){$planData.binary}else{Join-Path $out $planData.binary}}else{Join-Path $out 'debug/BattleDuty.exe'}
    $args=@($cli,'game','run','--project','.','--binary',$binary,'--instance','crate-windows-review','--session',$env:GODMODE_SESSION_ID,'--offscreen','--settings-path',$profile,'--json')
    if($planData.fixture){$args+=@('--fixture','roguelite')}
    if($planData.autorun){$env:GODMODE_CONSOLE_AUTORUN=[string]$planData.autorun}else{Remove-Item Env:GODMODE_CONSOLE_AUTORUN -ErrorAction SilentlyContinue}
    $raw=node @args
    $code=$LASTEXITCODE
    [IO.File]::WriteAllText((Join-Path $out 'batch-launch.json'),($raw -join [Environment]::NewLine))
    if($code -ne 0 -or -not (($raw -join '')|ConvertFrom-Json).ok){throw ($raw -join '')}
    Crate-Input @{windowed=$true}
    Crate-Input @{rightButton=$false}
    if($planData.waitPresented){
        . (Join-Path $out 'wait-presented.ps1')
        $launchData=($raw -join '')|ConvertFrom-Json
        Wait-ReviewPresented $launchData.data.logPath $launchData.data.pid
    } else {Start-Sleep -Seconds 40}
    Crate-Input @{windowed=$true}
    if($planData.opening -eq 'pause-options' -or $planData.opening -eq 'story-options'){
        Crate-Input @{key=13}
        Start-Sleep -Seconds 180
        if($planData.opening -eq 'story-options'){
            Crate-Input @{key=69;durationMs=1200}
            Start-Sleep -Seconds 20
            Crate-Shot 'normal-story-after-link'
        }
        Crate-Input @{key=27}
        Crate-Input @{click=@(155,220)}
    }
    foreach($step in $planData.steps){
        if($step.offerSequence){Crate-OfferSequence ([int]$step.offerSequence)}
        if($step.heldShot){Crate-HeldShot ([string]$step.heldShot)}
        if($step.consoleRaw){Crate-Input @{key=192;text=[string]$step.consoleRaw;keysAfterText=@(13,192)}}
        if($step.checkpoint){
            $saveBase=[IO.Path]::ChangeExtension($profile,$null)
            foreach($suffix in @('meta.save','channel.save')){
                $source=$saveBase+$suffix
                if(Test-Path -LiteralPath $source){Copy-Item -LiteralPath $source -Destination (Join-Path $out ($step.checkpoint+'.'+$suffix))}
            }
        }
        if($step.walletExpected){
            $currentMeta=Get-Content -LiteralPath ([IO.Path]::ChangeExtension($profile,$null)+'meta.save') -Raw|ConvertFrom-Json
            if($currentMeta.dollars -ne [long]$step.walletExpected){throw ('Wallet gate: expected '+$step.walletExpected+' observed '+$currentMeta.dollars)}
        }
        if($step.rootAccessExpected){
            $currentMeta=Get-Content -LiteralPath ([IO.Path]::ChangeExtension($profile,$null)+'meta.save') -Raw|ConvertFrom-Json
            if(-not $currentMeta.upgrades.rootAccess -and $currentMeta.unlocked -notcontains 'rootAccess'){throw 'Live grant gate: Root Access is not owned'}
        }
        if($step.requireText){
            $ocrRaw=& (Join-Path $out 'ocr-native.ps1') -Image (Join-Path $out ($step.requireText.shot+'.png'))
            $ocrRaw|Set-Content (Join-Path $out ($step.requireText.shot+'.ocr.json'))
            $ocr=$ocrRaw|ConvertFrom-Json
            foreach($term in $step.requireText.terms){if($ocr.text -notlike ('*'+$term+'*')){throw ('Native UI OCR did not find '+$term+' in '+$step.requireText.shot)}}
        }
        if($step.input){$h=@{};foreach($p in $step.input.PSObject.Properties){$h[$p.Name]=$p.Value};Crate-Input $h}
        if($step.console){Crate-Console ([string]$step.console)}
        if($step.waitMs){Start-Sleep -Milliseconds ([int]$step.waitMs)}
        if($step.shot){Crate-Shot ([string]$step.shot)}
    }
} finally {
    Crate-Cleanup
    if($profile){
        $saveBase=[IO.Path]::ChangeExtension($profile,$null)
        foreach($suffix in @('meta.save','channel.save')){
            if(Test-Path ($saveBase+$suffix)){
                $destination=Join-Path $out (([IO.Path]::GetFileNameWithoutExtension($Plan))+'.final.'+$suffix)
                Copy-Item ($saveBase+$suffix) $destination
            }
        }
    }
    $engineLog=Join-Path $env:TEMP 'godot-cli/291e3f44b2ae/game-crate-windows-review.log'
    if(Test-Path -LiteralPath $engineLog){Copy-Item -LiteralPath $engineLog -Destination (Join-Path $out (([IO.Path]::GetFileNameWithoutExtension($Plan))+'.engine.log'))}
}
