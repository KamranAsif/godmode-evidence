$ErrorActionPreference='Stop'
$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$env:GODOTJS_PATH='C:\tools\GodotJS-4.6.1-v8-nopc-2\editor\godot.windows.editor.x86_64.exe'
$root=$PSScriptRoot
$repo='D:\work\godmode.exe-rougelite'
$pr='0bd56376f3da79328cde4f7307c09af362f24824'
$main='61792ef4116b54740e3300da83959809a6b15e80'
@{candidate=$pr;baseline=$main}|ConvertTo-Json|Set-Content "$root/revisions.json"
Get-ChildItem Env:GODMODE_GRUNT_METER_* | Remove-Item
Remove-Item Env:GODMODE_SESSION_ID -ErrorAction SilentlyContinue
function Check-Memory {
 $m=Get-CimInstance Win32_OperatingSystem
 @{utc=[DateTime]::UtcNow.ToString('o');freeKiB=$m.FreePhysicalMemory}|ConvertTo-Json -Compress|Add-Content "$root/memory.jsonl"
 if($m.FreePhysicalMemory -lt 4194304){throw 'Below 4 GiB; requeue this job before any engine launch'}
}
$receipts=@()
foreach($revision in @(@{label='pr';sha=$pr},@{label='main';sha=$main})) {
 $tree=Join-Path $root $revision.label
 git -C $repo worktree add --detach $tree $revision.sha
 if($LASTEXITCODE -ne 0){throw 'worktree failed'}
 Push-Location $tree
 $prep='pr2377-followup-prepare-'+$revision.label+'-'+[guid]::NewGuid().ToString('N')
 try {
  pnpm install --frozen-lockfile
  if($LASTEXITCODE -ne 0){throw 'install failed'}
  pnpm build:scripts
  if($LASTEXITCODE -ne 0){throw 'build failed'}
  pnpm imports:seed
  if($LASTEXITCODE -ne 0){throw 'seed failed'}
  Check-Memory
  node tools/godot-cli/dist/src/index.js project import --project . --session $prep
  if($LASTEXITCODE -ne 0){throw 'import failed'}
  foreach($seed in @('1871','2853137488')) {
   Check-Memory
   $env:GODMODE_PLAYABILITY_SEED=$seed
   $log=Join-Path $root ($revision.label+'-'+$seed+'.log')
   $before=@(Get-ChildItem artifacts/first-run-playability -Directory -ErrorAction SilentlyContinue|Select-Object -ExpandProperty Name)
   cmd /d /c "pnpm test:first-run-playability > `"$log`" 2>&1"
   $code=$LASTEXITCODE
   $dirs=@(Get-ChildItem artifacts/first-run-playability -Directory -ErrorAction SilentlyContinue|Where-Object {$before -notcontains $_.Name}|Select-Object -ExpandProperty FullName)
   $receipts+=@{revision=$revision.label;sha=$revision.sha;seed=$seed;exitCode=$code;log=$log;resultDirectories=$dirs}
   $receipts|ConvertTo-Json -Depth 10|Set-Content "$root/runs.json"
  }
 } finally {
  node tools/godot-cli/dist/src/index.js session end --project . --session $prep
  Remove-Item Env:GODMODE_PLAYABILITY_SEED -ErrorAction SilentlyContinue
  Pop-Location
 }
}
$receipts|Format-Table revision,seed,exitCode
