import sys, subprocess, pathlib, json, hashlib, math, csv, struct
from concurrent.futures import ThreadPoolExecutor
import numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).parent / 'python'))
import imageio_ffmpeg
root = pathlib.Path(__file__).resolve().parent.parent
ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
paths = sorted(p for p in (root/'assets/audio').rglob('*') if p.suffix.lower() in ('.ogg','.wav','.mp3'))
def db(v): return round(20*math.log10(v),3) if v > 0 else None
def audit(p):
    result = subprocess.run([ffmpeg,'-v','error','-threads','1','-i',str(p),'-f','wav','-acodec','pcm_f32le','-'],capture_output=True)
    if result.returncode: raise RuntimeError(f'{p}: {result.stderr.decode()}')
    at = 12
    while at+8 <= len(result.stdout):
        tag = result.stdout[at:at+4]; size=struct.unpack_from('<I',result.stdout,at+4)[0]; at+=8
        if tag == b'fmt ': channels,rate=struct.unpack_from('<HI',result.stdout,at+2)
        if tag == b'data': break
        at += size+(size%2)
    x = np.frombuffer(result.stdout[at:],dtype='<f4').reshape(-1,channels)
    loud = np.max(np.abs(x),axis=1) >= 0.001
    active = np.flatnonzero(loud)
    duration = len(x)/rate
    lead = int(active[0])/rate if len(active) else duration
    tail = (len(x)-int(active[-1])-1)/rate if len(active) else duration
    block=max(1,round(rate*.01))
    energy=np.sum(x.astype(np.float64)**2,axis=1)/channels
    starts=np.arange(0,len(x),block)
    lengths=np.minimum(block,len(x)-starts)
    block_rms=np.sqrt(np.add.reduceat(energy,starts)/lengths)
    quiet_fraction=float(np.sum(lengths[block_rms<.001])/len(x))
    peak = db(float(np.max(np.abs(x)))) if len(x) else None
    mean = db(float(np.sqrt(np.mean(x.astype(np.float64)**2)))) if len(x) else None
    fraction = float(1-np.mean(loud)) if len(x) else 1
    flags = []
    if peak is None: flags.append('fully-silent')
    elif peak <= -40 or mean <= -55: flags.append('near-silent')
    if peak is not None and peak > 0: flags.append('decoded-over-full-scale')
    if fraction >= .8: flags.append('mostly-silence')
    if lead >= 1 or (lead >= .25 and lead >= duration*.25): flags.append('long-lead-in')
    return dict(path=p.relative_to(root).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),sampleRate=rate,channels=channels,durationSeconds=round(duration,6),peakDbfs=peak,meanRmsDbfs=mean,belowMinus60Fraction=round(fraction,6),belowMinus60Rms10msFraction=round(quiet_fraction,6),leadBelowMinus60Seconds=round(lead,6),tailBelowMinus60Seconds=round(tail,6),flags=flags)
with ThreadPoolExecutor(max_workers=2) as pool: rows=list(pool.map(audit,paths))
groups={}
for r in rows: groups.setdefault(r['sha256'],[]).append(r['path'])
duplicates=[dict(sha256=k,files=v) for k,v in groups.items() if len(v)>1]
variations=[g for g in duplicates if len({p.rsplit('-',1)[0] for p in g['files']})<len(g['files'])]
result=dict(method='FFmpeg 7.1 decoded float32 at native rate/channels; peak=max absolute sample, mean=RMS dBFS. belowMinus60Fraction: duration when ALL channels below amplitude 0.001; additional duration-weighted 10ms RMS fraction provided. Flags: peak<=-40 or RMS<=-55 near-silent; >=80% sample-frame duration mostly silence; lead>=1s or >=250ms and >=25% duration long lead-in. Compressed priming included as decoded by FFmpeg.',files=rows,duplicates=duplicates,variationDuplicates=variations)
(root/'artifacts/waveform-audit.json').write_text(json.dumps(result,indent=2))
with (root/'artifacts/waveform-audit.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print(json.dumps(dict(files=len(rows),flagged=[r for r in rows if r['flags']],duplicateGroups=len(duplicates),variationDuplicateGroups=len(variations)),indent=2))
