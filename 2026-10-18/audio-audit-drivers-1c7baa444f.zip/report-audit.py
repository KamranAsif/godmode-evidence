import pathlib,json,wave,math
import numpy as np
root=pathlib.Path(__file__).resolve().parent
load=lambda p:json.loads((root/p).read_text(encoding='utf-8-sig'))
scan=load('waveform-audit.json');before=load('isolated-before/report.json');after=load('isolated-after/report.json');final=load('burst-final/report.json')
support=load('support-before/report.json'); support_final=load('support-final/report.json')
def pcm(folder,name):
    with wave.open(str(root/folder/(name+'.wav'))) as w:
        samples=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2')
        return dict(pcmSamples=len(samples),fullScaleSamples=int(np.sum((samples==32767)|(samples==-32768))))
rows={r['name']:dict(r,**pcm('isolated-after',r['name'])) for r in after['cases']}
for r in final['cases']: rows[r['name']]=dict(r,**pcm('burst-final',r['name']))
old={r['name']:dict(r,**pcm('isolated-before',r['name'])) for r in before['cases']}
for r in support['cases']:
    rows[r['name']]=dict(r,**pcm('support-before',r['name']))
    old[r['name']]=dict(r,**pcm('support-before',r['name']))
for r in support_final['cases']:
    if r['name'].startswith('warmup-'): continue
    rows[r['name']]=dict(r,**pcm('support-final',r['name']))
parents={'RifleBody':'WeaponDirect','RifleMechanical':'WeaponDirect','RifleSub':'WeaponDirect','RifleTail':'WeaponTail','RifleReflections':'WeaponTail','WeaponTail':'GameplaySfx','WeaponDirect':'GameplaySfx','GameplaySfx':'Master','GameplayUI':'Master'}
low=[]
for row in rows.values():
    for receipt in row['receipts']:
        gain=receipt['volumeDb'];bus=receipt['bus']; chain=[]
        while bus:
            snap=receipt['busSnapshot'][bus]; gain+=snap['volumeDb'];chain.append(dict(bus=bus,**snap));bus=parents.get(bus)
        if gain<=-40: low.append(dict(case=row['name'],gainDb=gain,chain=chain))
summary=dict(sourceCommit='0bbaa6f1f',method='Native GodotJS headless AudioEffectRecord Master PCM plus actual AudioStreamPlayer bus/send gains; 100% volume, committed tuning.json and swaps, no saved/live human overrides. Isolated 46-case before and intermediate after. Final 10-case subset retested headroom and auditions after gain changes; final burst is 12 shots vs 4 baseline (stronger stress). First baseline near-pistol echo was dropped because test scheduled before a costly sound-set switch; fresh setup clock retest produces PCM, so this is not a game defect. Default empty mechanical/sub are tested solo. New machine-fire direct case is an API diagnostic: normal New-mode gameplay uses the five-layer rifle instead.',silentCases=[r['name'] for r in rows.values() if r['outputPeakDbfs'] is None],startGainsAtOrBelowMinus40=low,rifleClipping=[dict(case=n,before=old[n]['fullScaleSamples'],after=rows[n]['fullScaleSamples'],afterPeakDbfs=rows[n]['outputPeakDbfs']) for n in ['classic-machine-fire','new-rifle-body','new-rifle-burst']],cases=list(rows.values()),waveformConsoleBefore=load('console-before.json'),waveformConsoleAfter=load('console-after.json'))
summary['method'] += ' Secondary audit adds 74 cheat/enemy cue, support-loop and enemy-gun cases in both sound sets, plus actual console auditions. World sources are at their authored unit_size (unity distance gain); cheat one-shots use the production flat actor path. First recorder/decoder warmup can miss a short drone cue; warmed retry produces PCM. New officer radio is deliberately muted by profile newMutedPaths. The final mortar/browser corrections have their own native retries. No warmup case is treated as a content defect.'
summary['mortarClipping']=dict(case='new-cheat-mortar-impact',before=old['new-cheat-mortar-impact']['fullScaleSamples'],after=rows['new-cheat-mortar-impact']['fullScaleSamples'],afterPeakDbfs=rows['new-cheat-mortar-impact']['outputPeakDbfs'])
(root/'runtime-audit.json').write_text(json.dumps(summary,indent=2))
assert set(summary['silentCases'])=={'new-rifle-mechanical','new-rifle-sub','new-preview-rifle-mechanical','new-preview-rifle-sub','new-enemy-officer-radio'}
assert not low
assert all(r['after']==0 for r in summary['rifleClipping'])
assert summary['mortarClipping']['after']==0
assert len(rows)==125
assert len([r for r in rows['new-rifle-burst']['receipts'] if 'rifle:body:' in r['source']])==12
def fmt(v):return 'silent' if v is None else f'{v:.2f}'
report=['# Audio audit - 2026-10-18','',f"Source: origin/main `0bbaa6f1f`; 716 files. {scan['method']}",'','No fully silent or near-silent source files. Quietest peak: '+str(min(r['peakDbfs'] for r in scan['files']))+' dBFS.','', '## Source flags','', '| File | Flags | Duration s | Peak dBFS | RMS dBFS | Below -60 sample % / 10ms RMS % | Lead s |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for r in scan['files']:
    if r['flags']:report.append(f"| `{r['path']}` | {', '.join(r['flags'])} | {r['durationSeconds']:.3f} | {fmt(r['peakDbfs'])} | {fmt(r['meanRmsDbfs'])} | {r['belowMinus60Fraction']*100:.1f} / {r['belowMinus60Rms10msFraction']*100:.1f} | {r['leadBelowMinus60Seconds']:.3f} |")
report+=['','Mostly-silence flags are a screening threshold, not proof of a broken transient. Dead lead-ins and missing/duplicate content go to the sound owner. 45 codec sources decode above full scale in float; this does not imply every playback clips because authored gains provide headroom. No asset samples were edited.','', '## Runtime - every tested weapon/layer','',summary['method'],'', '| Case | Resolved physical recording(s) | Effective gain(s) dB including sends | Master peak dBFS | Full-scale PCM samples |','| --- | --- | --- | ---: | ---: |']
for r in rows.values():
    files=sorted(set(v['file'] for v in r['voices'] if v['file']))
    gains=sorted(set(round(v['effectiveGainDb'],2) for v in r['voices']))
    report.append(f"| {r['name']} | {'; '.join('`'+p+'`' for p in files) or 'none'} | {', '.join(map(str,gains)) or 'n/a'} | {fmt(r['outputPeakDbfs'])} | {r['fullScaleSamples']} |")
report+=['','At 100% default volume there are no assigned starts at/below -40 dB effective gain. Tail decay can intentionally fade below that floor; the late reflections are intentionally quiet. Pistol near/far echoes produce very quiet PCM (-40.85/-44.85 dBFS), with -24/-28 dB effective gains.','', '## Fixes','', '- Empty effect previews now resolve the same body recording as gameplay (tail/reflection HTTP 404 -> 200); mechanical/sub stay empty until sound owner supplies recordings.', '- Starts with explicit authored values cannot accidentally recover a prior pooled sound base (e.g. pistol -5 plus -2 trim equals rifle authored -7).', '- Local Classic direct rifle adds -3 dB headroom after its proper authored -7 dB base; +6 saved trim unchanged. Measured direct gain +1 -> -4 dB in the pooled reproduction.', '- New rifle body base -7 -> -15 dB. Saved +6 trim and first/sustained accents unchanged: first effective +0.5 -> -7.5 dB. Tail/reflection gains unchanged. Single-shot clipping and a stronger 12-shot burst now have zero full-scale PCM samples.', '- Raw decodes, committed swaps and duplicated effect streams retain physical source identity separately from the virtual tuning key.','', '## Byte-identical groups','',f"{len(scan['duplicates'])} groups: {len(scan['variationDuplicates'])} numbered variation groups; 13 intentional asset-set/swap mirrors. Exact SHA-256 groups below.",'']
report+=['','New mortar accent +6 -> +3 dB; with saved -4.2 dB trim effective gain +1.8 -> -1.2 dB, Master peak now -1.30 dBFS and zero full-scale samples. Browser unplayed audition defaults 0 dB / Master -> -12 dB / GameplaySfx, matching F4. Actual console auditions produced PCM for body/reflections/tail (-3.22/-13.60/-13.60 dBFS); empty mechanical/sub stayed silent.','']
variations={r['sha256'] for r in scan['variationDuplicates']}
for g in scan['duplicates']:
    report+=['- '+('Variation' if g['sha256'] in variations else 'Mirror')+' `'+g['sha256']+'`: '+', '.join('`'+p+'`' for p in g['files'])]
(root/'audio-audit-report.md').write_text('\n'.join(report)+'\n')
print(json.dumps(dict(cases=len(rows),silent=summary['silentCases'],lowGains=low,clipping=summary['rifleClipping']),indent=2))
