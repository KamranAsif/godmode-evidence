import {readFileSync,writeFileSync} from 'node:fs';
import {runtimeAction,runtimeInspect} from '../tools/godot-cli/dist/src/cli.js';
const read=p=>{const b=readFileSync(p);return JSON.parse(b[0]===255?b.toString('utf16le').slice(1):b.toString('utf8').replace(/^\uFEFF/,''));};
const start=read('artifacts/combat-full-start.json');
const url=start.data.inspectionUrl;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const inspect=async()=>(await runtimeInspect(url,undefined,true)).data.store;
const actions=[];
const action=async(name,payload)=>{const result=(await runtimeAction(url.replace('/inspect','/action'),{name,payload},{waitMs:30000})).data;actions.push({name,payload,result});return result;};
try{
await action('debug_restart_run',{});await wait(500);
await action('debug_roguelite_seed',{seed:1871});await wait(500);
await action('debug_console',{run:'invincible on'});
await action('debug_console',{run:'stream hold on'});
await action('debug_console',{run:'kill enemies'});
const state=await inspect();const playerId=state.localPeerId;
await action('debug_audio_record',{output:process.cwd().replaceAll('\\','/')+'/artifacts/accepted-shots.wav'});
const rows=[];
for(const weapon of ['pistol','machineGun','shotgun','sniperRifle','smg','dmr','grenadeLauncher']){
 await action('debug_equip_weapon',{playerId,weapon});await wait(900);
 await action('input',{shoot:true,tap:true,tapFrames:2});await wait(1200);
 const s=await inspect();rows.push({weapon,counts:s.audio?.playedCounts,alive:s.snapshot?.players.find(p=>p.id===playerId)?.alive,runDead:s.roguelite?.run?.survival?.dead});
}
await action('debug_audio_record',{stop:true});
writeFileSync('artifacts/accepted-shots-report.json',JSON.stringify({profile:'full headless production arena because cheap arena generator times out',soundSet:'Classic default',sourceCommit:'0bbaa6f1f plus current audio fixes',rows,actions},null,2));
console.log(JSON.stringify(rows.map(r=>({weapon:r.weapon,alive:r.alive,dead:r.runDead,counts:r.counts})),null,2));
}catch(e){writeFileSync('artifacts/accepted-shots-error.json',JSON.stringify({error:String(e.stack),actions},null,2));throw e;}
