Lighting investigation, 2026-10-06.
Raw native PNG URLs and SHA-256 hashes are in accepted-captures.json and image-uploads.json.
All PNGs are 1920x1080. Architectures are analogous contexts in different maps, not identical geometry.
Each repository used its own godot-cli runtime. FPS audit uses isolated server/client subtrees in one engine; the patch is included.
Frame samples are 5-second warm-up + 10-second uncapped rendered windows; no bridge polling during sampling.
Crop is audit-only. Original atlas and tracked scratch source were restored; see restoration-receipt.json.
No PR, merge, production lighting change, or combined fix was made.
