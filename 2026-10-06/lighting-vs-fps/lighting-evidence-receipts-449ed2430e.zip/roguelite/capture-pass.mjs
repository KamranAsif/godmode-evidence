import {readFile} from 'node:fs/promises';
import { rogue,fps,output,cli,action,store,ready,save,capture,views,delay } from './control.mjs';
const project = process.argv[2]==='fps'?fps:rogue;
const instance = project===fps?'lighting-fps':'lighting-rogue';
const kind = project===fps?'fps':'rogue';
const pass = process.argv[3]??'baseline';
const value = await ready(project,instance);
const playerId = value.localPeerId;
const inventory=(await action(project,instance,'investigation_inventory')).result;
await save(`${kind}-${pass}-inventory`,inventory.inventoryFile?JSON.parse(await readFile(inventory.inventoryFile,'utf8')):inventory);
if (project===rogue) {
    await action(project,instance,'pause',{open:false});
    await action(project,instance,'debug_console',{invincible:true,killEnemies:true,freeFly:true,hideMinimap:true,open:false});
    await action(project,instance,'photo_mode',{active:true});
    await action(project,instance,'pause',{open:false});
    await action(project,instance,'debug_kill_admins',{},true);
    await delay(8000);
    await action(project,instance,'pause',{open:true});
} else await action(project,instance,'investigation_photo',{enabled:true});
await delay(3000);
const result = [];
for (const view of views[kind]) {
    if (view.id==='gameplay') {
        await action(project,instance,'investigation_view',{pinned:false});
        if (project===rogue) {
            await action(project,instance,'debug_console',{freeFly:false,open:false});
            await action(project,instance,'photo_mode',{active:false});
            await action(project,instance,'pause',{open:false});
            await action(project,instance,'debug_kill_admins',{},true);
            await action(project,instance,'debug_set_player_position',{playerId,x:view.position[0],y:view.position[1]-0.65,z:view.position[2]});
            await action(project,instance,'input',{yaw:view.yaw,pitch:view.pitch,moveX:0,moveZ:0,hold:true});
        } else {
            await action(project,instance,'investigation_photo',{enabled:false});
            await action(project,instance,'investigation_server',{name:'debug_equip_weapon',payload:{playerId,weapon:'machineGun'}});
            await action(project,instance,'investigation_server',{name:'debug_set_player_position',payload:{playerId,x:view.position[0],y:view.position[1]-0.65,z:view.position[2]}});
            await action(project,instance,'input',{yaw:view.yaw,pitch:view.pitch,moveX:0,moveZ:0,hold:true});
        }
    } else {
        await action(project,instance,'investigation_view',view);
        if (project===rogue) await action(project,instance,'debug_console',{flyTo:view.position,lookAt:{yaw:view.yaw,pitch:view.pitch}});
    }
    await delay(2000);
    const label = `${kind}-${pass}-${view.id}`;
    await capture(project,instance,label);
    const state = await store(project,instance);
    const frames = await cli(project,'runtime','frames','--instance',instance,'--window-ms','10000','--warmup-ms','5000');
    await save(`${label}-frames`,frames);
    await save(`${label}-store`,state);
    result.push({label,view,frames});
    console.log(`${label}: ${frames.meanMs??frames.mean??JSON.stringify(frames.statistics??frames).slice(0,220)}`);
}
await save(`${kind}-${pass}-manifest`,result);
