import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { rogue,output,action,save,ready } from './control.mjs';
const execute=promisify(execFile);
const reset={environment:{ssao_enabled:true,ssil_enabled:false,ssil_intensity:1,ssil_radius:5,tonemap_mode:3,tonemap_exposure:0.5,ambient_light_energy:1.5,adjustment_enabled:true,ssr_enabled:false},sun:{light_bake_mode:2,shadow_enabled:true,shadow_normal_bias:1.4,shadow_bias:0.06,shadow_opacity:0.9},shade_fill:'restore'};
await ready(rogue,'lighting-rogue');
for (const [label,toggle] of [['fill-zero',{shade_fill:0}],['fill-low',{shade_fill:0.2}],['shadow-off',{sun:{shadow_enabled:false}}]]) {
 await action(rogue,'lighting-rogue','investigation_toggle',reset);
 await save(`rogue-${label}-toggle`,await action(rogue,'lighting-rogue','investigation_toggle',toggle));
 console.log('Testing '+label);
 const {stdout}=await execute(process.execPath,[`${output}/capture-pass.mjs`,'rogue',label],{cwd:rogue,windowsHide:true,timeout:600000,maxBuffer:2e6}); console.log(stdout.trim());
}
await action(rogue,'lighting-rogue','investigation_toggle',reset);
