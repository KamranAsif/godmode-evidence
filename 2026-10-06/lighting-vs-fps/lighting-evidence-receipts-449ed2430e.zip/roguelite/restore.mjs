import assert from 'node:assert/strict';
import path from 'node:path';
import {cp,rm,readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {rogue,fps,output,cli,session} from './control.mjs';
const execute=promisify(execFile);
const target=path.resolve(rogue,'assets/maps/sands_pearl/lighting');
assert.equal(path.dirname(target),path.resolve(rogue,'assets/maps/sands_pearl'));
assert.ok(target.startsWith(path.resolve(rogue)+path.sep));
assert.equal((await cli(rogue,'game','ps','--all')).instances.length,0,'Stop own runtime before restoring');
await rm(target,{recursive:true,force:true});
await cp(`${output}/original-lighting`,target,{recursive:true});
await cp(`${output}/original-baker.gd`,`${rogue}/tools/maps/study/native/baker.gd`);
const original=JSON.parse(await readFile(`${target}/bake.json`,'utf8'));
for (const [name,hash] of Object.entries(original.outputs)) {
 const actual=createHash('sha256').update(await readFile(`${rogue}/${name}`)).digest('hex');
 assert.equal(actual,hash,name);
}
await cli(rogue,'project','import');
const check=await execute(process.execPath,[`${rogue}/tools/maps/study/check-lighting.mjs`,'--require-output'],{cwd:rogue,windowsHide:true,maxBuffer:4e6});
await execute('git',['restore','--','scripts/game.ts'],{cwd:fps,windowsHide:true});
await cli(rogue,'session','end','--session',session);
const rogueStatus=await execute('git',['status','--short'],{cwd:rogue,windowsHide:true});
const fpsStatus=await execute('git',['status','--short'],{cwd:fps,windowsHide:true});
const result={restoredAt:new Date().toISOString(),atlasOutputsVerified:Object.keys(original.outputs).length,sourceCheck:check.stdout.trim(),rogueStatus:rogueStatus.stdout,fpsStatus:fpsStatus.stdout};
await writeFile(`${output}/restoration-receipt.json`,JSON.stringify(result,null,2));
console.log(JSON.stringify(result));
