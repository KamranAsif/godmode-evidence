import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {rogue,fps,output,views} from './control.mjs';
const labels=process.argv.slice(2);
const records=[];
for(const label of labels){
 const kind=label.startsWith('fps-')?'fps':'rogue',project=kind==='fps'?fps:rogue;
 const pass=label.slice(kind.length+1);
 const inventory=JSON.parse(await readFile(`${output}/${label}-inventory.json`,'utf8'));
 if(!inventory.accepted || inventory.lightmaps.some(v=>!v.bound || !v.users))throw new Error('Unbound bake '+label);
 for(const view of views[kind]){
  const stem=`${label}-${view.id}`,bytes=await readFile(`${project}/artifacts/lighting-investigation/${stem}.png`);
  const frames=JSON.parse(await readFile(`${output}/${stem}-frames.json`,'utf8'));
  if(bytes.readUInt32BE(16)!==1920||bytes.readUInt32BE(20)!==1080)throw new Error('Resolution '+stem);
  if(frames.engine.headless||frames.engine.maxFps||frames.engine.vsyncMode)throw new Error('Timing conditions '+stem);
  const capture=JSON.parse(await readFile(`${output}/${stem}-capture.json`,'utf8'));
  const pose=capture.action?.result?.insertionPose;
  const audit=capture.action?.result?.auditCamera;
  if (kind==='fps' && (!audit || JSON.stringify(capture.action.result.auditViewportPixels)!=='[1920,1080]')) throw new Error('Native FPS render dimensions '+stem);
  if(view.id!=='gameplay' && audit && (audit.global_position.some((v,i)=>Math.abs(v-view.position[i])>0.002)||Math.abs(audit.fov-view.fov)>0.002)) throw new Error('FPS camera mismatch '+stem);
  if(view.id!=='gameplay'&&pose){
   const actual=pose.cameraGlobal.origin;
   if(actual.some((v,i)=>Math.abs(v-view.position[i])>0.002)||Math.abs(pose.cameraProjection.fov-view.fov)>0.002)throw new Error('Camera mismatch '+stem);
  }
  records.push({label:stem,kind,pass,view:view.id,width:1920,height:1080,sha256:createHash('sha256').update(bytes).digest('hex'),path:`${project}/artifacts/lighting-investigation/${stem}.png`,camera:pose?.cameraGlobal??audit??null,projection:pose?.cameraProjection??(audit?{fov:audit.fov}:null),frames});
 }
}
await writeFile(`${output}/accepted-captures.json`,JSON.stringify(records,null,2));
console.log('Accepted '+records.length+' native 1920x1080 captures');
