import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import dgram from 'node:dgram';
const execute = promisify(execFile);
export const rogue = 'D:/work/godmode-roguelite-worktrees/lighting-vs-fps-20261006';
export const fps = 'D:/work/Godmode.exe-worktrees/lighting-reference-20261006';
export const output = `${rogue}/artifacts/lighting-investigation`;
export const session = 'lighting-investigation-20261006';
export const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
export async function cli(project, ...args) {
    const { stdout } = await execute(process.execPath,[`${project}/tools/godot-cli/dist/src/index.js`,...args,...(args.includes('--all')||args[0]==='session'?[]:['--project',project]),'--json'],{
        cwd:project,windowsHide:true,timeout:900000,maxBuffer:50e6,
        env:{...process.env,GODMODE_SESSION_ID:session,GODMODE_PREBUILT_GENERATING:'1',GODMODE_LIGHTING_SINGLE_PROCESS:project===fps?'1':'',GODMODE_LIGHTING_AUDIT_PORT:process.env.GODMODE_LIGHTING_AUDIT_PORT??'55837'}
    });
    const result = JSON.parse(stdout);
    if (!result.ok) throw new Error(JSON.stringify(result));
    return result.data;
}
export const action = async (project,instance,name,payload={},refused=false) => { const value=await cli(project,'runtime','action','--instance',instance,'--name',name,'--payload',JSON.stringify(payload),...(refused?['--allow-refused']:[])); if (name.startsWith('investigation_') && value.result?.accepted!==true) throw new Error('Audit override failed: '+JSON.stringify(value.result)); return value; };
export const store = async (project,instance) => (await cli(project,'runtime','inspect','--instance',instance,'--store-only')).store;
export const save = async (name,data) => { await mkdir(output,{recursive:true});await writeFile(`${output}/${name}.json`,JSON.stringify(data,null,2)+'\n'); };
export async function ready(project,instance) {
    const deadline = Date.now()+300000;
    while (Date.now()<deadline) {
        try {
            const value = await store(project,instance);
            if (value?.loadoutPickOpen) await action(project,instance,'loadout_pick_confirm',{});
            if (value?.snapshot?.players?.some(p=>p.id===value.localPeerId) && !value.loadoutPickOpen) return value;
        } catch (error) { if (Date.now()+5000>deadline) throw error; }
        await delay(1000);
    }
    throw new Error('Gameplay did not become ready');
}
export async function capture(project,instance,label) {
    const file = `${project}/artifacts/lighting-investigation/${label}.png`;
    const receipt = await cli(project,'game','capture','--instance',instance,'--output',file,...(project===rogue?['--allow-unchecked']:[]));
    const bytes = await readFile(file);
    if (bytes.readUInt32BE(16)!==1920 || bytes.readUInt32BE(20)!==1080) throw new Error(`Wrong resolution: ${file}`);
    await save(`${label}-capture`,receipt);
    return file;
}
export async function launch(project,instance) {
    if (project===fps) {
        const socket = dgram.createSocket('udp4');
        await new Promise(resolve=>socket.bind(0,'127.0.0.1',resolve));
        process.env.GODMODE_LIGHTING_AUDIT_PORT = String(socket.address().port);
        socket.close();
    }
    const peers=await cli(project,'game','ps','--all');
    await save(`${instance}-peers`,peers);
    if (peers.instances?.length) throw new Error('Another managed engine is running: '+JSON.stringify(peers.instances.map(v=>({instance:v.instance,pid:v.pid}))));
    return cli(project,'game','run','--instance',instance,'--session',session,'--scene','res://artifacts/lighting-investigation/audit.tscn','--inspect','--allow-actions',
        ...(project===rogue?['--fixture','roguelite','--offscreen','--offscreen-size','1920x1080']:['--category','assault']));
}
export const stop = (project,instance) => cli(project,'game','stop','--instance',instance);
export const views = {
    rogue:[
        {id:'outdoor',position:[-402,-15.5820005417,-392],yaw:0,pitch:0,fov:75},
        {id:'covered',position:[-542.946,-15.774,-361.28],yaw:-1.5708,pitch:0,fov:75},
        {id:'contact',position:[-400,-15.582,-399],yaw:-1.1,pitch:-0.5,fov:75},
        {id:'gameplay',position:[-406.027852,-15.60,-384.99851],yaw:0,pitch:0,fov:75}
    ],
    fps:[
        {id:'outdoor',position:[0,9,50],yaw:0,pitch:0.1,fov:75},
        {id:'covered',position:[-6.31,1.65,11.73],yaw:0,pitch:0.06,fov:75},
        {id:'contact',position:[-6.86,6.65,-11.73],yaw:0,pitch:-0.28,fov:75},
        {id:'gameplay',position:[-6.31,6.65,27.02],yaw:0,pitch:0.13,fov:75}
    ]
};
if (process.argv[2]==='launch') {
    const project = process.argv[3]==='fps'?fps:rogue;
    const instance = process.argv[3]==='fps'?'lighting-fps':'lighting-rogue';
    console.log(JSON.stringify(await launch(project,instance)));
}
