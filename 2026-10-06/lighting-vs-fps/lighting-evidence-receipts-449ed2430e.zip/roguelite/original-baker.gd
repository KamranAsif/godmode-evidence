@tool
extends EditorPlugin

# LightmapGI.bake is editor-only and not script-bound in the pinned engine.
# Keep this small adapter on the matching official 4.6.1 editor; the game stays TS.
const LIGHTMAP_TEXEL_SIZE := 1.0
const OUTPUT := "res://assets/maps/sands_pearl/lighting/"
var room: Node3D
var stage := "starting"
var bindings := {}
var transforms := {}
var unique_meshes := 0
var groups := {}
var triangle_count := 0
var expected_users := 0
var degenerate_triangles := 0
var lod_count := 0
var stage_request := {}

func _enter_tree() -> void:
    # Audit/version baking must not cover the user's desktop.
    DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
    DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS, true)
    DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_NO_FOCUS, true)
    DisplayServer.window_set_position(Vector2i(-10000, -10000))
    if FileAccess.file_exists("res://bake-complete.json"):
        return
    if FileAccess.file_exists("res://prepare-complete.json"):
        if not FileAccess.file_exists("res://stage-request.json"):
            fail("Missing STUDY native stage request")
            return
        var request = JSON.parse_string(FileAccess.get_file_as_string("res://stage-request.json"))
        if not (request is Dictionary) or not request.has("phase"):
            fail("Invalid STUDY native stage request")
            return
        stage_request = request
        var report = JSON.parse_string(FileAccess.get_file_as_string("res://prepare-complete.json"))
        expected_users = report.staticMeshes
        unique_meshes = report.uniqueMeshes
        triangle_count = report.placedTriangles
        degenerate_triangles = report.degenerateTrianglesRemoved
        lod_count = report.lods
        open_prepared.call_deferred()
    else:
        prepare.call_deferred()

func open_prepared() -> void:
    EditorInterface.open_scene_from_path("res://prepared.scn")
    stage = "opening"
    set_process(true)

func collect(node: Node) -> void:
    if node is MeshInstance3D and node.mesh != null and node.gi_mode == GeometryInstance3D.GI_MODE_STATIC:
        # A shared unit box may be a tiny window frame or an 80 m slab.
        # Sharing UV density across those scales gives every frame the slab's atlas budget.
        var scale = node.global_transform.basis.get_scale().abs()
        var texel_size = float(node.get_meta("lightmapTexelSizeMeters", LIGHTMAP_TEXEL_SIZE))
        var key = str(node.mesh.get_instance_id()) + ":" + str(scale) + ":" + str(texel_size)
        if not groups.has(key):
            groups[key] = {"source": node.mesh, "scale": Vector3.ZERO, "texelSize": texel_size, "nodes": []}
        var group = groups[key]
        group.scale = group.scale.max(scale)
        group.nodes.append(node)
        expected_users += 1
    for child in node.get_children():
        collect(child)

func triangles(mesh: Mesh) -> int:
    var count := 0
    for surface in range(mesh.get_surface_count()):
        var arrays = mesh.surface_get_arrays(surface)
        var indices = arrays[Mesh.ARRAY_INDEX]
        count += (indices.size() if indices != null and not indices.is_empty() else arrays[Mesh.ARRAY_VERTEX].size()) / 3
    return count

# Godot's xatlas adapter rejects edges shorter than sqrt(FLT_EPSILON).
# Count those exact triangles separately; any other topology loss fails the bake.
func unwrap_triangles(mesh: Mesh, scale: Vector3) -> int:
    var count := 0
    for surface in range(mesh.get_surface_count()):
        var arrays = mesh.surface_get_arrays(surface)
        var vertices = arrays[Mesh.ARRAY_VERTEX]
        var indices = arrays[Mesh.ARRAY_INDEX]
        if indices == null or indices.is_empty():
            indices = range(vertices.size())
        for face in range(0, indices.size(), 3):
            var a: Vector3 = vertices[indices[face]] * scale
            var b: Vector3 = vertices[indices[face + 1]] * scale
            var c: Vector3 = vertices[indices[face + 2]] * scale
            if (a - b).length_squared() >= 1.19209290e-7 and (b - c).length_squared() >= 1.19209290e-7 and (c - a).length_squared() >= 1.19209290e-7:
                count += 1
    return count

func prepare() -> void:
    var version = Engine.get_version_info()
    if version.major != 4 or version.minor != 6 or version.patch != 1 or version.build != "official":
        fail("STUDY native bake requires official Godot 4.6.1")
        return
    DirAccess.make_dir_recursive_absolute(OUTPUT + "meshes")
    room = load("res://source.scn").instantiate()
    get_tree().root.add_child(room)
    var shader_parameters: Array = []
    restore_shader_parameters(room, shader_parameters)
    FileAccess.open("res://shader-parameters-restored.json", FileAccess.WRITE).store_string(JSON.stringify(shader_parameters, "  "))
    collect(room)
    var source_report = JSON.parse_string(FileAccess.get_file_as_string("res://source-report.json"))
    if expected_users != source_report.staticMeshes:
        fail("Export changed mesh count: %s -> %s" % [source_report.staticMeshes, expected_users])
        return
    # Runtime binding paths are relative to DumboSurvivalArena, not the exported
    # DumboBake scene root. This keeps the live and native hierarchies aligned.
    var map = room.get_node("DumboSurvivalArena")
    var index := 0
    for group in groups.values():
        var source: Mesh = group.source
        var mesh: ArrayMesh
        if source is ArrayMesh:
            mesh = source.duplicate()
        else:
            mesh = ArrayMesh.new()
            for surface in range(source.get_surface_count()):
                mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, source.surface_get_arrays(surface))
                mesh.surface_set_material(surface, source.surface_get_material(surface))
        var source_hashes := PackedInt64Array()
        for surface in range(source.get_surface_count()):
            var source_arrays = source.surface_get_arrays(surface)
            # Imported normal/tangent rounding varies between ARM and x86.
            # Fingerprint stable geometry/UV channels; source files are hashed too.
            source_arrays[Mesh.ARRAY_NORMAL] = null
            source_arrays[Mesh.ARRAY_TANGENT] = null
            source_hashes.append(hash(source_arrays))
        var before = triangles(mesh)
        var expected = unwrap_triangles(mesh, group.scale)
        print("STUDY_UNWRAP=%s triangles=%s placements=%s" % [index, before, group.nodes.size()])
        var error = mesh.lightmap_unwrap(Transform3D(Basis.from_scale(group.scale), Vector3.ZERO), group.texelSize)
        if error != OK or triangles(mesh) != expected or mesh.get_surface_count() != source.get_surface_count():
            fail("UV2 generation failed: mesh=%s node=%s error=%s triangles=%s->%s surfaces=%s->%s" % [index, room.get_path_to(group.nodes[0]), error, before, triangles(mesh), source.get_surface_count(), mesh.get_surface_count()])
            return
        degenerate_triangles += (before - expected) * group.nodes.size()
        # Unwrap rebuilds the index arrays, invalidating the imported LOD indices.
        # Follow the stock importer: rebuild distance LODs, retaining the full-detail mesh.
        var importer = ImporterMesh.from_mesh(mesh)
        importer.generate_lods(20.0, 0.0, [])
        for surface in range(importer.get_surface_count()):
            lod_count += importer.get_surface_lod_count(surface)
        var size_hint = mesh.lightmap_size_hint
        mesh = importer.get_mesh()
        mesh.lightmap_size_hint = size_hint
        # Imported optimized shadow streams lose their vertex data in the
        # exported bake scene. Cast from the valid derived geometry instead.
        mesh.shadow_mesh = null
        if triangles(mesh) != expected:
            fail("LOD generation changed base mesh topology")
            return
        # Preserve the live materials on nodes; UV2 resources contain geometry only.
        for node in group.nodes:
            for surface in range(source.get_surface_count()):
                node.set_surface_override_material(surface, node.get_active_material(surface))
        for surface in range(mesh.get_surface_count()):
            mesh.surface_set_material(surface, null)
        mesh.set_meta("sourceSurfaceHashes", source_hashes)
        var mesh_path = OUTPUT + "meshes/mesh_%03d.res" % index
        if ResourceSaver.save(mesh, mesh_path, ResourceSaver.FLAG_COMPRESS) != OK:
            fail("Could not save UV2 mesh " + mesh_path)
            return
        mesh.take_over_path(mesh_path)
        for node in group.nodes:
            node.mesh = mesh
            bindings[str(map.get_path_to(node))] = mesh
            transforms[str(map.get_path_to(node))] = map.global_transform.affine_inverse() * node.global_transform
            triangle_count += expected
        index += 1
    var binding_resource = Resource.new()
    binding_resource.set_meta("regions", source_report.regions)
    binding_resource.set_meta("meshes", bindings)
    binding_resource.set_meta("transforms", transforms)
    ResourceSaver.save(binding_resource, OUTPUT + "mesh_bindings.tres")
    var lightmap: LightmapGI = room.get_node("DumboSurvivalArena/StudyLightmap")
    lightmap.light_data = LightmapGIData.new()
    ResourceSaver.save(lightmap.light_data, OUTPUT + "study_lightmap.lmbake")
    lightmap.light_data.take_over_path(OUTPUT + "study_lightmap.lmbake")
    var scene = PackedScene.new()
    scene.pack(room)
    ResourceSaver.save(scene, "res://prepared.scn", ResourceSaver.FLAG_COMPRESS)
    room.free()
    # Stop here so the CLI can import the generated resources in a fresh editor pass.
    # The mesh files index the output directory. Do not pre-import a tiny EXR:
    # its uncompressed preset would override the lightmapper's VRAM default.
    var report = {"staticMeshes": expected_users, "uniqueMeshes": groups.size(),
        "placedTriangles": triangle_count, "degenerateTrianglesRemoved": degenerate_triangles, "lods": lod_count}
    FileAccess.open("res://prepare-complete.json", FileAccess.WRITE).store_string(JSON.stringify(report))
    stage = "prepared"

func _process(_delta: float) -> void:
    if stage == "selected_lightmap":
        stage = "baking"
        bake_lightmap()
    elif stage == "opening":
        room = EditorInterface.get_edited_scene_root()
        if room != null and room.scene_file_path == "res://prepared.scn":
            if stage_request.get("phase", "") == "lightmap":
                EditorInterface.edit_node(room.get_node("DumboSurvivalArena/StudyLightmap"))
                stage = "selected_lightmap"
            else:
                fail("Unknown STUDY native stage: " + JSON.stringify(stage_request))

func find_baker(node: Node) -> Node:
    if node.is_class("LightmapGIEditorPlugin") and node.has_method("_bake"):
        return node
    for child in node.get_children():
        var found = find_baker(child)
        if found != null:
            return found
    return null

var last_reimport_msec := 0

func note_reimport(_resources = null) -> void:
    last_reimport_msec = Time.get_ticks_msec()

func importer_idle() -> bool:
    # The pinned editor has no is_importing(); a queued reimport ends with resources_reimported.
    var filesystem = EditorInterface.get_resource_filesystem()
    if not filesystem.resources_reimported.is_connected(note_reimport):
        filesystem.resources_reimported.connect(note_reimport)
    var started := Time.get_ticks_msec()
    while true:
        var now := Time.get_ticks_msec()
        if now - started > 300000:
            return false
        if not filesystem.is_scanning() and now - started > 15000 and now - last_reimport_msec > 5000:
            return true
        await get_tree().process_frame
    return false

func bake_lightmap() -> void:
    var native_baker = find_baker(get_tree().root)
    if native_baker == null:
        fail("Pinned LightmapGI editor hook not found")
        return
    if not await environment_ready():
        fail("SCENE bake environment did not settle; inspect bake-environment-proof.json")
        return
    var texels := 0
    var hero_texels := 0
    var hero_meshes := 0
    for node in room.find_children("*", "MeshInstance3D", true, false):
        if node.gi_mode == GeometryInstance3D.GI_MODE_STATIC:
            var hint = node.mesh.lightmap_size_hint
            texels += hint.x * hint.y
            if float(node.get_meta("lightmapTexelSizeMeters", LIGHTMAP_TEXEL_SIZE)) < LIGHTMAP_TEXEL_SIZE:
                hero_texels += hint.x * hint.y
                hero_meshes += 1
    print("STUDY_TEXEL_BUDGET=" + str(texels))
    # Opening the scene lets the importer notice textures used in 3D and queue their reimport. The bake
    # saves its atlas through reimport_files(), which fails while another import runs, so wait for quiet.
    if not await importer_idle():
        fail("Editor imports did not settle before the lightmap bake")
        return
    print("STUDY_BAKE_STAGE=lightmap")
    native_baker.call("_bake")
    await get_tree().process_frame
    var lightmap: LightmapGI = room.get_node("DumboSurvivalArena/StudyLightmap")
    if lightmap.light_data == null or lightmap.light_data.get_user_count() != expected_users:
        var dialogs: Array = []
        visible_bake_dialogs(get_tree().root, dialogs)
        var hints: Array = []
        for node in room.find_children("*", "MeshInstance3D", true, false):
            if node.gi_mode == GeometryInstance3D.GI_MODE_STATIC:
                hints.append({"path": str(node.get_path()), "size": str(node.mesh.lightmap_size_hint), "area": node.mesh.lightmap_size_hint.x * node.mesh.lightmap_size_hint.y})
        hints.sort_custom(func(a, b): return a.area > b.area)
        var diagnostics = {"dialogs": dialogs, "maxTextureSize": lightmap.max_texture_size, "denoiserRange": lightmap.denoiser_range, "largestMeshHints": hints.slice(0, 12)}
        var report = FileAccess.open("res://bake-failure-diagnostics.json", FileAccess.WRITE)
        report.store_string(JSON.stringify(diagnostics, "  "))
        report.close()
        fail("Lightmap users: expected %s, got %s. Native editor: %s" % [expected_users, lightmap.light_data.get_user_count() if lightmap.light_data != null else 0, JSON.stringify(dialogs)])
        return
    var atlas_textures: Array = []
    for texture in lightmap.light_data.lightmap_textures:
        atlas_textures.append({"width": texture.get_width(), "height": texture.get_height(), "layers": texture.get_layers()})
    var receipt = {"engine": Engine.get_version_info().string, "texelSizeMeters": LIGHTMAP_TEXEL_SIZE, "maxTextureSize": lightmap.max_texture_size, "denoiserRange": lightmap.denoiser_range,
        "lightmappedMeshes": lightmap.light_data.get_user_count(), "probeCount": RenderingServer.lightmap_get_probe_capture_points(lightmap.light_data.get_rid()).size(), "uniqueMeshes": unique_meshes, "requestedTexels": texels,
        "heroTexelSizeMeters": 0.5, "heroMeshes": hero_meshes, "heroRequestedTexels": hero_texels,
        "atlasTextures": atlas_textures,
        "placedTriangles": triangle_count, "degenerateTrianglesRemoved": degenerate_triangles, "lods": lod_count}
    var file = FileAccess.open("res://lightmap-complete.json", FileAccess.WRITE)
    file.store_string(JSON.stringify(receipt))
    file.close()
    print("STUDY_LIGHTMAP=" + JSON.stringify(receipt))
    stage = "complete"

func restore_shader_parameters(node: Node, receipt: Array) -> void:
    var materials: Array = []
    if node is MeshInstance3D:
        for surface in node.mesh.get_surface_count() if node.mesh != null else 0:
            materials.append(node.get_active_material(surface))
    if node is WorldEnvironment and node.environment != null and node.environment.sky != null:
        materials.append(node.environment.sky.sky_material)
    for material in materials:
        if not (material is ShaderMaterial) or not material.has_meta("studyBakeShaderParameters"): continue
        var parameters = JSON.parse_string(material.get_meta("studyBakeShaderParameters"))
        var types = {}
        for property in material.shader.get_shader_uniform_list(): types[property.name] = property.type
        var restored = {}
        for name in parameters:
            var item = parameters[name]
            var value = item.value
            match item.kind:
                "color": value = Color(value[0],value[1],value[2],value[3])
                "vector2": value = Vector2(value[0],value[1])
                "vector3": value = Vector3(value[0],value[1],value[2])
                "basis", "transform":
                    var basis = Basis(Vector3(value[0][0],value[0][1],value[0][2]),Vector3(value[1][0],value[1][1],value[1][2]),Vector3(value[2][0],value[2][1],value[2][2]))
                    value = Transform3D(basis,Vector3(value[3][0],value[3][1],value[3][2])) if item.kind == "transform" else basis
                "scalar":
                    if types.get(name) == TYPE_INT: value = int(value)
            material.set_shader_parameter(name,value)
            restored[name] = str(material.get_shader_parameter(name))
        receipt.append({"path":str(room.get_path_to(node)),"parameters":parameters,"actual":restored})
    for child in node.get_children(): restore_shader_parameters(child,receipt)

func environment_ready() -> bool:
    var lightmap = room.get_node("DumboSurvivalArena/StudyLightmap") as LightmapGI
    var environment = lightmap.get_world_3d().environment
    if environment == null: return false
    var samples: Array = []
    var previous = Vector3.ZERO
    var stable = 0
    for frame in range(1,121):
        await get_tree().process_frame
        var image = RenderingServer.environment_bake_panorama(environment.get_rid(),true,Vector2i(128,64))
        if image == null or image.is_empty(): continue
        var total = Vector3.ZERO
        var maximum = Vector3.ZERO
        for y in image.get_height():
            for x in image.get_width():
                var c = image.get_pixel(x,y)
                var rgb = Vector3(c.r,c.g,c.b)
                total += rgb
                maximum = maximum.max(rgb)
        var mean = total/(image.get_width()*image.get_height())
        var delta = (mean-previous).length()/maxf(previous.length(),0.0001)
        stable = stable+1 if frame >= 5 and mean.length()>0.0001 and delta<0.001 else 0
        samples.append({"frame":frame,"meanLinear":[mean.x,mean.y,mean.z],"maxLinear":[maximum.x,maximum.y,maximum.z],"relativeDelta":delta})
        previous = mean
        if stable >= 3: break
    var sky_material = environment.sky.sky_material if environment.sky != null else null
    var gain = sky_material.get_shader_parameter("radiance_energy") if sky_material is ShaderMaterial else null
    var proof = {"ready":stable>=3,"environmentMode":lightmap.environment_mode,"ambientMode":environment.ambient_light_source,"ambientEnergy":environment.ambient_light_energy,"skyMix":environment.ambient_light_sky_contribution,"backgroundEnergy":environment.background_energy_multiplier,"exposure":environment.tonemap_exposure,"radianceGain":gain,"samples":samples}
    FileAccess.open("res://bake-environment-proof.json",FileAccess.WRITE).store_string(JSON.stringify(proof,"  "))
    if sky_material is ShaderMaterial and sky_material.has_meta("studyBakeShaderParameters"):
        var expected = JSON.parse_string(sky_material.get_meta("studyBakeShaderParameters"))
        if expected.has("radiance_energy") and gain != expected.radiance_energy.value: return false
    return stable >= 3

func visible_bake_dialogs(node: Node, dialogs: Array) -> void:
    if node is AcceptDialog and node.visible and not node.dialog_text.is_empty():
        dialogs.append({"class": node.get_class(), "text": node.dialog_text})
    for child in node.get_children():
        visible_bake_dialogs(child, dialogs)

func fail(message: String) -> void:
    stage = "failed"
    push_error(message)
    var file = FileAccess.open("res://bake-error.txt", FileAccess.WRITE)
    file.store_string(message)
    file.close()
