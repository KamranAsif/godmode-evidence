extends Node3D

var client: Node
var server: Node
var pinned: Dictionary = {}
var saved_fill: Dictionary = {}
var sun: DirectionalLight3D
var environment: Environment

func _ready() -> void:
    process_priority = 1000
    if OS.get_environment("GODMODE_LIGHTING_SINGLE_PROCESS") == "1":
        var host_view := SubViewport.new()
        host_view.name = "ServerViewport"
        host_view.own_world_3d = true
        host_view.size = Vector2i(16,16)
        host_view.render_target_update_mode = SubViewport.UPDATE_DISABLED
        add_child(host_view)
        var server_root := Node3D.new()
        server_root.name = "Server"
        host_view.add_child(server_root)
        get_tree().set_multiplayer(SceneMultiplayer.new(),server_root.get_path())
        server = load("res://scenes/main.tscn").instantiate()
        server.set_meta("lightingAuditServer",true)
        server_root.add_child(server)
        var client_root := Node3D.new()
        client_root.name = "Client"
        add_child(client_root)
        get_tree().set_multiplayer(SceneMultiplayer.new(),client_root.get_path())
        client = load("res://scenes/main.tscn").instantiate()
        client_root.add_child(client)
    else:
        client = load("res://scenes/main.tscn").instantiate()
        add_child(client)
    DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
    DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS,true)
    DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_NO_FOCUS,true)
    DisplayServer.window_set_size(Vector2i(1920,1080))
    DisplayServer.window_set_position(Vector2i(-10000,-10000))
    DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
    Engine.max_fps = 0

func _process(_delta: float) -> void:
    if client != null and client.has_meta("godot_cli_state"):
        set_meta("godot_cli_state",client.get_meta("godot_cli_state"))
    if not pinned.is_empty():
        var camera := get_viewport().get_camera_3d()
        if camera != null:
            camera.global_position = Vector3(pinned.position[0],pinned.position[1],pinned.position[2])
            camera.rotation = Vector3(pinned.pitch,pinned.yaw,0)
            camera.fov = pinned.get("fov",75)

func json_value(value: Variant) -> Variant:
    if value is Color: return [value.r,value.g,value.b,value.a]
    if value is Vector3: return [value.x,value.y,value.z]
    if value is Vector2 or value is Vector2i: return [value.x,value.y]
    if value is Resource: return {"class":value.get_class(),"path":value.resource_path}
    return value

func properties(object: Object, names: Array) -> Dictionary:
    var result := {}
    for key in names: result[key] = json_value(object.get(key))
    return result

func inventory() -> Dictionary:
    var worlds := client.find_children("*","WorldEnvironment",true,false)
    var suns := client.find_children("*","DirectionalLight3D",true,false)
    if worlds.is_empty() or suns.is_empty(): return {"accepted":false,"error":"lighting not ready"}
    environment = worlds[0].environment
    sun = suns[0]
    var env_keys := ["tonemap_mode","tonemap_exposure","tonemap_white","background_energy_multiplier","ambient_light_source","ambient_light_energy","ambient_light_color","ambient_light_sky_contribution","reflected_light_source","glow_enabled","glow_intensity","glow_strength","glow_normalized","glow_bloom","glow_hdr_threshold","ssao_enabled","ssao_radius","ssao_intensity","ssao_power","ssao_detail","ssao_light_affect","ssao_ao_channel_affect","ssao_sharpness","ssil_enabled","ssil_radius","ssil_intensity","ssr_enabled","ssr_max_steps","sdfgi_enabled","fog_enabled","fog_density","fog_sky_affect","fog_aerial_perspective","volumetric_fog_enabled","volumetric_fog_density","volumetric_fog_length","adjustment_enabled","adjustment_brightness","adjustment_contrast","adjustment_saturation"]
    var sun_keys := ["light_bake_mode","shadow_enabled","directional_shadow_mode","directional_shadow_max_distance","directional_shadow_split_1","directional_shadow_split_2","directional_shadow_split_3","directional_shadow_blend_splits","directional_shadow_fade_start","light_energy","light_indirect_energy","light_color","light_specular","light_angular_distance","shadow_opacity","shadow_bias","shadow_normal_bias","shadow_blur","rotation_degrees"]
    var maps := []
    for lm in client.find_children("*","LightmapGI",true,false):
        var data := properties(lm,["quality","bounces","bounce_indirect_energy","texel_scale","use_denoiser","denoiser_strength","denoiser_range","directional","use_texture_for_bounces","environment_mode","environment_custom_energy","max_texture_size","generate_probes_subdiv"])
        data.path = str(lm.get_path())
        data.users = lm.light_data.get_user_count() if lm.light_data != null else 0
        data.bound = lm.light_data != null
        maps.append(data)
    var meshes := []
    for mesh in client.find_children("*","MeshInstance3D",true,false):
        if mesh.mesh == null or mesh.name == "ViewmodelShadow": continue
        var aabb: AABB = mesh.get_aabb()
        var size: Vector3 = aabb.size * mesh.global_basis.get_scale().abs()
        if mesh.gi_mode == GeometryInstance3D.GI_MODE_STATIC or meshes.size() < 100:
            var materials := []
            for s in mesh.mesh.get_surface_count():
                var mat = mesh.get_active_material(s)
                if mat is StandardMaterial3D:
                    materials.append(properties(mat,["resource_name","albedo_color","roughness","metallic","metallic_specular","emission_enabled","emission_energy_multiplier"]))
                elif mat is ShaderMaterial:
                    var fields := {"name":mat.resource_name,"shader":mat.shader.resource_path}
                    for entry in mat.shader.get_shader_uniform_list():
                        if str(entry.name) in ["base_color","shade_fill","shade_fill_color","surface_roughness","ground_specular","wall_roughness_low","structure_ambient_strength"]:
                            fields[entry.name] = json_value(mat.get_shader_parameter(entry.name))
                    materials.append(fields)
            meshes.append({"path":str(mesh.get_path()),"gi":mesh.gi_mode,"hint":json_value(mesh.mesh.lightmap_size_hint),"sizeMeters":json_value(size),"centerMeters":json_value(mesh.global_transform * aabb.get_center()),"texelSizeMetadata":mesh.get_meta("lightmapTexelSizeMeters") if mesh.has_meta("lightmapTexelSizeMeters") else null,"materials":materials})
    var sky := environment.sky.sky_material if environment.sky != null else null
    var sky_values := {"class":sky.get_class() if sky != null else null}
    if sky is ShaderMaterial:
        for entry in sky.shader.get_shader_uniform_list(): sky_values[entry.name] = json_value(sky.get_shader_parameter(entry.name))
    elif sky is ProceduralSkyMaterial: sky_values.merge(properties(sky,["sky_energy_multiplier","ground_energy_multiplier","sky_top_color","sky_horizon_color"]))
    var camera := get_viewport().get_camera_3d()
    return {"accepted":true,"environment":properties(environment,env_keys),"sun":properties(sun,sun_keys),"lightmaps":maps,"voxels":client.find_children("*","VoxelGI",true,false).map(func(v): return {"path":str(v.get_path()),"bound":v.data != null,"energy":v.data.energy if v.data != null else null}),"voxelCount":client.find_children("*","VoxelGI",true,false).size(),"reflectionProbeCount":client.find_children("*","ReflectionProbe",true,false).size(),"sky":sky_values,"meshes":meshes,"camera":properties(camera,["global_position","rotation","fov"]) if camera != null else null,"physicalViewportPixels":json_value(get_viewport().get_texture().get_size()),"physicalWindowPixels":json_value(DisplayServer.window_get_size()),"logicalCanvasSize":json_value(get_viewport().get_visible_rect().size),"viewport":properties(get_viewport(),["msaa_3d","screen_space_aa","use_taa","scaling_3d_scale"])}

func godot_cli_action(request: String) -> String:
    var action: Dictionary = JSON.parse_string(request)
    var payload: Dictionary = action.get("payload",{})
    match action.name:
        "investigation_inventory": return JSON.stringify(inventory())
        "investigation_view":
            pinned = payload if payload.get("pinned",true) else {}
            return JSON.stringify({"accepted":true,"pose":pinned})
        "investigation_server":
            return server.godot_cli_action(JSON.stringify(payload)) if server != null else JSON.stringify({"accepted":false})
        "investigation_toggle":
            if environment == null: inventory()
            for key in payload.get("environment",{}):
                if key in ["ssao_enabled","ssil_enabled","ssil_intensity","ssil_radius","tonemap_mode","tonemap_exposure","ambient_light_energy","adjustment_enabled","ssr_enabled"]:
                    environment.set(key,payload.environment[key])
            for key in payload.get("sun",{}):
                if key in ["light_bake_mode","shadow_enabled","shadow_normal_bias","shadow_bias","shadow_opacity"]: sun.set(key,payload.sun[key])
            if payload.has("shade_fill"):
                for mesh in client.find_children("*","MeshInstance3D",true,false):
                    if mesh.mesh == null: continue
                    for s in mesh.mesh.get_surface_count():
                        var mat = mesh.get_active_material(s)
                        if not mat is ShaderMaterial or not ("faceted-surface" in mat.shader.resource_path or (mat.resource_name.begins_with("FacetedSurface_") and not "Foliage" in mat.resource_name and not ":foliage" in mat.resource_name)): continue
                        if not saved_fill.has(mat): saved_fill[mat] = mat.get_shader_parameter("shade_fill")
                        mat.set_shader_parameter("shade_fill",saved_fill[mat] if str(payload.shade_fill) == "restore" else float(payload.shade_fill))
            return JSON.stringify({"accepted":true,"changed":payload})
    return client.godot_cli_action(request)
