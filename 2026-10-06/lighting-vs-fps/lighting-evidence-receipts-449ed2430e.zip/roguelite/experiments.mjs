import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { rogue,output,action,save,cli,ready } from './control.mjs';
const execute = promisify(execFile);
const reset = {
    environment:{ssao_enabled:true,ssil_enabled:false,ssil_intensity:1,ssil_radius:5,tonemap_mode:3,tonemap_exposure:0.5,ambient_light_energy:1.5,adjustment_enabled:true,ssr_enabled:false},
    sun:{light_bake_mode:2,shadow_enabled:true,shadow_normal_bias:1.4,shadow_bias:0.06,shadow_opacity:0.9},shade_fill:'restore'
};
const options = [
    ['baseline',{}],
    ['fill-zero',{shade_fill:0}],
    ['ambient-prototype',{environment:{ambient_light_energy:0.16}}],
    ['bias-prototype',{sun:{shadow_normal_bias:0.5}}],
    ['ssil-on',{environment:{ssil_enabled:true}}],
    ['ssao-off',{environment:{ssao_enabled:false}}],
    ['filmic-only',{environment:{tonemap_mode:2}}],
    ['tone-prototype',{environment:{tonemap_mode:2,tonemap_exposure:1.6}}],
    ['ssr-on',{environment:{ssr_enabled:true}}],
    ['baseline-repeat',{}]
];
await ready(rogue,'lighting-rogue');
for (const [label,toggle] of options) {
    await action(rogue,'lighting-rogue','investigation_toggle',reset);
    await save(`rogue-${label}-toggle`,await action(rogue,'lighting-rogue','investigation_toggle',toggle));
    console.log(`Testing ${label}`);
    const result = await execute(process.execPath,[`${output}/capture-pass.mjs`,'rogue',label],{cwd:rogue,windowsHide:true,timeout:600000,maxBuffer:2e6});
    console.log(result.stdout.trim());
}
await action(rogue,'lighting-rogue','investigation_toggle',reset);
await save('rogue-final-reset',{reset,lighting:(await action(rogue,'lighting-rogue','debug_lighting')).result});
console.log('Lighting restored to baseline');
