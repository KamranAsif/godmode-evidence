import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { cp,readFile,writeFile,mkdir,access } from 'node:fs/promises';
import { rogue,output,launch,stop,save,cli,ready } from './control.mjs';
const execute=promisify(execFile);
const label=process.argv[2];
if(!['crop-baseline','crop-density'].includes(label))throw new Error('Expected crop-baseline or crop-density');
const crop='-400,-395,25;-543,-361,25';
const directory=`${rogue}/assets/maps/sands_pearl/lighting`;
const baker=`${rogue}/tools/maps/study/native/baker.gd`;
const backup=`${output}/original-lighting`;
try {await access(`${backup}/bake.json`);}catch {
 await cp(directory,backup,{recursive:true});
 await cp(baker,`${output}/original-baker.gd`);
 console.log('Original atlas and baker backed up');
}
if(label==='crop-density'){
 let source=await readFile(`${output}/original-baker.gd`,'utf8');
 source=source.replace('const LIGHTMAP_TEXEL_SIZE := 1.0','const LIGHTMAP_TEXEL_SIZE := 0.5');
 source=source.replace('var key = str(node.mesh.get_instance_id())', '# Audit only: retain 1 m for large shared charts; densify bounded region meshes.\n        var audit_extent: Vector3 = (node.mesh.get_aabb().size * scale).abs()\n        if maxf(audit_extent.x,maxf(audit_extent.y,audit_extent.z)) > 256.0:\n            texel_size = float(node.get_meta("lightmapTexelSizeMeters",1.0))\n        var key = str(node.mesh.get_instance_id())');
 source=source.replace('    native_baker.call("_bake")', '    # Audit helper only: the control retained the native BSP warning log.\n    # Repeated warning backtraces dominate wall time; output data is still validated below.\n    print("AUDIT_NATIVE_BAKE_WARNING_BACKTRACES_SUPPRESSED")\n    Engine.print_error_messages = false\n    native_baker.call("_bake")\n    Engine.print_error_messages = true');
 await writeFile(baker,source);
 await writeFile(`${output}/density-baker.gd`,source);
} else await cp(`${output}/original-baker.gd`,baker);
const started=new Date().toISOString();
console.log('Starting '+label+' native audit bake');
const baked=await execute(process.execPath,[`${rogue}/tools/maps/study/bake-lighting.mjs`,'--crop',crop],{
 cwd:rogue,windowsHide:true,timeout:7200000,maxBuffer:30e6,
 env:{...process.env,GODMODE_PREBUILT_GENERATING:'1'}
});
await writeFile(`${output}/${label}-bake.log`,baked.stdout+'\n'+baked.stderr);
await save(`${label}-bake-receipt`,{started,ended:new Date().toISOString(),manifest:JSON.parse(await readFile(`${directory}/bake.json`,'utf8'))});
await cp(directory,`${output}/${label}-lighting`,{recursive:true});
console.log('Bake complete; launching runtime capture');
process.env.GODMODE_STUDY_CROP=crop;
await launch(rogue,'lighting-rogue');
try{
 await ready(rogue,'lighting-rogue');
 const {stdout}=await execute(process.execPath,[`${output}/capture-pass.mjs`,'rogue',label],{cwd:rogue,windowsHide:true,timeout:900000,maxBuffer:2e6,env:{...process.env,GODMODE_STUDY_CROP:crop}});
 console.log(stdout.trim());
}finally{await stop(rogue,'lighting-rogue');}
