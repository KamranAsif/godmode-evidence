import {execFile} from "node:child_process";
import {promisify} from "node:util";
import {writeFileSync} from "node:fs";
import {setTimeout as delay} from "node:timers/promises";
const execute=promisify(execFile), project="artifacts/check-exports/latest-rope-pack",instance="rope-export-latest";
async function call(args) { const {stdout}=await execute(process.execPath,["tools/godot-cli/dist/src/index.js","--json",...args,"--project",project,"--instance",instance],{env:process.env,maxBuffer:30e6,timeout:60000}); const r=JSON.parse(stdout);if(!r.ok)throw Error(stdout);return r; }
const action=(name,payload)=>call(["runtime","action","--name",name,"--payload",JSON.stringify(payload)]);
await action("debug_insertion_pose",{enabled:false});
await action("debug_console",{run:"insertion rappel"});
await action("debug_console",{run:"invincible on"});
await action("debug_console",{run:"health 100"});
const before=await call(["runtime","inspect","--store-only"]);
await action("debug_console",{lookAt:{yaw:before.data.store.yaw,pitch:1.1}});
await delay(700);
const capture=await call(["game","capture","--output","artifacts/check-exports/rope/rappel-player-looking-up.png"]);
const state=await call(["runtime","inspect","--store-only"]);
writeFileSync("artifacts/check-exports/rope/rappel-player-looking-up.json",JSON.stringify({capture:capture.data,store:state.data.store},null,2));
console.log(JSON.stringify({yaw:state.data.store.yaw,pitch:state.data.store.pitch,insertion:state.data.store.roguelite?.insertion}));
