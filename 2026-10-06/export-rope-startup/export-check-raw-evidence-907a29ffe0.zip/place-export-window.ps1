param([int]$TaskEngineId)
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class ExportWindowPlacement {
    public delegate bool WindowVisitor(IntPtr window, IntPtr data);
    [DllImport("user32.dll")] public static extern bool EnumWindows(WindowVisitor visitor, IntPtr data);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);
    public static IntPtr Find(int processId) {
        IntPtr result = IntPtr.Zero;
        EnumWindows((window, data) => { uint owner; GetWindowThreadProcessId(window, out owner); if(owner == processId) { result = window; return false; } return true; }, IntPtr.Zero);
        return result;
    }
    [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr hWnd, int x, int y, int width, int height, bool repaint);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int command);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr window, IntPtr after, int x, int y, int width, int height, uint flags);
    [StructLayout(LayoutKind.Sequential)] public struct Rect { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr window, out Rect bounds);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr window);
}
'@
$deadline=(Get-Date).AddSeconds(60)
while ((Get-Date) -lt $deadline) {
    $engine=Get-Process -Id $TaskEngineId -ErrorAction SilentlyContinue
    if (-not $engine) { exit 1 }
    $window=[ExportWindowPlacement]::Find($TaskEngineId)
    if ($window -ne [IntPtr]::Zero) {
        # Async placement avoids blocking on the game's loading callback. Keep its 1920x1080 client size.
        [ExportWindowPlacement]::SetWindowPos($window,[IntPtr]::Zero,-10000,-10000,0,0,0x4015) | Out-Null
        Write-Output "EXPORTED_WINDOW_RENDERING_OFFSCREEN_PID=$TaskEngineId"
        $bounds=New-Object ExportWindowPlacement+Rect
        [ExportWindowPlacement]::GetClientRect($window,[ref]$bounds) | Out-Null
        Write-Output "EXPORTED_WINDOW_CLIENT_SIZE=$($bounds.Right-$bounds.Left)x$($bounds.Bottom-$bounds.Top) minimized=$([ExportWindowPlacement]::IsIconic($window))"
        exit 0
    }
    Start-Sleep -Milliseconds 25
}
exit 1
