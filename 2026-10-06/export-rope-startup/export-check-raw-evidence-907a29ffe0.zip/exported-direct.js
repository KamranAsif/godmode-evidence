const { spawn } = require("node:child_process");
const path = require("node:path");
const args = process.argv.slice(2);
if (process.env.GODMODE_MEASURE_VERBOSE === "1") args.unshift("--verbose");
for (const flag of ["--path", "--script"]) {
    const index = args.indexOf(flag);
    if (index >= 0) args.splice(index, 2);
}
const child = spawn(process.env.GODMODE_EXPORTED_BINARY, args, { stdio: "inherit", windowsHide: true });
console.log(`EXPORTED_ADAPTER_CHILD_PID=${child.pid}`);
const placement = spawn("powershell.exe", ["-NoProfile", "-File", path.join(__dirname,"place-export-window.ps1"), String(child.pid)], {stdio:"inherit",windowsHide:true});
child.on("exit", code => { placement.kill(); process.exit(code ?? 1); });
