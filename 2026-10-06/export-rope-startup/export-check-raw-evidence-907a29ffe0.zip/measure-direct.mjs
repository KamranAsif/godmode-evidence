import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import { setTimeout as delay } from "node:timers/promises";
import { freemem, totalmem } from "node:os";
const execute = promisify(execFile);
const [label, argument, pairs = "3", deadlineSeconds = "80"] = process.argv.slice(2);
const root = process.cwd(), binary = path.resolve(argument), project = path.dirname(binary);
const evidence = path.join(root, "artifacts/check-exports", label);
mkdirSync(evidence, {recursive: true});
copyFileSync(path.join(root, "project.godot"), path.join(project, "project.godot"));
const session = process.env.GODMODE_SESSION_ID;
if (!session) throw Error("Session required");
process.env.GODMODE_EXPORTED_BINARY = binary;
async function call(args) {
    const {stdout} = await execute(process.execPath, [path.join(root,"tools/godot-cli/dist/src/index.js"), "--json", ...args], {env:process.env, timeout:120000,maxBuffer:20e6});
    const reply=JSON.parse(stdout); if(!reply.ok) throw Error(stdout); return reply.data;
}
const results=[];
for(let pair=1;pair<=Number(pairs);pair++) {
    writeFileSync(path.join(project,"override.cfg"),`[application]\nconfig/use_custom_user_dir=true\nconfig/custom_user_dir_name="Godot/app_userdata/export-rope-startup/${label}-${pair}"\n[display]\nwindow/size/mode=0\nwindow/size/mode.windows=0\nwindow/size/mode.template=0\nwindow/size/no_focus=true\n`);
    for(const temperature of ["cold","warm"]) {
        const name=`${label}-${pair}-${temperature}`; let started, log="";
        const freeMemoryBytesBefore = freemem(), totalMemoryBytes = totalmem();
        const invoked=performance.now();
        try {
            started=await call(["--godot",path.join(root,"artifacts/check-exports/exported-direct.js"),"game","run","--project",project,"--instance",name,"--session",session,"--offscreen","--offscreen-size","1920x1080","--inspect","--fixture","roguelite"]);
            const end=Date.now()+Number(deadlineSeconds)*1000; let marker=null;
            while(Date.now()<end) {
                const logs=path.join(project,"logs");
                if(existsSync(logs)) log=readdirSync(logs).filter(f=>f.endsWith(".log")).map(f=>readFileSync(path.join(logs,f),"utf8")).find(t=>t.includes(`settings-${name}.cfg`))??log;
                const engineLog=readFileSync(started.logPath,"utf8");
                marker=/GODMODE_FIRST_PRESENTED_GAMEPLAY_FRAME=(\d+)/.exec(log)??(label.startsWith("fixed")?null:/GODMODE_FIRST_GAMEPLAY_FRAME=(\d+)/.exec(log));
                if(marker) break;
                await delay(100);
            }
            const result={name,temperature,pair,gameplayMs:marker?Number(marker[1]):null,readyMs:Number(/GODMODE_FIRST_GAMEPLAY_FRAME=(\d+)/.exec(log)?.[1]??0)||null,timedOut:!marker,deadlineSeconds:Number(deadlineSeconds),observedMs:Math.round(performance.now()-invoked),totalMemoryBytes,freeMemoryBytesBefore,freeMemoryBytesAfter:freemem(),phases:log.split(/\r?\n/).filter(l=>/GODMODE_(ARENA|MOCAP|FIRST_)/.test(l))};
            writeFileSync(path.join(evidence,`${name}.log`),log);
            copyFileSync(started.logPath,path.join(evidence,`${name}-engine.log`));
            results.push(result); writeFileSync(path.join(evidence,"measurements.json"),JSON.stringify(results,null,2)); console.log(JSON.stringify(result));
        } finally {
            if(started) await call(["game","stop","--project",project,"--instance",name]);
            const engineLog=started?.logPath&&existsSync(started.logPath)?readFileSync(started.logPath,"utf8"):"";
            const pid=/client log opened pid=(\d+)/.exec(log)??/EXPORTED_ADAPTER_CHILD_PID=(\d+)/.exec(engineLog);
            if(pid) await execute("taskkill",["/PID",pid[1],"/T","/F"]).catch(()=>{});
        }
        await delay(3000);
    }
}
