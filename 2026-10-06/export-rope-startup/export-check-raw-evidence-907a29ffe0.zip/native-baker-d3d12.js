const { spawnSync } = require("node:child_process");
const child = spawnSync("C:/Godot/Godot_v4.6.1-stable_win64_console.exe", ["--rendering-driver", "d3d12", ...process.argv.slice(2)], { stdio: "inherit", windowsHide: true });
process.exit(child.status ?? 1);
