import {execFile} from "node:child_process";
import {promisify} from "node:util";
import {mkdirSync,writeFileSync} from "node:fs";
import {setTimeout as delay} from "node:timers/promises";
const execute=promisify(execFile);
const project="artifacts/check-exports/latest-rope-pack", instance="rope-export-latest";
const directory="artifacts/check-exports/rope";mkdirSync(directory,{recursive:true});
async function call(args) {
    const {stdout}=await execute(process.execPath,["tools/godot-cli/dist/src/index.js","--json",...args,"--project",project,"--instance",instance],{env:process.env,timeout:120000,maxBuffer:30e6});
    const reply=JSON.parse(stdout);if(!reply.ok)throw Error(stdout);return reply;
}
async function action(name,payload) {
    return call(["runtime","action","--name",name,"--payload",JSON.stringify(payload)]);
}
// Stage on the open waterfront before invoking the ordinary return selector.
await action("debug_console",{invincible:true,killEnemies:true,run:"timescale 1"});
await action("debug_console",{run:"tp -504.021484375 -15.9482421875 -406.138671875",lookAt:{yaw:-Math.PI/2,pitch:0}});
await delay(600);
await action("debug_console",{run:"timescale 0.05"});
await action("debug_console",{run:"insertion rappel"});
await action("debug_console",{run:"invincible on",killEnemies:true});
await action("debug_console",{run:"health 100"});
await action("debug_insertion_pose",{elapsedMs:1300,view:"firstPerson",clay:false});
await action("debug_console",{run:"timescale 1"});
await delay(6000);
await action("debug_console",{run:"timescale 0.05"});
for(const view of ["firstPerson","overview","side"]) {
    await action("debug_insertion_pose",{elapsedMs:1300,view,clay:false});
    await delay(800);
    const output=`${directory}/rappel-${view}.png`;
    const capture=await call(["game","capture","--output",output]);
    const state=await call(["runtime","inspect","--store-only"]);
    writeFileSync(`${directory}/rappel-${view}.json`,JSON.stringify({capture:capture.data,store:state.data.store},null,2));
    console.log(JSON.stringify({view,output,insertion:state.data.store?.roguelite?.insertion}));
}
