extends SceneTree

# Full inspection must include every node, including actors and UI added after
# a large map. Poll /inspect?store=1 when only state is needed.
const MAX_HEADER_BYTES := 8192
const MAX_REQUEST_BYTES := 65536

# Actions whose caller has to read the scene as it stood in the very bridge
# turn that ran them, and so are answered with a full node snapshot as well as
# their result. `capture` force-draws a frame and its evidence is measured on
# that exact frame rather than on a later polling sample; `debug_showcase_pose`
# drives an animation and is read back the same way.
#
# Every other action gets its result and the store only. Serializing the whole
# node tree is not free on the game's own main thread: a client's is ~600 KB
# and ~105 ms, and a suite driving `input` in a tight loop used to hold that
# client at ~10 fps instead of ~140 — time taken from the very frames a
# presentation test is trying to sample. `debug_event_log` paid it too, on a
# reply whose whole point was to be cheap enough to poll. See issue #178.
const SNAPSHOT_ACTIONS: Array[String] = ["capture", "debug_showcase_pose"]

# Frame-time capture (issue #280).
#
# Nothing in this repository could measure what a frame costs, so every
# performance judgement in it -- unshadowed real-time lights, an 8192
# directional shadow map, ~50k triangles a body, six live character
# SubViewports, no occlusion culling -- was an assumption.
#
# It has to be counted here rather than sampled from outside, for the same
# reason `presentation.prediction` counts its own frames: an external poller
# cannot sample faster than the game draws, so it would measure itself. This
# script *is* the client's main loop when a run is started with `--inspect`
# (see `startGodot`), so `_process` below is that client's idle frame and its
# `delta` is the frame time, whatever scene is loaded and whichever role the
# process is playing.
#
# Raw samples rather than a histogram or a running summary, so the percentiles
# are exact and the arithmetic lives in TypeScript where it is cheap to unit
# test (`summarizeFrameTimes`). Recording one is a clock read, a store and an
# increment; the array is sized once and never grows. The samples are
# serialised only when `GET /frames` asks for them, never on the store or
# snapshot path.
#
# The interval between frames is timed here rather than taken from the `delta`
# the engine passes in, and that is not a stylistic choice. On a real rendering
# client under load, measured on the car_garage graybox, the idle deltas summed
# to about 54% of the wall-clock time the same frames took: 23 frames reporting
# 133 ms each across a window that really lasted 5.7 seconds. Reporting those
# deltas as frame time would have claimed 7.5 fps for a client drawing 4.
# A wall-clock interval cannot drift from what the player sees, and by
# construction the samples add up to the window they were taken in.
#
# 8192 is about 2.3 minutes at 60 fps and 34 seconds at 240, comfortably past
# the 30-second ceiling `runtime frames` puts on a window. A longer window
# still reports exact frame, sum, min and max counters -- only the percentiles
# narrow to the retained tail, and `dropped` says by how much.
const FRAME_SAMPLE_CAPACITY := 8192

var server := TCPServer.new()
var peers: Array[StreamPeerTCP] = []
var request_buffers: Dictionary = {}
var port := 8799
var scene_path := ""
var allow_actions := false
# The dead-man's switch (issue #191). An engine is spawned detached and outlives
# the command that started it by design, so nothing ends one except an explicit
# stop -- and a sweep that is killed never makes that call, leaving the engine
# running for as long as the machine is up. Rather than trust every caller to
# clean up on every path, the engine watches whether anyone still holds its
# session open, and leaves when nobody does.
#
# This measures absence of an owner, not elapsed work: any process in the
# session refreshes the file, so a slow run is never at risk, and only the case
# where every one of them is gone reaches the timeout.
var session_heartbeat := ""
var session_ttl_ms := 0
var _heartbeat_checked_at_ms := 0
# The frame-time window. `frame_samples` is a ring buffer of the most recent
# frame times in milliseconds; the counters beside it span the whole window and
# stay exact even once the ring has wrapped.
var frame_samples := PackedFloat32Array()
var frame_write_index := 0
var frame_count := 0
var frame_sum_ms := 0.0
var frame_min_ms := 0.0
var frame_max_ms := 0.0
var frame_window_started_usec := 0
var frame_window_started_process_frames := 0
# When the previous idle frame was seen, so the next one can be measured
# against it. Seeded by `_reset_frames`, so the first frame of a window is
# measured from the reset rather than discarded.
var frame_last_ticks_usec := 0
# `game run --offscreen`: the window is kept windowed, this size, at this position
# (far off every screen), as the screenshot runner does. Re-applied for the first
# frames, because the game applies project.godot's fullscreen start in `_ready`.
var offscreen := false
var offscreen_size := Vector2i(1280, 720)
var offscreen_position := Vector2i(-10000, -10000)
var offscreen_frames_left := 120

func _init() -> void:
    var args := OS.get_cmdline_user_args()
    var index := 0
    while index < args.size():
        match args[index]:
            "--port":
                index += 1
                port = int(args[index]) if index < args.size() else 8799
            "--scene":
                index += 1
                scene_path = args[index] if index < args.size() else ""
            "--allow-actions":
                allow_actions = true
            "--session-heartbeat":
                index += 1
                session_heartbeat = args[index] if index < args.size() else ""
            "--session-ttl-ms":
                index += 1
                session_ttl_ms = int(args[index]) if index < args.size() else 0
            "--window-size":
                index += 1
                if index < args.size():
                    var size := args[index].split("x")
                    offscreen_size = Vector2i(int(size[0]), int(size[1]))
            "--window-position":
                index += 1
                if index < args.size():
                    var at := args[index].split(",")
                    offscreen_position = Vector2i(int(at[0]), int(at[1]))
                    offscreen = true
        index += 1
    # Sized here rather than in `_start`, which is deferred: `_process` can run
    # before it, and a frame recorded into an empty array would be an index
    # error on the very first frame of every inspected run.
    frame_samples.resize(FRAME_SAMPLE_CAPACITY)
    _reset_frames()
    call_deferred("_start")

func _start() -> void:
    if OS.get_environment("GODMODE_MEASURE_SYNC_ARENA") == "1":
        print("EXPORT_SYNC_ARENA_START=%d" % Time.get_ticks_msec())
        for variant in ["client", "server"]:
            export_held_scenes.append(load("res://assets/maps/dumbo/prebuilt/survival_%s.scn" % variant))
        print("EXPORT_SYNC_ARENA_DONE=%d" % Time.get_ticks_msec())
    if scene_path.is_empty():
        scene_path = str(ProjectSettings.get_setting("application/run/main_scene", ""))
    if !scene_path.is_empty():
        var scene := load(scene_path) as PackedScene
        if scene == null:
            push_error("Could not load inspection scene: %s" % scene_path)
            quit(2)
            return
        root.add_child(scene.instantiate())
    var error := server.listen(port, "127.0.0.1")
    if error != OK:
        push_error("Could not start inspection bridge on port %d" % port)
        quit(2)
        return
    RenderingServer.frame_post_draw.connect(_export_first_draw)
    print("GODOT_CLI_INSPECTION=http://127.0.0.1:%d/inspect" % port)


# True once nobody has renewed this session for longer than the TTL.
#
# Checked on a coarse interval rather than every frame: this is a filesystem
# stat, the condition it detects takes minutes to arise, and the bridge's frame
# budget is the same one presentation sampling competes for (issue #177).
#
# A missing heartbeat file is treated as abandoned rather than as an error. The
# file is written before the engine is spawned, so its absence means something
# removed it -- a cleared temp directory, or a `session end` that ran while this
# engine was still starting -- and in both cases nobody is left to renew it.
func _session_abandoned() -> bool:
    if session_heartbeat.is_empty() or session_ttl_ms <= 0:
        return false
    var now_ms := Time.get_ticks_msec()
    if now_ms - _heartbeat_checked_at_ms < 5000:
        return false
    _heartbeat_checked_at_ms = now_ms
    if !FileAccess.file_exists(session_heartbeat):
        return true
    var age_seconds := Time.get_unix_time_from_system() - FileAccess.get_modified_time(session_heartbeat)
    return age_seconds * 1000.0 > float(session_ttl_ms)

func _process(_delta: float) -> bool:
    if offscreen and offscreen_frames_left > 0:
        offscreen_frames_left -= 1
        _keep_offscreen()
    _record_frame()
    if _session_abandoned():
        print("GODMODE_SESSION_EXPIRED=%s" % session_heartbeat)
        quit(0)
        return true
    while server.is_connection_available():
        var connection := server.take_connection()
        peers.append(connection)
        request_buffers[connection] = PackedByteArray()
    for peer in peers.duplicate():
        peer.poll()
        if peer.get_status() != StreamPeerTCP.STATUS_CONNECTED:
            peers.erase(peer)
            request_buffers.erase(peer)
        elif peer.get_available_bytes() > 0:
            var read_result: Array = peer.get_data(peer.get_available_bytes())
            if read_result[0] != OK:
                peers.erase(peer)
                request_buffers.erase(peer)
                peer.disconnect_from_host()
                continue
            var buffer: PackedByteArray = request_buffers[peer]
            buffer.append_array(read_result[1])
            request_buffers[peer] = buffer
            var expected_size := _expected_request_size(buffer)
            if expected_size == -2 or buffer.size() > MAX_REQUEST_BYTES:
                _respond_error(peer, "413 Content Too Large", "request is too large")
                peers.erase(peer)
                request_buffers.erase(peer)
            elif expected_size >= 0 and buffer.size() >= expected_size:
                _respond(peer, buffer.slice(0, expected_size).get_string_from_utf8())
                peers.erase(peer)
                request_buffers.erase(peer)
    return false

# One clock read, one store and one increment, so the measurement cannot
# meaningfully change what it is measuring. `frame_count` keeps climbing past
# the ring's capacity: the sum, min and max are exact over the whole window
# even when the samples behind them have been overwritten.
func _record_frame() -> void:
    var now_usec := Time.get_ticks_usec()
    var frame_ms := float(now_usec - frame_last_ticks_usec) / 1000.0
    frame_last_ticks_usec = now_usec
    frame_samples[frame_write_index] = frame_ms
    frame_write_index = (frame_write_index + 1) % FRAME_SAMPLE_CAPACITY
    if frame_count == 0 or frame_ms < frame_min_ms:
        frame_min_ms = frame_ms
    if frame_count == 0 or frame_ms > frame_max_ms:
        frame_max_ms = frame_ms
    frame_sum_ms += frame_ms
    frame_count += 1

func _reset_frames() -> void:
    frame_write_index = 0
    frame_count = 0
    frame_sum_ms = 0.0
    frame_min_ms = 0.0
    frame_max_ms = 0.0
    frame_window_started_usec = Time.get_ticks_usec()
    frame_last_ticks_usec = frame_window_started_usec
    frame_window_started_process_frames = Engine.get_process_frames()

# The retained samples oldest-first, with the counters that span the whole
# window. Percentiles and the mean are left to the caller (`summarizeFrameTimes`
# in tools/godot-cli/src/cli.ts): sorting thousands of samples belongs anywhere
# but the main thread of the game being measured.
func _frames_reading() -> Dictionary:
    var retained: int = min(frame_count, FRAME_SAMPLE_CAPACITY)
    var samples: Array[float] = []
    samples.resize(retained)
    var start := (frame_write_index - retained + FRAME_SAMPLE_CAPACITY) % FRAME_SAMPLE_CAPACITY
    for index in retained:
        samples[index] = frame_samples[(start + index) % FRAME_SAMPLE_CAPACITY]
    return {
        "schemaVersion": 1,
        "capacity": FRAME_SAMPLE_CAPACITY,
        "frames": frame_count,
        "retained": retained,
        "dropped": frame_count - retained,
        "windowMs": float(Time.get_ticks_usec() - frame_window_started_usec) / 1000.0,
        # The engine's own idle-frame counter over the same window. It must
        # equal `frames`; if it ever does not, this script missed frames and
        # every statistic beside it is describing the wrong population.
        "engineFrames": Engine.get_process_frames() - frame_window_started_process_frames,
        "sumMs": frame_sum_ms,
        "minMs": frame_min_ms,
        "maxMs": frame_max_ms,
        "samplesMs": samples,
        "engine": _engine_reading(),
    }

# What the caller needs to know before believing a number. A headless run draws
# nothing, so its frame times measure the idle loop rather than render cost; a
# vsync-locked or `max_fps`-capped client reports the cap it is waiting on
# rather than the work it did. Reported rather than judged here, so the
# thresholds live with the command that prints them.
func _engine_reading() -> Dictionary:
    var display_server := DisplayServer.get_name()
    var headless := display_server == "headless"
    return {
        "displayServer": display_server,
        "headless": headless,
        "videoAdapter": "" if headless else RenderingServer.get_video_adapter_name(),
        "renderingMethod": str(ProjectSettings.get_setting("rendering/renderer/rendering_method", "")),
        "maxFps": Engine.max_fps,
        # -1 where there is no window to ask; DisplayServer.VSYNC_DISABLED is 0.
        "vsyncMode": -1 if headless else int(DisplayServer.window_get_vsync_mode()),
        # What vsync would actually hold a frame to, so the caller can tell a
        # measurement that hit the cap from one that never came near it.
        "refreshRateHz": -1.0 if headless else DisplayServer.screen_get_refresh_rate(),
        "physicsTicksPerSecond": Engine.physics_ticks_per_second,
    }

func _expected_request_size(buffer: PackedByteArray) -> int:
    var text := buffer.get_string_from_utf8()
    var header_end := text.find("\r\n\r\n")
    if header_end < 0:
        return -2 if buffer.size() > MAX_HEADER_BYTES else -1
    var header_size := header_end + 4
    if header_size > MAX_HEADER_BYTES:
        return -2
    var content_length := 0
    var content_length_count := 0
    for line in text.substr(0, header_end).split("\r\n"):
        if line.to_lower().begins_with("content-length:"):
            content_length_count += 1
            var raw_length := line.get_slice(":", 1).strip_edges()
            if content_length_count > 1 or !raw_length.is_valid_int():
                return -2
            content_length = int(raw_length)
    if content_length < 0 or header_size + content_length > MAX_REQUEST_BYTES:
        return -2
    return header_size + content_length

func _respond_error(peer: StreamPeerTCP, status: String, message: String) -> void:
    var body := JSON.stringify({"error": message})
    var response := "HTTP/1.1 %s\r\nContent-Type: application/json\r\nContent-Length: %d\r\nConnection: close\r\n\r\n%s" % [status, body.to_utf8_buffer().size(), body]
    peer.put_data(response.to_utf8_buffer())
    peer.disconnect_from_host()

func _respond(peer: StreamPeerTCP, request: String) -> void:
    var status := "200 OK"
    var body := ""
    if request.begins_with("GET /inspect "):
        body = JSON.stringify(_snapshot())
    elif request.begins_with("GET /inspect?store=1 "):
        # The same reply with the node walk left out. Issue #178 measured that
        # walk at ~600 KB and ~105 ms of the game's own main thread, which is
        # why actions stopped carrying one; a suite that *polls* GET /inspect
        # pays it on every turn of the loop for the same reason, and the
        # arithmetic is worse than it looks. A client held at a few frames a
        # second cannot keep up with the server's 20 Hz snapshot stream, and
        # those snapshots are larger than an ENet fragment, so they are
        # delivered reliably and queue instead of being dropped: the client
        # ends up displaying a world several seconds old, and a window that
        # opens and closes on the server inside two seconds is never in view
        # when the suite looks (issue #202). A predicate that reads only the
        # store polls this instead and leaves the client running at full speed.
        #
        # `nodes` is absent rather than empty, so a caller that reaches for it
        # fails loudly instead of quietly asserting over nothing.
        body = JSON.stringify(_store_snapshot())
    elif request.begins_with("GET /frames "):
        body = JSON.stringify(_frames_reading())
    elif request.begins_with("GET /frames?reset=1 "):
        # Answers with the window that just ended and starts a new one, so a
        # caller brackets a measurement with two cheap requests instead of
        # polling. Reading and resetting in one turn is what keeps the window
        # equal to the wait between them: a separate reset would leave the
        # frames drawn in between belonging to neither.
        body = JSON.stringify(_frames_reading())
        _reset_frames()
    elif request.begins_with("POST /action "):
        if !allow_actions:
            status = "403 Forbidden"
            body = JSON.stringify({"error": "runtime actions were not enabled"})
        else:
            var separator := request.find("\r\n\r\n")
            var request_body := request.substr(separator + 4) if separator >= 0 else ""
            var target := _find_action_target(root)
            if target == null:
                status = "422 Unprocessable Entity"
                body = JSON.stringify({"error": "scene has no godot_cli_action handler"})
            else:
                var action_result: Variant = target.call("godot_cli_action", request_body)
                var decoded: Variant = JSON.parse_string(str(action_result))
                var store: Variant = _find_store(root)
                var reply := {"ok": true, "result": decoded if decoded != null else action_result, "store": store}
                # Include the scene snapshot produced in the same bridge turn as
                # the action, for the actions that are read back that way. Capture
                # tests assert the exact transforms that were force-drawn instead
                # of an earlier polling sample. The store is resolved once and
                # handed to the snapshot rather than walked for a second time.
                if SNAPSHOT_ACTIONS.has(_action_name(request_body)):
                    reply["snapshot"] = _snapshot_with_store(store)
                body = JSON.stringify(reply)
    else:
        status = "404 Not Found"
        body = JSON.stringify({"error": "not found"})
    var response := "HTTP/1.1 %s\r\nContent-Type: application/json\r\nContent-Length: %d\r\nConnection: close\r\n\r\n%s" % [status, body.to_utf8_buffer().size(), body]
    peer.put_data(response.to_utf8_buffer())
    peer.disconnect_from_host()

func _snapshot() -> Dictionary:
    return _snapshot_with_store(_find_store(root))

func _store_snapshot() -> Dictionary:
    return {"schemaVersion": 1, "scene": scene_path if !scene_path.is_empty() else null, "frame": Engine.get_process_frames(), "capturedAtMs": Time.get_ticks_msec(), "store": _find_store(root)}

func _snapshot_with_store(store: Variant) -> Dictionary:
    var nodes: Array[Dictionary] = []
    _append_nodes(root, nodes)
    return {"schemaVersion": 1, "scene": scene_path if !scene_path.is_empty() else null, "frame": Engine.get_process_frames(), "capturedAtMs": Time.get_ticks_msec(), "nodes": nodes, "store": store}

# The action envelope's name, or "" when the body is not the {name, payload}
# shape the handler expects. An unnamed request is refused by the handler
# anyway, so it never needs a snapshot.
func _action_name(request_body: String) -> String:
    var decoded: Variant = JSON.parse_string(request_body)
    if decoded is Dictionary and decoded.get("name") is String:
        return str(decoded["name"])
    return ""

func _find_store(node: Node) -> Variant:
    # A game that builds its store on demand is asked for it here, so the store
    # costs nothing between requests; a simple scene still publishes a meta.
    if node.has_method("godot_cli_state"):
        return JSON.parse_string(str(node.call("godot_cli_state")))
    if node.has_meta("godot_cli_state"):
        var decoded: Variant = JSON.parse_string(str(node.get_meta("godot_cli_state")))
        return decoded
    for child in node.get_children():
        var found: Variant = _find_store(child)
        if found != null:
            return found
    return null

func _find_action_target(node: Node) -> Node:
    if node.has_method("godot_cli_action"):
        return node
    for child in node.get_children():
        var found := _find_action_target(child)
        if found != null:
            return found
    return null

func _append_nodes(node: Node, output: Array[Dictionary]) -> void:
    var item := {"path": str(node.get_path()), "type": node.get_class(), "instanceId": node.get_instance_id()}
    # createCategoryCharacter/createSystemAdminCharacter (presentation.ts)
    # tag a rigged character's root with which body it actually loaded, so
    # tests can assert a player's rendered identity matches their cheat
    # class instead of only that some body is visible.
    if node.has_meta("playerCategory"):
        item["playerCategory"] = str(node.get_meta("playerCategory"))
    if node.has_meta("systemAdminLevel"):
        item["systemAdminLevel"] = str(node.get_meta("systemAdminLevel"))
    if node is Node3D:
        var node_3d := node as Node3D
        item["position"] = _vector3(node_3d.global_position)
        item["localPosition"] = _vector3(node_3d.position)
        item["rotationDegrees"] = _vector3(node_3d.rotation_degrees)
        item["globalRotation"] = _quaternion(node_3d.global_basis.get_rotation_quaternion())
        item["globalScale"] = _vector3(node_3d.global_basis.get_scale())
        var camera := node_3d.get_viewport().get_camera_3d()
        if camera != null:
            var camera_space := camera.global_transform.affine_inverse() * node_3d.global_position
            item["screenPosition"] = _vector2(camera.unproject_position(node_3d.global_position))
            item["cameraDepth"] = -camera_space.z
            item["behindCamera"] = camera.is_position_behind(node_3d.global_position)
    elif node is Control:
        var control := node as Control
        item["position"] = _vector2(control.global_position)
        item["localPosition"] = _vector2(control.position)
        item["size"] = _vector2(control.size)
        item["mouseFilter"] = control.mouse_filter
    elif node is Node2D:
        item["position"] = _vector2((node as Node2D).global_position)
    if node is VisualInstance3D:
        item["visible"] = (node as VisualInstance3D).visible
        item["visibleInTree"] = (node as VisualInstance3D).is_visible_in_tree()
    elif node is CanvasItem:
        item["visible"] = (node as CanvasItem).visible
        item["visibleInTree"] = (node as CanvasItem).is_visible_in_tree()
    if node is GeometryInstance3D:
        var geometry := node as GeometryInstance3D
        item["giMode"] = geometry.gi_mode
        item["renderLayers"] = geometry.layers
        item["hasMaterialOverride"] = geometry.material_override != null
        if geometry.material_override is ShaderMaterial:
            var shader_material := geometry.material_override as ShaderMaterial
            item["shaderPath"] = shader_material.shader.resource_path if shader_material.shader != null else ""
            var first_person_depth: Variant = shader_material.get_shader_parameter("first_person")
            if first_person_depth is bool:
                item["firstPersonDepthSafe"] = first_person_depth
    if node is MeshInstance3D:
        var mesh_instance := node as MeshInstance3D
        item["hasMesh"] = mesh_instance.mesh != null
        item["skeletonPath"] = str(mesh_instance.skeleton)
        item["hasSkin"] = mesh_instance.skin != null
        if mesh_instance.mesh != null:
            var mesh := mesh_instance.mesh
            item["meshResourcePath"] = mesh.resource_path
            if mesh.has_meta("sourceSurfaceHashes"):
                item["sourceSurfaceHashes"] = Array(mesh.get_meta("sourceSurfaceHashes"))
                item["uv2VertexCounts"] = []
                item["activeMaterialInstanceIds"] = []
                for surface in range(mesh.get_surface_count()):
                    var arrays := mesh.surface_get_arrays(surface)
                    var uv2 = arrays[Mesh.ARRAY_TEX_UV2]
                    item["uv2VertexCounts"].append(uv2.size() if uv2 != null else 0)
                    var material := mesh_instance.get_active_material(surface)
                    item["activeMaterialInstanceIds"].append(material.get_instance_id() if material != null else 0)
            var bounds := mesh_instance.get_aabb()
            item["aabb"] = {"position": _vector3(bounds.position), "size": _vector3(bounds.size)}
            var world_bounds := mesh_instance.global_transform * bounds
            item["worldAabb"] = {"position": _vector3(world_bounds.position), "size": _vector3(world_bounds.size)}
        if node.has_meta("muzzleFlashDurationMs"):
            item["muzzleFlashDurationMs"] = int(node.get_meta("muzzleFlashDurationMs"))
            item["fireIntervalMs"] = int(node.get_meta("fireIntervalMs"))
    if node is Skeleton3D:
        var skeleton := node as Skeleton3D
        item["boneCount"] = skeleton.get_bone_count()
        var bone_names: Array[String] = []
        var bone_parents: Array[int] = []
        var bone_global_positions: Array = []
        var bone_world_positions: Array = []
        var bone_world_rotations: Array = []
        var bone_screen_positions: Array = []
        var bone_camera_depths: Array = []
        var skeleton_camera := skeleton.get_viewport().get_camera_3d()
        for bone_index in skeleton.get_bone_count():
            bone_names.append(str(skeleton.get_bone_name(bone_index)))
            bone_parents.append(skeleton.get_bone_parent(bone_index))
            var bone_position := skeleton.get_bone_global_pose(bone_index).origin
            bone_global_positions.append(_vector3(bone_position))
            var bone_pose := skeleton.get_bone_global_pose(bone_index)
            var bone_world_position := skeleton.global_transform * bone_position
            bone_world_positions.append(_vector3(bone_world_position))
            bone_world_rotations.append(_quaternion((skeleton.global_basis * bone_pose.basis).get_rotation_quaternion()))
            if skeleton_camera != null:
                var bone_camera_space := skeleton_camera.global_transform.affine_inverse() * bone_world_position
                bone_screen_positions.append(_vector2(skeleton_camera.unproject_position(bone_world_position)))
                bone_camera_depths.append(-bone_camera_space.z)
        item["boneNames"] = bone_names
        item["boneParents"] = bone_parents
        item["boneGlobalPositions"] = bone_global_positions
        item["boneWorldPositions"] = bone_world_positions
        item["boneWorldRotations"] = bone_world_rotations
        item["boneScreenPositions"] = bone_screen_positions
        item["boneCameraDepths"] = bone_camera_depths
        if skeleton.get_bone_count() > 0:
            item["rootBonePose"] = _vector3(skeleton.get_bone_global_pose(0).origin)
    if node is AnimationPlayer:
        var animation_player := node as AnimationPlayer
        item["animations"] = Array(animation_player.get_animation_list())
        item["currentAnimation"] = animation_player.current_animation
        item["animationPosition"] = animation_player.current_animation_position
        item["isPlaying"] = animation_player.is_playing()
    if node is CharacterBody3D:
        item["velocity"] = _vector3((node as CharacterBody3D).velocity)
    if node is CollisionShape3D:
        var collision_shape := node as CollisionShape3D
        item["shapeType"] = collision_shape.shape.get_class() if collision_shape.shape != null else ""
        if collision_shape.shape is CapsuleShape3D:
            var capsule := collision_shape.shape as CapsuleShape3D
            item["capsuleHeight"] = capsule.height
            item["capsuleRadius"] = capsule.radius
    if node is BoneAttachment3D:
        var bone_attachment := node as BoneAttachment3D
        item["boneName"] = str(bone_attachment.bone_name)
        item["boneIndex"] = bone_attachment.bone_idx
    if node is Camera3D:
        var camera := node as Camera3D
        item["cullMask"] = camera.cull_mask
        item["fov"] = camera.fov
        item["near"] = camera.near
        item["far"] = camera.far
        item["projection"] = camera.projection
        # Camera projection APIs use logical screen coordinates even when a
        # Retina backing texture is several times larger. Report the optical
        # center by projecting a point on the camera's own forward axis.
        item["projectionCenter"] = _vector2(camera.unproject_position(camera.global_position - camera.global_basis.z))
        item["viewportSize"] = _vector2(camera.get_viewport().get_visible_rect().size)
        var viewport_texture := camera.get_viewport().get_texture()
        item["renderSize"] = _vector2(viewport_texture.get_size()) if viewport_texture != null else item["viewportSize"]
    if node is LightmapGI and (node as LightmapGI).light_data != null:
        var data := (node as LightmapGI).light_data
        item["lightmapUserPaths"] = []
        for user in range(data.get_user_count()):
            item["lightmapUserPaths"].append(str(data.get_user_path(user)))
    output.append(item)
    for child in node.get_children():
        _append_nodes(child, output)

func _vector2(value: Vector2) -> Array[float]:
    return [value.x, value.y]

func _vector3(value: Vector3) -> Array[float]:
    return [value.x, value.y, value.z]

func _quaternion(value: Quaternion) -> Array[float]:
    return [value.x, value.y, value.z, value.w]


## `game run --offscreen`: windowed, borderless, unfocusable and parked off every
## screen, as the screenshot runner's capture window is. Only once windowed can it move.
func _keep_offscreen() -> void:
    if DisplayServer.window_get_mode() != DisplayServer.WINDOW_MODE_WINDOWED:
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
    DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS, true)
    DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_NO_FOCUS, true)
    if DisplayServer.window_get_size() != offscreen_size:
        DisplayServer.window_set_size(offscreen_size)
        root.size = offscreen_size
    if DisplayServer.window_get_position() != offscreen_position:
        DisplayServer.window_set_position(offscreen_position)

var export_draw_logged := false
var export_held_scenes: Array[Resource] = []
func _export_first_draw() -> void:
    if export_draw_logged:
        return
    var store: Variant = _find_store(root)
    if store is Dictionary and int(store.get("localPeerId", 0)) > 0 and not bool(store.get("matchLoadingOpen", true)) and not bool(store.get("mainMenuOpen", true)):
        export_draw_logged = true
        print("EXPORT_FIRST_PRESENTED_GAMEPLAY_FRAME=%d pid=%d" % [Time.get_ticks_msec(), OS.get_process_id()])
        RenderingServer.frame_post_draw.disconnect(_export_first_draw)
