const { spawnSync } = require("node:child_process");
const path = require("node:path");
const args = process.argv.slice(2);
const projectIndex = args.indexOf("--path");
if (projectIndex >= 0) args.splice(projectIndex, 2);
const scriptIndex = args.indexOf("--script");
if (scriptIndex >= 0) args[scriptIndex + 1] = path.join(__dirname, "timed-inspection.gd");
const child = spawnSync(process.env.GODOTJS_PATH, ["--main-pack", process.env.GODMODE_EXPORTED_BINARY, ...args], { stdio: "inherit", windowsHide: true });
process.exit(child.status ?? 1);
