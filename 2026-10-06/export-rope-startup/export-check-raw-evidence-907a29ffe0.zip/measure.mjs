import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync, copyFileSync } from "node:fs";
import path from "node:path";
import { setTimeout as delay } from "node:timers/promises";

const root = process.cwd();
const cli = path.join(root, "tools/godot-cli/dist/src/index.js");
const execute = promisify(execFile);
const [label, binaryArgument, pairsArgument = "3"] = process.argv.slice(2);
const binary = path.resolve(binaryArgument);
const project = path.dirname(binary);
const evidence = path.join(root, "artifacts/check-exports", label);
mkdirSync(evidence, { recursive: true });
copyFileSync(path.join(root, "project.godot"), path.join(project, "project.godot"));
const session = process.env.GODMODE_SESSION_ID;
process.env.GODMODE_EXPORTED_BINARY = binary;
if (!session) throw new Error("GODMODE_SESSION_ID is required");
async function call(args) {
    const { stdout } = await execute(process.execPath, [cli, "--json", ...args], { cwd: root, env: process.env, timeout: 120_000, maxBuffer: 20e6 });
    const reply = JSON.parse(stdout);
    if (!reply.ok) throw new Error(JSON.stringify(reply));
    return reply.data;
}
const results = [];
for (let pair = 1; pair <= Number(pairsArgument); pair++) {
    // Each pair gets a fresh user shader cache; warm repeats share only that pair's cache.
    // This does not purge the Windows file cache or the driver's machine-wide shader cache.
    const userDirectory = `Godot/app_userdata/export-rope-startup/${label}-${pair}`;
    writeFileSync(path.join(project, "override.cfg"), `[application]\nconfig/use_custom_user_dir=true\nconfig/custom_user_dir_name="${userDirectory}"\n[display]\nwindow/size/mode=1\nwindow/size/mode.windows=1\nwindow/size/mode.template=1\nwindow/size/no_focus=true\n`);
    for (const temperature of ["cold", "warm"]) {
        const name = `${label}-${pair}-${temperature}`;
        let started;
        const invokedAt = performance.now();
        try {
            started = await call(["--godot", path.join(root, "artifacts/check-exports/exported-run.js"), "game", "run", "--project", project, "--instance", name, "--session", session, "--offscreen", "--offscreen-size", "1920x1080", "--inspect", "--allow-actions", "--fixture", "roguelite"]);
            const deadline = Date.now() + 180_000;
            let text = "", match = null;
            while (Date.now() < deadline) {
                const logs = path.join(project, "logs");
                if (existsSync(logs)) {
                    const current = readdirSync(logs).filter(file => file.endsWith(".log")).map(file => readFileSync(path.join(logs, file), "utf8")).find(log => log.includes(`settings-${name}.cfg`));
                    if (current) text = current;
                }
                const engineLog = started.logPath && existsSync(started.logPath) ? readFileSync(started.logPath, "utf8") : "";
                match = /EXPORT_FIRST_PRESENTED_GAMEPLAY_FRAME=(\d+)/.exec(engineLog);
                if (match) break;
                await delay(100);
            }
            if (!match) throw new Error(`No gameplay marker: ${text.slice(-3000)} ${JSON.stringify(started)}`);
            const observedMs = Math.round(performance.now() - invokedAt);
            // Allow presentation, resource loading and the first render to finish before capturing.
            const frame = await call(["runtime", "frames", "--project", project, "--instance", name, "--warmup-ms", "1000", "--window-ms", "2000"]);
            await call(["game", "capture", "--project", project, "--instance", name, "--output", path.join(evidence, `${name}.png`)]);
            await delay(100);
            const logs = path.join(project, "logs");
            if (existsSync(logs)) text = readdirSync(logs).filter(file => file.endsWith(".log")).map(file => readFileSync(path.join(logs, file), "utf8")).find(log => log.includes(`settings-${name}.cfg`)) ?? text;
            if (!text) text = readFileSync(started.logPath, "utf8");
            const gameplayMarker = /GODMODE_FIRST_GAMEPLAY_FRAME=(\d+)/.exec(text);
            const result = { name, temperature, pair, enginePresentedGameplayMs: Number(match[1]), engineGameplayMs: gameplayMarker ? Number(gameplayMarker[1]) : null, observedFromCliMs: observedMs, pid: started.pid, frames: frame, arenas: text.split(/\r?\n/).filter(line => line.includes("GODMODE_ARENA_BUILD=")) };
            writeFileSync(path.join(evidence, `${name}.log`), text);
            if (started.logPath) copyFileSync(started.logPath, path.join(evidence, `${name}-engine.log`));
            results.push(result);
            writeFileSync(path.join(evidence, "measurements.json"), JSON.stringify(results, null, 2));
            console.log(JSON.stringify({ name, engineGameplayMs: result.engineGameplayMs, presentedMs: result.enginePresentedGameplayMs, observedMs, arenas: result.arenas }));
        } finally {
            if (started) await call(["game", "stop", "--project", project, "--instance", name]);
            // The Windows CLI stops the Node adapter, not its native child. Reap only the
            // engine identified by this run's own first-draw marker.
            const log = started?.logPath && existsSync(started.logPath) ? readFileSync(started.logPath, "utf8") : "";
            const childPid = /EXPORT_FIRST_PRESENTED_GAMEPLAY_FRAME=\d+ pid=(\d+)/.exec(log);
            if (childPid) await execute("taskkill", ["/PID", childPid[1], "/T", "/F"]).catch(() => {});
        }
        await delay(3000);
    }
}
