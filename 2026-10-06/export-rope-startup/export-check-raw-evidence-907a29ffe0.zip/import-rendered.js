const { spawnSync } = require("node:child_process");
const { openSync, closeSync, readFileSync, writeFileSync } = require("node:fs");
const path = require("node:path");
const originalArgs = process.argv.slice(2);
const editor = originalArgs.includes("--editor");
const exporting = originalArgs.some(arg => arg.startsWith("--export-"));
const args = editor ? originalArgs.filter(arg => arg !== "--headless") : originalArgs;
if (editor) args.push("--windowed", "--resolution", "640x360", "--position", "-10000,-10000");
if (editor || exporting) args.push("--", "--godmode-session", "s-muw0ec5r-7c6d2057b46f");
const projectArg = originalArgs.indexOf("--path");
const config = projectArg >= 0 ? path.join(originalArgs[projectArg + 1], "project.godot") : null;
const original = config && (editor || exporting) ? readFileSync(config) : null;
// Build-host workaround only: Windows packs BPTC and the preset excludes ASTC.
// Keep the authored file byte-identical after the engine exits.
if (original) writeFileSync(config, original.toString().replace("textures/vram_compression/import_etc2_astc=true", "textures/vram_compression/import_etc2_astc=false"));
if (!editor && !exporting) {
    const child = spawnSync(process.env.GODOTJS_PATH, args, { stdio: "inherit", windowsHide: true });
    process.exit(child.status ?? 1);
}
let child;
const log = openSync("artifacts/check-exports/import-engine.log", "a");
try {
    child = spawnSync(process.env.GODOTJS_PATH, args, { stdio: ["ignore", log, log], windowsHide: true });
} finally {
    closeSync(log);
    if (original) writeFileSync(config, original);
}
process.exit(child.status ?? 1);
