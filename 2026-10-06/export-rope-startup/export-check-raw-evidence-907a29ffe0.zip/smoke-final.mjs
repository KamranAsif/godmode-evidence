import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { writeFileSync, copyFileSync } from "node:fs";
import { setTimeout as delay } from "node:timers/promises";
const execute = promisify(execFile), instance = "export-rope-smoke-final";
async function call(args) {
    const { stdout } = await execute(process.execPath, ["tools/godot-cli/dist/src/index.js", "--json", ...args], {env: process.env, timeout: 120000, maxBuffer: 40e6});
    const r=JSON.parse(stdout); if(!r.ok) throw Error(stdout); return r.data;
}
await call(["game","ps","--project","."]);
const started = await call(["game","run","--project",".","--instance",instance,"--session",process.env.GODMODE_SESSION_ID,"--headless","--inspect","--allow-actions","--fixture","roguelite"]);
try {
    let state;
    const deadline=Date.now()+90000;
    while(Date.now()<deadline) {
        try {
            state=await call(["runtime","inspect","--project",".","--instance",instance,"--store-only"]);
        } catch(error) {
            if(!String(error.stdout).includes("bridge is unavailable")) throw error;
        }
        if(state?.store.localPeerId>0 && state.store.roguelite) break;
        await delay(500);
    }
    if(!(state?.store.localPeerId>0)) throw Error("Gameplay did not load");
    const action=(name,payload)=>call(["runtime","action","--project",".","--instance",instance,"--name",name,"--payload",JSON.stringify(payload)]);
    await action("debug_console",{run:"timescale 0.05"});
    await action("debug_console",{run:"insertion rappel"});
    await action("debug_insertion_pose",{elapsedMs:1300,view:"firstPerson",clay:false});
    state=await call(["runtime","inspect","--project",".","--instance",instance,"--store-only"]);
    const report={localPeerId:state.store.localPeerId,insertion:state.store.roguelite.insertion};
    writeFileSync("artifacts/check-exports/smoke-final.json",JSON.stringify(report,null,2));
    if(!report.insertion.ropeVisible || report.insertion.phase!=="returning") throw Error(JSON.stringify(report));
    console.log(JSON.stringify(report));
} finally {
    await call(["game","stop","--project",".","--instance",instance]);
    copyFileSync(started.logPath,"artifacts/check-exports/smoke-final-engine.log");
}
