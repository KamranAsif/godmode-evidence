import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { copyFileSync, linkSync, mkdirSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { setTimeout as delay } from "node:timers/promises";
const execute = promisify(execFile), root = process.cwd();
const project = path.resolve("artifacts/check-exports/final-rope-pack"), instance = "rope-export-final";
const binary = path.join(project,"BattleDuty-aimbot.exe");
mkdirSync(project,{recursive:true});
if(!existsSync(binary)) linkSync(path.resolve(process.argv[2]),binary);
copyFileSync("project.godot",path.join(project,"project.godot"));
writeFileSync(path.join(project,"override.cfg"),'[application]\nconfig/use_custom_user_dir=true\nconfig/custom_user_dir_name="Godot/app_userdata/export-rope-startup/rope-proof-final"\n[display]\nwindow/size/mode=0\nwindow/size/mode.windows=0\nwindow/size/mode.template=0\nwindow/size/no_focus=true\n');
process.env.GODMODE_EXPORTED_BINARY = binary;
async function call(args) {
    const {stdout}=await execute(process.execPath,["tools/godot-cli/dist/src/index.js","--json",...args],{env:process.env,timeout:120000,maxBuffer:40e6});
    const reply=JSON.parse(stdout); if(!reply.ok)throw Error(stdout);return reply.data;
}
await call(["game","ps","--project",project]);
const started=await call(["--godot",path.join(root,"artifacts/check-exports/exported-run.js"),"game","run","--project",project,"--instance",instance,"--session",process.env.GODMODE_SESSION_ID,"--offscreen","--offscreen-size","1920x1080","--inspect","--allow-actions","--fixture","roguelite"]);
try {
    let state;const deadline=Date.now()+120000;
    while(Date.now()<deadline) {
        try {state=await call(["runtime","inspect","--project",project,"--instance",instance,"--store-only"]);} catch(error) {if(!String(error.stdout).includes("bridge is unavailable"))throw error;}
        if(state?.store.localPeerId>0 && state.store.roguelite)break;
        await delay(500);
    }
    if(!(state?.store.localPeerId>0))throw Error("Export pack did not reach gameplay");
    for(const script of ["rope-captures.mjs","rope-look-up.mjs"]) {
        const result=await execute(process.execPath,[`artifacts/check-exports/${script}`],{env:process.env,timeout:180000,maxBuffer:400000});console.log(result.stdout);
    }
    const action=(name,payload)=>call(["runtime","action","--project",project,"--instance",instance,"--name",name,"--payload",JSON.stringify(payload)]);
    await action("debug_console",{run:"timescale 1"});
    await action("debug_insertion_pose",{enabled:false});
    await delay(6000);
    state=await call(["runtime","inspect","--project",project,"--instance",instance,"--store-only"]);
    writeFileSync("artifacts/check-exports/rope-retraction.json",JSON.stringify({localPeerId:state.store.localPeerId,insertion:state.store.roguelite.insertion},null,2));
    if(state.store.roguelite.insertion.ropeVisible)throw Error("Rope remained after return/retraction");
    console.log(JSON.stringify({retraction:state.store.roguelite.insertion}));
} finally {
    await call(["game","stop","--project",project,"--instance",instance]);
    copyFileSync(started.logPath,"artifacts/check-exports/rope-pack-engine.log");
    const log=readFileSync(started.logPath,"utf8");
    if(/SCRIPT ERROR|GODMODE_FRAME_ERROR/.test(log))throw Error("Script error in capture engine log");
}
