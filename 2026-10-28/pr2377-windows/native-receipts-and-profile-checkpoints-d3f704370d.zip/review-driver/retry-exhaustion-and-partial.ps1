$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$ErrorActionPreference='Stop'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
node "$PSScriptRoot/native-batch.mjs" "$PSScriptRoot/batch-partial-replay.json"
$partialCode=$LASTEXITCODE
node "$PSScriptRoot/native-batch.mjs" "$PSScriptRoot/batch-exhaustion-control.json"
$exhaustionCode=$LASTEXITCODE
@{partialReplayExit=$partialCode;exhaustionExit=$exhaustionCode}|ConvertTo-Json|Set-Content "$PSScriptRoot/exhaustion-retry-exit-codes.json"
if($partialCode -ne 0 -or $exhaustionCode -ne 0){throw 'One or more controls failed; receipts retained'}
