$env:GODMODE_GPU_CAPTURE_LIMIT='3'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
. (Join-Path $PSScriptRoot 'control.ps1')
Start-Sleep -Seconds 20
Crate-Input @{key=27}
Crate-Shot 'initial-pause-menu'
