$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$ErrorActionPreference='Stop'
& "$PSScriptRoot/ui-batch.ps1" -Plan "$PSScriptRoot/batch-partial-tooltip.json"
& "$PSScriptRoot/ui-batch.ps1" -Plan "$PSScriptRoot/batch-feat-campaign.json"
