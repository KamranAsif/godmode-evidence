$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$ErrorActionPreference='Stop'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
node "$PSScriptRoot/native-batch.mjs" "$PSScriptRoot/batch-twentyone-progress.json"
if($LASTEXITCODE -ne 0){throw 'Partial counter capture failed'}
node "$PSScriptRoot/native-batch.mjs" "$PSScriptRoot/batch-feat-drain-workaround.json"
if($LASTEXITCODE -ne 0){throw 'Receipt-gated feat campaign failed'}
