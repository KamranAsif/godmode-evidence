$ErrorActionPreference='Stop'
$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$env:GODMODE_SESSION_ID=Get-Content (Join-Path $PSScriptRoot 'ui-session.txt')
$cli='tools/godot-cli/dist/src/index.js'
$out=$PSScriptRoot
function Crate-Input([hashtable]$Data){
    $file=Join-Path $out 'native-input.json'
    [IO.File]::WriteAllText($file,($Data|ConvertTo-Json -Compress))
    $raw=node $cli game window-input --project . --instance crate-windows-review --payload-file $file --timeout-ms 180000 --json
    [IO.File]::AppendAllText((Join-Path $out 'native-input-receipts.jsonl'),([DateTime]::UtcNow.ToString('o')+' '+($Data|ConvertTo-Json -Compress)+' '+($raw -join '')+[Environment]::NewLine))
    if($LASTEXITCODE -ne 0 -or -not (($raw -join '')|ConvertFrom-Json).ok){throw ($raw -join '')}
}
function Crate-Console([string]$Line){
    $logPath=Join-Path $env:TEMP 'godot-cli/291e3f44b2ae/game-crate-windows-review.log'
    $watcher=New-Object IO.FileSystemWatcher (Split-Path $logPath),(Split-Path $logPath -Leaf)
    $watcher.EnableRaisingEvents=$true
    $stream=[IO.File]::Open($logPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
    $stream.Position=$stream.Length
    $reader=New-Object IO.StreamReader $stream
    try {
        Crate-Input @{key=192;text=$Line;keysAfterText=@(13,192)}
        $receipt=$reader.ReadToEnd()
        if($receipt -notmatch 'GODMODE_DEBUG_COMMAND='){
            $event=$watcher.WaitForChanged([IO.WatcherChangeTypes]::Changed,10000)
            $receipt+=$reader.ReadToEnd()
        }
        $accepted=($receipt -split '[\r\n]+')|Where-Object {$_ -match 'GODMODE_DEBUG_COMMAND='}
        @{utc=[DateTime]::UtcNow.ToString('o');command=$Line;receipts=@($accepted)}|ConvertTo-Json -Compress|Add-Content (Join-Path $out 'console-command-receipts.jsonl')
        if(-not $accepted){throw ('No client command receipt for: '+$Line)}
    } finally {$reader.Dispose();$stream.Dispose();$watcher.Dispose()}
}
function Crate-Shot([string]$Name){
    $raw=node $cli game capture --project . --instance crate-windows-review --os-window --output (Join-Path $out ($Name+'.png')) --timeout-ms 180000 --allow-unchecked --json
    [IO.File]::WriteAllText((Join-Path $out ($Name+'.receipt.json')),($raw -join [Environment]::NewLine))
    if($LASTEXITCODE -ne 0 -or -not (($raw -join '')|ConvertFrom-Json).ok){throw ($raw -join '')}
}
function Crate-Cleanup {
    node $cli game stop --project . --instance crate-windows-review --json
    node $cli gpu release --json
    node $cli session end --json
}
