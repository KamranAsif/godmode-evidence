function Wait-ReviewMemory {
    param([string]$Receipt)
    Add-Type -AssemblyName System.Management
    $memory=Get-CimInstance Win32_OperatingSystem
    @{utc=[DateTime]::UtcNow.ToString('o');freeKiB=$memory.FreePhysicalMemory}|ConvertTo-Json -Compress|Add-Content -LiteralPath $Receipt
    if($memory.FreePhysicalMemory -ge 4*1024*1024){return}
    # WMI samples at one-minute intervals. WaitForNextEvent blocks without a sleep/status loop.
    $watcher=New-Object System.Management.ManagementEventWatcher("SELECT * FROM __InstanceModificationEvent WITHIN 60 WHERE TargetInstance ISA 'Win32_OperatingSystem'")
    try {
        while($memory.FreePhysicalMemory -lt 4*1024*1024){
            Write-Output ('Waiting for 4 GiB free physical RAM; current free KiB: '+$memory.FreePhysicalMemory)
            [void]$watcher.WaitForNextEvent()
            $memory=Get-CimInstance Win32_OperatingSystem
            @{utc=[DateTime]::UtcNow.ToString('o');freeKiB=$memory.FreePhysicalMemory}|ConvertTo-Json -Compress|Add-Content -LiteralPath $Receipt
        }
    } finally {$watcher.Stop();$watcher.Dispose()}
}
