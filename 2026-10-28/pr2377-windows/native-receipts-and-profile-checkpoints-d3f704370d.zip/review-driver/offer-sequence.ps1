function Crate-HeldShot([string]$Name,[int]$Key=73){
 $payload=Join-Path $out ($Name+'.input.json');@{key=$Key;durationMs=5000}|ConvertTo-Json -Compress|Set-Content $payload
 $receipt=Join-Path $out ($Name+'.held-input.json')
 $p=Start-Process -FilePath (Get-Command node).Source -ArgumentList @($cli,'game','window-input','--project','.','--instance','crate-windows-review','--payload-file',$payload,'--timeout-ms','180000','--json') -WindowStyle Hidden -PassThru -RedirectStandardOutput $receipt -RedirectStandardError (Join-Path $out ($Name+'.held-input.stderr.txt'))
 try{Start-Sleep -Milliseconds 2400;Crate-Shot $Name}finally{$p.WaitForExit()}
 $r=Get-Content $receipt -Raw|ConvertFrom-Json;if(-not $r.ok){throw 'Held-key capture input failed'}
}
function Read-PickReceipt([long]$Offset){
 $logPath=Join-Path $env:TEMP 'godot-cli/291e3f44b2ae/game-crate-windows-review.log'
 $watcher=New-Object IO.FileSystemWatcher (Split-Path $logPath),(Split-Path $logPath -Leaf);$watcher.EnableRaisingEvents=$true
 $stream=[IO.File]::Open($logPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite);$stream.Position=$Offset;$reader=New-Object IO.StreamReader $stream
 try{
  $s=$reader.ReadToEnd();if($s -notmatch 'GODMODE_SURVIVAL_PICK='){$event=$watcher.WaitForChanged([IO.WatcherChangeTypes]::Changed,10000);$s+=$reader.ReadToEnd()}
  $m=[regex]::Match($s,'GODMODE_SURVIVAL_PICK=([^:\r\n]+):([^:\r\n]+):([^\r\n]+)')
  if(-not $m.Success){throw 'No native pick receipt after choice'}
  return @{kind=$m.Groups[1].Value;id=$m.Groups[2].Value;line=$m.Value}
 }finally{$reader.Dispose();$stream.Dispose();$watcher.Dispose()}
}
function Crate-OfferSequence([int]$Count){
 $catalog=Get-Content (Join-Path $out 'crate-power-catalog.json') -Raw|ConvertFrom-Json
 $progress=@{};$records=@();$mixed=@{};$higher=@{};$maxed=@{};$weaponTarget=$null;$exclusiveTarget=$null
 function Normalize-Card([string]$s){return ($s.ToUpperInvariant() -replace '[^A-Z0-9]','')}
 $byName=@{};foreach($power in $catalog){$byName[(Normalize-Card $power.name)]=$power}
 for($n=1;$n -le $Count;$n++){
  Crate-Console 'lootbox';$name='crate-offer-'+$n.ToString('00');Crate-Shot $name
  $ocrRaw=& (Join-Path $out 'ocr-native.ps1') -Image (Join-Path $out ($name+'.png'));$ocrRaw|Set-Content (Join-Path $out ($name+'.ocr.json'));$ocr=$ocrRaw|ConvertFrom-Json
  $words=@($ocr.lines|ForEach-Object {$_.words});$cards=@();$compact=$true
  foreach($mode in @('compact','wide')){
   $cards=@();$rows=if($mode -eq 'compact'){2}else{1}
   for($row=0;$row -lt $rows;$row++){for($col=0;$col -lt 3;$col++){
    $top=if($mode -eq 'compact'){285+173*$row}else{390};$bottom=$top+39;$left=193+304*$col
    $title=($words|Where-Object {$_.height -ge 12 -and $_.y -ge $top -and $_.y -lt $bottom -and $_.x -ge $left -and $_.x -lt $left+288}|Sort-Object x|ForEach-Object {$_.text}) -join ' '
    $normalized=Normalize-Card $title
    if($byName.ContainsKey($normalized)){$cards+=@{index=($row*3+$col);title=$title;power=$byName[$normalized]}}
   }}
   if($cards.Count -gt 0){$compact=($mode -eq 'compact');break}
  }
  if(-not $cards.Count){throw ('OCR recognized no catalogue card in '+$name)}
  $colours=python (Join-Path $out 'tier-pixels.py') (Join-Path $out ($name+'.png')) $(if($compact){'compact'}else{'wide'})|ConvertFrom-Json
  foreach($card in $cards){$card.tier=$colours[$card.index].tier;if($maxed.ContainsKey($card.power.id)){throw ('Native offer contains maxed card '+$card.power.id)}}
  $pick=$cards|Where-Object {$weaponTarget -and $_.power.id -eq $weaponTarget}|Select-Object -First 1
  if(-not $pick){$pick=$cards|Where-Object {$exclusiveTarget -and $_.power.id -eq $exclusiveTarget}|Select-Object -First 1}
  if(-not $pick){$pick=$cards|Where-Object {$_.power.kind -eq 'weapon' -and -not $maxed.ContainsKey($_.power.id)}|Select-Object -First 1;if($pick){$weaponTarget=$pick.power.id}}
  if(-not $pick){$pick=$cards|Where-Object {$_.power.kind -eq 'exclusive'}|Select-Object -First 1;if($pick -and -not $exclusiveTarget){$exclusiveTarget=$pick.power.id}}
  if(-not $pick){$pick=$cards|Where-Object {$_.power.id -eq 'shield'}|Select-Object -First 1}
  if(-not $pick){$pick=$cards[0]}
  if($pick.index -gt 0){$keys=@();for($i=1;$i -lt $pick.index;$i++){$keys+=40};$payload=@{key=40};if($keys.Count){$payload.keysAfterText=$keys};Crate-Input $payload}
  Crate-Shot ($name+'-selected')
  $logPath=Join-Path $env:TEMP 'godot-cli/291e3f44b2ae/game-crate-windows-review.log';$offset=(Get-Item $logPath).Length
  Crate-Input @{key=(49+$pick.index)}
  $receipt=Read-PickReceipt $offset
  if($receipt.id -ne $pick.power.id){throw ('Native picked '+$receipt.id+' but OCR chose '+$pick.power.id)}
  $id=$pick.power.id;$power=$pick.power;$old=$progress[$id];if(-not $old){$old=@{picks=0;value=0}}
  $tierIndex=@{basic=0;pink=1;red=2;gold=3}[$pick.tier];$new=@{picks=($old.picks+1);value=([Math]::Min($power.cap,($old.value+$power.increments[$tierIndex])))}
  $progress[$id]=$new
  if($pick.tier -ne 'basic'){$higher[$id]=$true}elseif($higher.ContainsKey($id)){$mixed[$id]=$true}
  if($new.picks -ge $power.maxPicks -or ($power.cap -gt 0 -and $new.value -ge $power.cap)){$maxed[$id]=$true;if($weaponTarget -eq $id){$weaponTarget=$null};if($exclusiveTarget -eq $id){$exclusiveTarget=$null}}
  $record=@{offer=$n;image=($name+'.png');selectedImage=($name+'-selected.png');shown=@($cards|ForEach-Object {@{index=$_.index;id=$_.power.id;name=$_.title;tierFromPixels=$_.tier}});picked=$id;tierFromPixels=$pick.tier;expectedBeforeFromCatalog=$old;expectedAfterFromCatalog=$new;nativeReceipt=$receipt.line}
  $records+=$record;$record|ConvertTo-Json -Depth 7 -Compress|Add-Content (Join-Path $out 'crate-native-choices.jsonl')
  if($id -eq 'shield'){Crate-HeldShot ('armour-after-offer-'+$n)}
 }
 @{progressExpectedFromCatalog=$progress;basicAfterHigher=@($mixed.Keys);maxedExpectedFromCatalog=@($maxed.Keys);count=$records.Count}|ConvertTo-Json -Depth 8|Set-Content (Join-Path $out 'crate-sequence-summary.json')
 Get-Content (Join-Path $out 'crate-sequence-summary.json') -Raw|Write-Output
}
