$ErrorActionPreference='Stop'
$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$env:GODOTJS_PATH='C:\tools\GodotJS-4.6.1-v8-nopc-2\editor\godot.windows.editor.x86_64.exe'
$env:GODMODE_SESSION_ID='verify-2377-import-'+[guid]::NewGuid().ToString('N')
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
$out=$PSScriptRoot
$cli='tools/godot-cli/dist/src/index.js'
Copy-Item artifacts/prebuilt-arena/failure.json (Join-Path $out 'arena-cold-import-failure.json')
Copy-Item C:/Users/Kam/AppData/Local/Temp/godot-cli/291e3f44b2ae/game-prebuilt-arena-export.log (Join-Path $out 'arena-cold-import-client.log')
pnpm imports:seed
if($LASTEXITCODE -ne 0){throw 'Import cache seed failed'}
try {
    $m=Get-CimInstance Win32_OperatingSystem
    @{utc=[DateTime]::UtcNow.ToString('o');freeKiB=$m.FreePhysicalMemory}|ConvertTo-Json|Set-Content (Join-Path $out 'import-memory-gate.json')
    if($m.FreePhysicalMemory -lt 4*1024*1024){throw 'Below 4 GiB: defer import'}
    $raw=node $cli project import --project . --gpu-timeout-ms 3600000 --json
    $code=$LASTEXITCODE
    [IO.File]::WriteAllText((Join-Path $out 'native-import.json'),($raw -join [Environment]::NewLine))
    if($code -ne 0 -or -not (($raw -join '')|ConvertFrom-Json).ok){throw 'Native import failed'}
} finally {
    node $cli session end --json
}
& (Join-Path $out 'prebuild-export.ps1')
