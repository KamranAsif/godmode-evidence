import json,sys
from PIL import Image
im=Image.open(sys.argv[1]).convert('RGB')
result=[]
for i in range(6):
 x=193+(i%3)*304;y=(194+(i//3)*173) if len(sys.argv)<3 or sys.argv[2]=='compact' else 234
 pixels=[im.getpixel((xx,yy)) for yy in range(y+8,y+24) for xx in range(x+30,x+258)]
 votes={'pink':0,'red':0,'gold':0}
 for r,g,b in pixels:
  if r>90 and b>70 and r>1.8*g and b>1.7*g: votes['pink']+=1
  elif r>90 and r>1.7*g and r>1.7*b: votes['red']+=1
  elif r>100 and g>65 and r>1.8*b and g>1.8*b: votes['gold']+=1
 tier=max(votes,key=votes.get)
 result.append({'index':i,'tier':tier if votes[tier]>=6 else 'basic','colourVotes':votes})
print(json.dumps(result))
