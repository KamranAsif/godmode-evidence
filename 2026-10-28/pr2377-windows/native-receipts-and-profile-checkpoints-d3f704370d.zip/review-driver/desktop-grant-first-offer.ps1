$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$ErrorActionPreference='Stop'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
node "$PSScriptRoot/native-batch.mjs" "$PSScriptRoot/batch-desktop-grant.json"
if($LASTEXITCODE -ne 0){throw 'Desktop grant control failed'}
node "$PSScriptRoot/native-batch.mjs" "$PSScriptRoot/batch-all-owned-offer.json"
if($LASTEXITCODE -ne 0){throw 'Owned offer control failed'}
& "$PSScriptRoot/ocr-native.ps1" -Image "$PSScriptRoot/all-owned-first-offer.png"|Set-Content "$PSScriptRoot/all-owned-first-offer.ocr.json"
