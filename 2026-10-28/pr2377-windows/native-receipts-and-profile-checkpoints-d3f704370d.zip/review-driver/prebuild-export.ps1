$ErrorActionPreference='Stop'
$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$env:GODOTJS_PATH='C:\tools\GodotJS-4.6.1-v8-nopc-2\editor\godot.windows.editor.x86_64.exe'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
$out=$PSScriptRoot
$cli='tools/godot-cli/dist/src/index.js'
if(Test-Path (Join-Path $out 'debug-export.json')){Copy-Item (Join-Path $out 'debug-export.json') (Join-Path $out 'debug-export-failed-attempt1.json')}
pnpm build:scripts
if($LASTEXITCODE -ne 0){throw 'Build failed'}
$cliFile=(Resolve-Path tools/godot-cli/dist/src/cli.js).Path
$text=[IO.File]::ReadAllText($cliFile)
$old='executablePath = firstFlag < 0 ? trimmed : trimmed.slice(0, firstFlag);'
$new='executablePath = /^(.+?\.exe)(?:\s|$)/i.exec(trimmed)?.[1] ?? (firstFlag < 0 ? trimmed : trimmed.slice(0, firstFlag));'
if($text.Contains($old)){[IO.File]::WriteAllText($cliFile,$text.Replace($old,$new))}
$env:GODMODE_SESSION_ID='verify-2377-arena-'+[guid]::NewGuid().ToString('N')
node (Join-Path $out 'hold.mjs')|Set-Content (Join-Path $out 'arena-hold.json')
if($LASTEXITCODE -ne 0){throw 'Arena capture hold failed'}
try {
    $m=Get-CimInstance Win32_OperatingSystem
    @{utc=[DateTime]::UtcNow.ToString('o');freeKiB=$m.FreePhysicalMemory}|ConvertTo-Json|Set-Content (Join-Path $out 'arena-memory-gate.json')
    if($m.FreePhysicalMemory -lt 4*1024*1024){throw 'Below 4 GiB: defer generation'}
    node tools/maps/prebuilt/build.mjs --ensure --strict
    if($LASTEXITCODE -ne 0){throw 'Native arena generation failed'}
} finally {
    node $cli game stop --project . --instance prebuilt-arena-export --json
    node $cli gpu release --json
    node $cli session end --json
}
# Export preflight and shader baking run outside the earlier generation hold.
$session=(node $cli session new --json|ConvertFrom-Json).data.sessionId
$env:GODMODE_SESSION_ID=$session
[IO.File]::WriteAllText((Join-Path $out 'session.txt'),$session)
try {
    $m=Get-CimInstance Win32_OperatingSystem
    @{utc=[DateTime]::UtcNow.ToString('o');freeKiB=$m.FreePhysicalMemory}|ConvertTo-Json|Set-Content (Join-Path $out 'export-memory-gate.json')
    if($m.FreePhysicalMemory -lt 4*1024*1024){throw 'Below 4 GiB: defer export'}
    $binary=Join-Path $out 'debug/BattleDuty.exe'
    $raw=node $cli game export --project . --session $session --preset 'Windows Desktop' --debug --output $binary --gpu-timeout-ms 3600000 --json
    $code=$LASTEXITCODE
    [IO.File]::WriteAllText((Join-Path $out 'debug-export.json'),($raw -join [Environment]::NewLine))
    if($code -ne 0 -or -not (($raw -join '')|ConvertFrom-Json).ok){throw 'Debug export failed'}
    Get-FileHash $binary -Algorithm SHA256|ConvertTo-Json|Set-Content (Join-Path $out 'debug-sha256.json')
    git status --short|Set-Content (Join-Path $out 'post-export-git-status.txt')
    Get-Content (Join-Path $out 'debug-sha256.json')
} finally {
    node $cli session end --session $session --json
}
