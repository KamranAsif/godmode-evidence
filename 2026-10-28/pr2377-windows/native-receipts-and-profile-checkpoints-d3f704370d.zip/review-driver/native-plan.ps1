param([Parameter(Mandatory=$true)][string]$Plan)
$env:GODMODE_GPU_CAPTURE_LIMIT='3'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
. (Join-Path $PSScriptRoot 'control.ps1')
$planData=Get-Content -LiteralPath $Plan -Raw|ConvertFrom-Json
try {
    if($planData.renew){node (Join-Path $out 'hold.mjs')|Set-Content (Join-Path $out 'ui-renewed-hold.json');if($LASTEXITCODE -ne 0){throw 'Hold renewal failed'}}
    foreach($step in $planData.steps){
        if($step.input){$h=@{};foreach($p in $step.input.PSObject.Properties){$h[$p.Name]=$p.Value};Crate-Input $h}
        if($step.console){Crate-Console ([string]$step.console)}
        if($step.waitMs){Start-Sleep -Milliseconds ([int]$step.waitMs)}
        if($step.shot){Crate-Shot ([string]$step.shot)}
    }
    if($planData.cleanup){Crate-Cleanup}
} catch {Crate-Cleanup;throw}
