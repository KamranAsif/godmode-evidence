$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$ErrorActionPreference='Stop'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
node "$PSScriptRoot/native-batch.mjs" "$PSScriptRoot/batch-prepurchase-pool.json"
if($LASTEXITCODE -ne 0){throw 'Prepurchase offers failed'}
node "$PSScriptRoot/native-batch.mjs" "$PSScriptRoot/batch-glass-purchase.json"
if($LASTEXITCODE -ne 0){throw 'Purchase input failed'}
$before=Get-Content "$PSScriptRoot/purchase-before.meta.save" -Raw|ConvertFrom-Json
$after=Get-Content "$PSScriptRoot/purchase-after.meta.save" -Raw|ConvertFrom-Json
$second=Get-Content "$PSScriptRoot/purchase-second-click.meta.save" -Raw|ConvertFrom-Json
$result=@{before=$before.dollars;after=$after.dollars;delta=($after.dollars-$before.dollars);secondClick=$second.dollars;owned=($after.unlocked -contains 'glassCannon');passed=($after.dollars -eq $before.dollars-400 -and $second.dollars -eq $after.dollars -and $after.unlocked -contains 'glassCannon')}
$result|ConvertTo-Json|Set-Content "$PSScriptRoot/glass-purchase-arithmetic.json"
$result|ConvertTo-Json
if(-not $result.passed){throw 'Glass Cannon purchase did not meet receipt assertions'}
