param([string]$Request)
$ErrorActionPreference = 'Stop'
$requestData = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Request)) | ConvertFrom-Json
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Threading;
using System.Diagnostics;
using System.Globalization;
using System.Text;
public static class GameWindow {
    public delegate bool EnumProc(IntPtr h, IntPtr p);
    [StructLayout(LayoutKind.Sequential)] public struct Rect { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] public struct Point { public int X, Y; }
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr p);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr h, out Rect r);
    [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr h, IntPtr dc, uint flags);
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
    [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] static extern bool AttachThreadInput(uint from, uint to, bool attach);
    [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
    [DllImport("user32.dll")] static extern IntPtr SetFocus(IntPtr h);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
    [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr h, int i, int v);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int height, uint flags);
    [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr h, ref Point p);
    [DllImport("user32.dll")] static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] static extern bool GetCursorPos(out Point p);
    [DllImport("user32.dll")] static extern void keybd_event(byte key, byte scan, uint flags, UIntPtr extra);
    [DllImport("user32.dll")] static extern void mouse_event(uint flags, uint x, uint y, uint data, UIntPtr extra);
    [DllImport("user32.dll")] static extern short VkKeyScan(char c);
    [DllImport("user32.dll")] static extern uint MapVirtualKey(uint key, uint type);
    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    public static IntPtr Find(int pid) {
        SetProcessDPIAware();
        IntPtr found = IntPtr.Zero;
        long area = 0;
        EnumWindows(delegate(IntPtr h, IntPtr p) {
            uint owner; GetWindowThreadProcessId(h, out owner);
            Rect r; GetClientRect(h, out r);
            long size = (long)(r.Right-r.Left)*(r.Bottom-r.Top);
            if (owner == pid && IsWindowVisible(h) && size > area) { found = h; area = size; }
            return true;
        }, IntPtr.Zero);
        if (found == IntPtr.Zero) throw new Exception("No visible window for the verified game PID; wait for startup (or omit --headless)");
        return found;
    }
    public static void Windowed(IntPtr h, bool offscreen, int width, int height) {
        ShowWindow(h, 9);
        int style = GetWindowLong(h, -16);
        SetWindowLong(h, -16, offscreen ? (style & ~0x00CF0000) : ((style & unchecked((int)~0x80000000)) | 0x00CF0000));
        // Keep the same 32-pixel drawable corner as inspected captures. Fully
        // offscreen windows can stop presenting, leaving stale FPS evidence.
        SetWindowPos(h, IntPtr.Zero, offscreen ? 32-width : 50, offscreen ? 32-height : 50, offscreen ? width : 1296, offscreen ? height : 759, 0x0034);
        if (offscreen) {
            // Some window themes retain a non-client edge after the style change.
            // Requested capture dimensions describe the drawable client, not the outer window.
            int outerWidth = width, outerHeight = height;
            for (int attempt = 0; attempt < 3; attempt++) {
                Thread.Sleep(100);
                Rect client;
                if (!GetClientRect(h, out client)) throw new Exception("Cannot measure resized game client");
                int missingWidth = width - (client.Right-client.Left);
                int missingHeight = height - (client.Bottom-client.Top);
                if (missingWidth == 0 && missingHeight == 0) return;
                outerWidth += missingWidth; outerHeight += missingHeight;
                SetWindowPos(h, IntPtr.Zero, 32-outerWidth, 32-outerHeight, outerWidth, outerHeight, 0x0034);
            }
            Rect finalClient;
            if (!GetClientRect(h, out finalClient) || finalClient.Right-finalClient.Left != width || finalClient.Bottom-finalClient.Top != height)
                throw new Exception("Game client did not reach the requested capture dimensions");
        }
    }
    public static void Focus(IntPtr h) {
        if (IsIconic(h)) ShowWindow(h, 9);
        SetForegroundWindow(h);
        Thread.Sleep(100);
        if (GetForegroundWindow() != h) {
            // A native Alt tap releases Windows foreground locking without attaching
            // input queues to a busy peer renderer. Always verify the target below.
            Key(18, 20);
            SetForegroundWindow(h);
            Thread.Sleep(150);
        }
        if (GetForegroundWindow() != h) throw new Exception("Windows refused to foreground the game; no input was sent");
    }
    public static void Key(int key, int ms) {
        byte scan = (byte)MapVirtualKey((uint)key, 0);
        uint extended = (key >= 33 && key <= 40) || key == 45 || key == 46 ? 1u : 0u;
        keybd_event((byte)key, scan, extended, UIntPtr.Zero);
        try { Thread.Sleep(ms); } finally { keybd_event((byte)key, scan, extended | 2u, UIntPtr.Zero); }
    }
    public static void Text(string text) {
        foreach (char c in text) {
            short mapped = VkKeyScan(c);
            if (mapped == -1 || (mapped >> 8) > 1) throw new Exception("Text character unavailable on current keyboard layout");
            bool shift = (mapped & 0x100) != 0;
            if (shift) keybd_event(16, 0, 0, UIntPtr.Zero);
            try { Key(mapped & 255, 20); } finally { if (shift) keybd_event(16, 0, 2, UIntPtr.Zero); }
        }
    }
    public static void PointAt(IntPtr h, int x, int y) {
        Rect r; GetClientRect(h, out r);
        if (x >= r.Right || y >= r.Bottom) throw new Exception("Pointer lies outside game client");
        Point p = new Point { X=x, Y=y }; ClientToScreen(h, ref p); SetCursorPos(p.X,p.Y); Thread.Sleep(50); Point actual; GetCursorPos(out actual); if(actual.X != p.X || actual.Y != p.Y) throw new Exception("Windows clamped native cursor: wanted "+p.X+","+p.Y+" got "+actual.X+","+actual.Y+"; move owned window onscreen after startup");
    }
    public static void Click(IntPtr h, int x, int y) {
        PointAt(h,x,y); Thread.Sleep(150);
        mouse_event(2,0,0,0,UIntPtr.Zero); Thread.Sleep(80); mouse_event(4,0,0,0,UIntPtr.Zero);
    }
    public static void Wheel(int clicks) { mouse_event(0x0800,0,0,unchecked((uint)(clicks*120)),UIntPtr.Zero); }
    public static void Right(bool down) { mouse_event(down ? 8u : 16u,0,0,0,UIntPtr.Zero); }
    public static void Move(int dx, int dy) { mouse_event(1,unchecked((uint)dx),unchecked((uint)dy),0,UIntPtr.Zero); }
    public static void Fire(int ms) {
        mouse_event(2,0,0,0,UIntPtr.Zero);
        try { Thread.Sleep(ms); } finally { mouse_event(4,0,0,0,UIntPtr.Zero); }
    }
    public static string Capture(IntPtr h, string output) {
        if (IsIconic(h)) throw new Exception("Game window is minimized; restore it before capture");
        Rect r; GetClientRect(h, out r);
        int w=r.Right-r.Left, height=r.Bottom-r.Top;
        if (w <= 0 || height <= 0) throw new Exception("Game has an empty client area");
        using (Bitmap bitmap = new Bitmap(w,height,PixelFormat.Format32bppArgb)) {
            using (Graphics graphics = Graphics.FromImage(bitmap)) {
                IntPtr dc = graphics.GetHdc();
                try { if (!PrintWindow(h,dc,3)) throw new Exception("PrintWindow failed (PW_CLIENTONLY | PW_RENDERFULLCONTENT)"); }
                finally { graphics.ReleaseHdc(dc); }
            }
            bool content = false;
            for (int y=0; y<height && !content; y+=Math.Max(1,height/32))
                for (int x=0; x<w; x+=Math.Max(1,w/32)) {
                    Color pixel = bitmap.GetPixel(x,y);
                    if (pixel.R+pixel.G+pixel.B > 0) { content=true; break; }
                }
            if (!content) throw new Exception("PrintWindow returned a black frame; no evidence was written");
            bitmap.Save(output,ImageFormat.Png);
        }
        return "{\"method\":\"PrintWindow/PW_RENDERFULLCONTENT\",\"width\":"+w+",\"height\":"+height+",\"hwnd\":\""+h+"\"}";
    }
    public static string Record(IntPtr h, string output, int durationMs, string ffmpeg) {
        if (IsIconic(h)) throw new Exception("Game window is minimized");
        Rect r; GetClientRect(h, out r);
        int w=r.Right-r.Left, height=r.Bottom-r.Top;
        if (w <= 0 || height <= 0 || w%2 != 0 || height%2 != 0) throw new Exception("Recording requires an even, non-empty client size");
        ProcessStartInfo start = new ProcessStartInfo(ffmpeg,
            "-hide_banner -loglevel error -n -f rawvideo -pixel_format bgra -video_size "+w+"x"+height+
            " -framerate 30 -i pipe:0 -an -c:v libx264 -preset ultrafast -crf 18 -pix_fmt yuv420p -movflags +faststart \""+output+"\"");
        start.UseShellExecute=false; start.CreateNoWindow=true; start.RedirectStandardInput=true;
        start.RedirectStandardError=true;
        using (Process encoder = Process.Start(start)) {
            var errors = encoder.StandardError.ReadToEndAsync();
            int frames=durationMs*30/1000;
            byte[] pixels = new byte[w*height*4];
            string startedAt=DateTime.UtcNow.ToString("o");
            StringBuilder timing=new StringBuilder();
            Stopwatch clock = Stopwatch.StartNew();
            try {
                using (Bitmap bitmap = new Bitmap(w,height,PixelFormat.Format32bppArgb))
                using (Graphics graphics = Graphics.FromImage(bitmap)) {
                    for (int frame=0; frame<frames; frame++) {
                        int wait=(int)(frame*1000.0/30-clock.Elapsed.TotalMilliseconds);
                        if (wait>0) Thread.Sleep(wait);
                        double startedMs=clock.Elapsed.TotalMilliseconds;
                        Rect current; GetClientRect(h, out current);
                        if (IsIconic(h) || current.Right != w || current.Bottom != height) throw new Exception("Game window changed during recording");
                        IntPtr dc=graphics.GetHdc();
                        try { if (!PrintWindow(h,dc,3)) throw new Exception("PrintWindow failed during recording"); }
                        finally { graphics.ReleaseHdc(dc); }
                        double capturedMs=clock.Elapsed.TotalMilliseconds;
                        if (frame==0) {
                            bool content=false;
                            for (int y=0; y<height && !content; y+=Math.Max(1,height/32))
                                for (int x=0; x<w; x+=Math.Max(1,w/32)) {
                                    Color c=bitmap.GetPixel(x,y);
                                    if (c.R+c.G+c.B>0) { content=true; break; }
                                }
                            if (!content) throw new Exception("PrintWindow returned a black frame");
                        }
                        BitmapData data=bitmap.LockBits(new Rectangle(0,0,w,height),ImageLockMode.ReadOnly,PixelFormat.Format32bppArgb);
                        try { Marshal.Copy(data.Scan0,pixels,0,pixels.Length); }
                        finally { bitmap.UnlockBits(data); }
                        encoder.StandardInput.BaseStream.Write(pixels,0,pixels.Length);
                        if (frame>0) timing.Append(',');
                        timing.Append("{\"frame\":").Append(frame).Append(",\"requestedMs\":").Append((frame*1000.0/30).ToString("F3",CultureInfo.InvariantCulture))
                            .Append(",\"startedMs\":").Append(startedMs.ToString("F3",CultureInfo.InvariantCulture))
                            .Append(",\"capturedMs\":").Append(capturedMs.ToString("F3",CultureInfo.InvariantCulture))
                            .Append(",\"writtenMs\":").Append(clock.Elapsed.TotalMilliseconds.ToString("F3",CultureInfo.InvariantCulture)).Append('}');
                    }
                }
                double elapsed=clock.Elapsed.TotalMilliseconds;
                encoder.StandardInput.Close();
                if (!encoder.WaitForExit(15000)) throw new Exception("Video encoder timed out");
                if (encoder.ExitCode!=0) throw new Exception("Video encoder failed: "+errors.Result);
                if (elapsed>durationMs*1.15) throw new Exception("Capture could not sustain 30 FPS: elapsed "+elapsed+" ms; do not use this clip as real-time evidence");
                return "{\"method\":\"PrintWindow/PW_RENDERFULLCONTENT\",\"width\":"+w+",\"height\":"+height+",\"fps\":30,\"frames\":"+frames+
                    ",\"startedAt\":\""+startedAt+"\",\"elapsedMs\":"+Math.Round(elapsed)+",\"frameTiming\":["+timing+"]}";
            } finally {
                if (!encoder.HasExited) { encoder.StandardInput.Close(); if (!encoder.WaitForExit(2000)) encoder.Kill(); }
            }
        }
    }
}
'@
$deadline = [DateTime]::UtcNow.AddMilliseconds($requestData.waitMs)
while ($true) {
    try { $window = [GameWindow]::Find($requestData.pid); break }
    catch {
        if ([DateTime]::UtcNow -ge $deadline) { throw }
        if (-not (Get-Process -Id $requestData.pid -ErrorAction SilentlyContinue)) { throw 'Game exited before opening a window' }
        Start-Sleep -Milliseconds 100
    }
}
if ($requestData.recordOutput) {
    [GameWindow]::Record($window, $requestData.recordOutput, $requestData.durationMs, $requestData.ffmpeg)
} elseif ($requestData.output) {
    [GameWindow]::Capture($window, $requestData.output)
} else {
    if ($requestData.windowed -or $requestData.offscreen) {
        $captureWidth = 1280
        $captureHeight = 720
        if ($null -ne $requestData.size) { $captureWidth = [int]$requestData.size[0]; $captureHeight = [int]$requestData.size[1] }
        [GameWindow]::Windowed($window, [bool]$requestData.offscreen, $captureWidth, $captureHeight)
    }
    if ($requestData.key -or $requestData.text -or $null -ne $requestData.click -or $null -ne $requestData.pointAt -or $null -ne $requestData.rightButton -or $null -ne $requestData.mouseMove -or $requestData.fireMs) { [GameWindow]::Focus($window) }
    $duration = 100
    if ($requestData.durationMs) { $duration = $requestData.durationMs }
    if ($requestData.key) { [GameWindow]::Key($requestData.key, $duration) }
    if ($requestData.text) { Start-Sleep -Milliseconds 300; [GameWindow]::Text($requestData.text) }
    foreach ($nativeKey in $requestData.keysAfterText) { [GameWindow]::Key([int]$nativeKey, 100); Start-Sleep -Milliseconds 500 }
    if ($null -ne $requestData.pointAt) { [GameWindow]::PointAt($window, $requestData.pointAt[0], $requestData.pointAt[1]) }
    if ($null -ne $requestData.wheel) { [GameWindow]::Wheel([int]$requestData.wheel) }
    if ($null -ne $requestData.click) { [GameWindow]::Click($window, $requestData.click[0], $requestData.click[1]) }
    if ($null -ne $requestData.rightButton) { [GameWindow]::Right($requestData.rightButton) }
    if ($null -ne $requestData.mouseMove) { [GameWindow]::Move($requestData.mouseMove[0], $requestData.mouseMove[1]) }
    if ($requestData.fireMs) { [GameWindow]::Fire($requestData.fireMs) }
    if ($requestData.afterFireKey) { [GameWindow]::Key($requestData.afterFireKey, $duration) }
    @{ pid=$requestData.pid; hwnd="$window"; accepted=$true } | ConvertTo-Json -Compress
}
