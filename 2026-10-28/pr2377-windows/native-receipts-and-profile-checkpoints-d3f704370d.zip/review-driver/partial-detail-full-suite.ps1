$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$ErrorActionPreference='Stop'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
node "$PSScriptRoot/native-batch.mjs" "$PSScriptRoot/batch-partial-detail.json"
$nativeCode=$LASTEXITCODE
pnpm test *> "$PSScriptRoot/pnpm-test.txt"
$testCode=$LASTEXITCODE
Get-Content "$PSScriptRoot/pnpm-test.txt" -Tail 25
@{nativeDetailExit=$nativeCode;pnpmTestExit=$testCode}|ConvertTo-Json|Set-Content "$PSScriptRoot/final-suite-exit-codes.json"
if($nativeCode -ne 0 -or $testCode -ne 0){throw 'Review/control or full suite failed; retained receipts identify each result'}
