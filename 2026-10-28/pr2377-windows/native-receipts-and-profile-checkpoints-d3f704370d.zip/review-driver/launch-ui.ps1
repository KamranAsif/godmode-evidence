$env:GODMODE_GPU_CAPTURE_LIMIT='3'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
$out=$PSScriptRoot
$cli='tools/godot-cli/dist/src/index.js'
$env:GODMODE_SESSION_ID='verify-2377-ui-'+[guid]::NewGuid().ToString('N')
[IO.File]::WriteAllText((Join-Path $out 'ui-session.txt'),$env:GODMODE_SESSION_ID)
node $cli game ps --all --json|Set-Content (Join-Path $out 'ui-preflight.json')
node (Join-Path $out 'hold.mjs')|Set-Content (Join-Path $out 'ui-hold.json')
if($LASTEXITCODE -ne 0){throw 'UI hold failed'}
. (Join-Path $out 'control.ps1')
try {
    $m=Get-CimInstance Win32_OperatingSystem
    @{utc=[DateTime]::UtcNow.ToString('o');freeKiB=$m.FreePhysicalMemory}|ConvertTo-Json|Set-Content (Join-Path $out 'ui-memory-gate.json')
    if($m.FreePhysicalMemory -lt 4*1024*1024){throw 'Below 4 GiB: defer launch'}
    $profile=Join-Path $out 'review.settings.cfg'
    $binary=Join-Path $out 'debug/BattleDuty.exe'
    $raw=node $cli game run --project . --binary $binary --instance crate-windows-review --session $env:GODMODE_SESSION_ID --offscreen --settings-path $profile --json
    $code=$LASTEXITCODE
    [IO.File]::WriteAllText((Join-Path $out 'ui-launch.json'),($raw -join [Environment]::NewLine))
    if($code -ne 0 -or -not (($raw -join '')|ConvertFrom-Json).ok){throw ($raw -join '')}
    Start-Sleep -Seconds 35
    Crate-Input @{windowed=$true}
    Crate-Shot 'opening-profile'
} catch {Crate-Cleanup;throw}
