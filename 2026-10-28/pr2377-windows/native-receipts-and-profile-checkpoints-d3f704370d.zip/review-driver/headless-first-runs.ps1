$ErrorActionPreference='Stop'
$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$env:GODOTJS_PATH='C:\tools\GodotJS-4.6.1-v8-nopc-2\editor\godot.windows.editor.x86_64.exe'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
$out=$PSScriptRoot
. (Join-Path $out 'memory-gate.ps1')
$receipts=@()
foreach($seed in @('1871','2853137488')){
    Wait-ReviewMemory (Join-Path $out 'headless-memory-gates.jsonl')
    $env:GODMODE_SESSION_ID='verify-2377-headless-'+$seed+'-'+[guid]::NewGuid().ToString('N')
    $env:GODMODE_PLAYABILITY_SEED=$seed
    Remove-Item Env:GODMODE_GRUNT_METER_SECONDS -ErrorAction SilentlyContinue
    $before=@(Get-ChildItem artifacts/first-run-playability -Directory -ErrorAction SilentlyContinue|ForEach-Object Name)
    $started=[DateTime]::UtcNow.ToString('o')
    $raw=pnpm test:first-run-playability
    $code=$LASTEXITCODE
    [IO.File]::WriteAllText((Join-Path $out ('first-run-'+$seed+'.log')),($raw -join [Environment]::NewLine))
    $dest=Join-Path $out ('first-run-'+$seed)
    New-Item -ItemType Directory -Force $dest|Out-Null
    $produced=@(Get-ChildItem artifacts/first-run-playability -Directory -ErrorAction SilentlyContinue|Where-Object {$_.Name -notin $before})
    foreach($dir in $produced){foreach($name in @('result.json','engine.log')){if(Test-Path (Join-Path $dir.FullName $name)){Copy-Item -LiteralPath (Join-Path $dir.FullName $name) -Destination (Join-Path $dest $name)}}}
    node tools/godot-cli/dist/src/index.js session end --json
    $receipts+=@{seed=$seed;exitCode=$code;startedUtc=$started;endedUtc=[DateTime]::UtcNow.ToString('o');sessionDirectories=@($produced|ForEach-Object Name);scope='headless first-run check; no GPU hold'}
    $receipts|ConvertTo-Json -Depth 8|Set-Content (Join-Path $out 'first-run-checks.json')
    Write-Output ('First-run seed '+$seed+' exit '+$code)
}
if(@($receipts|Where-Object exitCode -ne 0).Count){throw 'One or more first-run checks failed; see retained per-seed results'}
