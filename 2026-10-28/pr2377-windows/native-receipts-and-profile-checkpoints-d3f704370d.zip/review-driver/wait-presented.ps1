function Wait-ReviewPresented([string]$LogPath,[int]$OwnedPid){
    $watcher=New-Object IO.FileSystemWatcher (Split-Path $LogPath),(Split-Path $LogPath -Leaf)
    $watcher.NotifyFilter=[IO.NotifyFilters]::LastWrite -bor [IO.NotifyFilters]::Size
    $eventId='crate-presented-'+[guid]::NewGuid().ToString('N')
    $subscription=Register-ObjectEvent $watcher Changed -SourceIdentifier $eventId
    $watcher.EnableRaisingEvents=$true
    $stream=[IO.File]::Open($LogPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
    $reader=New-Object IO.StreamReader $stream
    try{
        $seen=''
        while($true){
            $seen+=$reader.ReadToEnd()
            if($seen.Contains('GODMODE_FIRST_PRESENTED_GAMEPLAY_FRAME=')){
                @{utc=[DateTime]::UtcNow.ToString('o');pid=$OwnedPid;marker='GODMODE_FIRST_PRESENTED_GAMEPLAY_FRAME';wait='FileSystemWatcher Changed events'}|ConvertTo-Json -Compress|Add-Content (Join-Path $PSScriptRoot 'presented-receipts.jsonl')
                return
            }
            if(-not (Get-Process -Id $OwnedPid -ErrorAction SilentlyContinue)){throw 'Owned game exited before presented frame'}
            $event=Wait-Event -SourceIdentifier $eventId
            Remove-Event -EventIdentifier $event.EventIdentifier
        }
    }finally{
        $reader.Dispose();$stream.Dispose();Unregister-Event -SourceIdentifier $eventId
        Get-Event -SourceIdentifier $eventId -ErrorAction SilentlyContinue|Remove-Event
        $watcher.Dispose()
    }
}
