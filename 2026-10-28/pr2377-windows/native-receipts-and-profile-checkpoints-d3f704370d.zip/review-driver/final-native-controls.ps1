$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$ErrorActionPreference='Stop'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
node "$PSScriptRoot/native-batch.mjs" "$PSScriptRoot/batch-headshot-negative.json"
$headshotCode=$LASTEXITCODE
node "$PSScriptRoot/native-batch.mjs" "$PSScriptRoot/batch-exhaustion-control.json"
$exhaustionCode=$LASTEXITCODE
@{headshotExit=$headshotCode;exhaustionExit=$exhaustionCode}|ConvertTo-Json|Set-Content "$PSScriptRoot/final-controls-exit-codes.json"
if($headshotCode -ne 0 -or $exhaustionCode -ne 0){throw 'One or more final native controls failed; receipts retained'}
