import {readFile} from 'node:fs/promises';
import {upgradeCollection,upgradeGroups} from '../../packages/game-rules/dist/src/app_upgrades.js';
const out='artifacts/crate-tiers-windows';
const meta=JSON.parse(await readFile(`${out}/review.settings.meta.save`));
const channel=JSON.parse(await readFile(`${out}/review.settings.channel.save`));
for(const group of upgradeGroups(upgradeCollection(meta,channel.achievements.unlocked,channel.achievements.stats).filter(i=>i.discovery.visible))){
 const items=group.items.filter(i=>i.discovery.requirement);
 if(items.length)console.log(group.name+': '+items.map(i=>`${i.id}[${i.progress}]`).join(','));
}
