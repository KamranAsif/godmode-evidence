$env:GODMODE_GPU_CAPTURE_LIMIT='3'
$ErrorActionPreference='Stop'
Set-Location 'D:\work\godmode-roguelite-worktrees\verify-2377-20261028'
& "$PSScriptRoot/ui-batch.ps1" -Plan "$PSScriptRoot/batch-skip-and-progress.json"
node --test packages/game-rules/dist/test/achievement_stats.test.js packages/game-rules/dist/test/app_upgrades.test.js packages/game-rules/dist/test/cheat_shop.test.js packages/game-rules/dist/test/streak_loadout.test.js packages/game-rules/dist/test/supply_drops.test.js packages/game-rules/dist/test/survival_meta.test.js *> "$PSScriptRoot/targeted-crate-tests.txt"
$code=$LASTEXITCODE
Get-Content "$PSScriptRoot/targeted-crate-tests.txt" -Tail 10
if($code -ne 0){throw 'Targeted crate tests failed; see retained output'}
