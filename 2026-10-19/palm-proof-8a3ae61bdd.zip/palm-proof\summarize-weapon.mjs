import {readFileSync,writeFileSync,existsSync} from 'node:fs';
const label=process.argv[2]??'weapon-phases';
const dir='artifacts/enemy-cost/'+label+'/';
const report=[];
for(const name of ['normal-1','normal-2']) {
 if(!existsSync(dir+name+'-physics.json'))continue;
 const raw=JSON.parse(readFileSync(dir+name+'-frames-raw.json'));
 const physics=JSON.parse(readFileSync(dir+name+'-physics.json')).result;
 const frames=new Map();
 for(const hitch of physics.frameProfile.hitches)for(const frame of hitch.frames)
  if(frame.atMs>=raw.windowStartedMs&&frame.atMs<=raw.windowEndedMs)frames.set(frame.frame,frame);
 const totals={};
 for(const frame of frames.values())for(const [key,value]of Object.entries(frame.systems)){
  if(!key.startsWith('weapon.')&&!key.startsWith('presentation.'))continue;
  const total=totals[key]??={ms:0,calls:0};total.ms+=value.ms;total.calls+=value.calls;
 }
 const stages=Object.entries(totals).map(([stage,sum])=>({stage,perDrawMs:sum.ms/frames.size,callsPerDraw:sum.calls/frames.size,perCallMs:sum.ms/sum.calls})).sort((a,b)=>b.perDrawMs-a.perDrawMs);
 const row={name,totalFrames:raw.frames,hitchCoveredFrames:frames.size,coverage:frames.size/raw.frames,meanMs:raw.meanMs??JSON.parse(readFileSync(dir+name+'-frames.json')).meanMs,stages};
 report.push(row);console.log(JSON.stringify(row));
}
writeFileSync('artifacts/'+label+'-summary.json',JSON.stringify(report,null,2));
