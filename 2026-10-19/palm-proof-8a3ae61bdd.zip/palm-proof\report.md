# Native world-body palm fitting

The next isolated enemy presentation cost after the render audit was fitting
both palms to the rifle. Each fit performed the same two-bone hinge solve using
many TypeScript-to-engine vector, transform and skeleton calls. The new path
keeps that solve in GDScript and caches the three bone indices per arm. It also
serves third-person player world bodies. First-person arm controls are unchanged.

The solver, grip targets, skeletons, meshes, materials, shadows, animation
cadence and attachment publication are unchanged. Animation remains full rate
inside 30 m. There are no map, AI, navigation or network changes.

## Measurement

Final controls use main `944e04b97` (including #2131, #2138 and #2139), the same cached arena
SHA-256 `70b12712bc54db1e3cc58927997fa4535fabb7d737bcfcf5d04bfcb77299085b`,
seed `1136293662`, and 65 living riflemen. The fixed street camera looks toward
five columns initially 9-30.6 m away. Both windows assert 65 living enemies
before and after measurement. Settings are full detail, 1920x1080, scale 1,
uncapped, no VSync, D3D12 Forward+ on the AMD Radeon RX 9070 XT. Each run has a
15-second settling period and two 8-second windows with 2-second warmups.
Each exclusive timing hold is limited to six minutes and released after stopping
the owned renderer.

Final whole-frame measurements and source manifests are in the linked PR proof.

| Final trace-free measurement | Main `944e04b97` | Native palm fit |
| --- | ---: | ---: |
| Whole frame mean | 59.434 ms | 62.461 ms |
| Whole frame p95 | 73.137 ms | 76.286 ms |
| Recorded frames | 271 | 258 |
| Weapon stage per drawn frame, window 1 | 8.292 ms | 6.809 ms |
| Weapon stage per drawn frame, window 2 | 7.320 ms | 5.972 ms |

The weapon stage saves 1.35-1.48 ms per recorded crowd frame, approximately
17% per weapon-pose call. Its hitch-history coverage is 100%/96.6% before and
98.4%/100% after. The full frame mean and p95 increase, while server CPU time
also increases by 1.35/2.76 ms per frame. These runs do not establish an overall
FPS improvement. Both revisions retain the same AI and physics code, but the
live fight is not a deterministic replay of every movement and collision.

The earlier `624ba6dcf` control was 63.208 ms mean, 83.800 ms p95 across 254
frames; it is not the final comparison. After the frozen pair completed, the PR
was rebased onto merged #2140. That adds its independently verified flat-step
probe reuse; none of this PR's four runtime files change in that rebase.

Separate diagnostic windows on `624ba6dcf` isolate the palm fits with identical
temporary timing spans on both revisions:

| Measurement | Original TypeScript | Native solver |
| --- | ---: | ---: |
| One palm fit, window 1 | 0.02470 ms | 0.00867 ms |
| One palm fit, window 2 | 0.02213 ms | 0.00857 ms |
| All palm fits per drawn frame, window 1 | 2.742 ms | 0.966 ms |
| All palm fits per drawn frame, window 2 | 2.436 ms | 0.960 ms |

This is approximately 63% less CPU time per fit and an observed 1.5-1.8 ms per
crowd frame. Diagnostic hitch-history coverage is 100% in both control windows
and 79.6%/100% in the native windows. The final benchmark removes these temporary
timers. Whole-frame variation is larger than the isolated saving, so the full
frame delta is an observation rather than an attribution to this kernel alone.

## Pose and build verification

The standalone fixture compares the original TypeScript solver with the native
solver on assault, breach and marksman production rigs: seven clips, both arms,
and twelve time/target combinations, including torso overrides, negative and
nonuniform scales, unreachable targets and degenerate reaches. All 504 cases
pass. Maximum position error is `5.724839411413996e-7 m`, maximum basis-column
error is `0.00002176578163926024`, and residual error is
`1.6391277313232422e-7 m`.

After importing and building scripts, run the fixture using an owned session:

```powershell
$env:GODMODE_SESSION_ID = '<owned-session>'
$fixture = node tools/godot-cli/dist/src/index.js game run --project . --headless --instance palm-equivalence --scene res://tests/fixtures/enemy_palm_equivalence.tscn --json | ConvertFrom-Json
# The fixture exits itself. Wait for ENEMY_PALM_EQUIVALENCE in $fixture.data.logPath,
# and require its pass:true result before removing the completed instance record.
node tools/godot-cli/dist/src/index.js game stop --project . --instance palm-equivalence --json
```

Its engine log reports:

```json
{"cases":504,"maxPositionError":5.724839411413996e-7,"maxBasisError":0.00002176578163926024,"maxResidualError":1.6391277313232422e-7,"pass":true}
```

Nine targeted animation-LOD and soldier-grip checks pass, including the
inside-30-m animation-rate check. An independent Codex auditor passed the six
linked wide, 8 m and 4 m captures from the main control and instrumented native
run. The native kernel and four call sites are identical in the final tree;
only diagnostic timers were removed. Live poses and close-camera placement
differ, so this is a qualitative fidelity check, not a pixel comparison. Stills
cannot prove temporal smoothness; the numerical pose comparison and unchanged
update cadence provide the additional checks.

All eleven steps of the full `pnpm test` pass, as do `pnpm format`, the TypeScript
build and the 504-case fixture on the #2139 baseline. The #2140 rebase also runs
its targeted step-probe checks. The final source manifests assert each runtime
file against the declared frozen reference before launching.

The Windows Playtest export succeeds in one attempt: 2,281,160,676 bytes,
embedded PCK, shader baking enabled, complete D3D12 runtime, and no inspection
bridge, tools or equivalence fixture in the packed paths. The capture lease,
including bounded renewals during shader compilation, remains below ten
continuous minutes. The actual executable's combat log records 375 enemy
footsteps and 81 rifle attacks without script errors. Its SHA-256 is
`e4d8c3bdf016ca36bc92dbeb2fb51b5c89dc48a25675bf8e3af4ddc47fa25370`.
Three primary-inspected captures show ordinary gameplay but do not frame close
enemy grips. This exported combat smoke is separate from the audited grip
comparison and exact-65 development benchmark. It runs with an isolated profile
under its own short capture hold, then stops the owned instance.

ART_STYLE.md, including dated scoped exceptions, was read in full. This change
preserves the approved character and held-gear geometry, colours, materials and
markings. No style conflict was found.
