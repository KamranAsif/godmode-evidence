import assert from 'node:assert/strict';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {readFileSync,writeFileSync,mkdirSync,readdirSync,existsSync,createReadStream} from 'node:fs';
import {createHash} from 'node:crypto';
import path from 'node:path';
const execute=promisify(execFile);
const cli=path.resolve('tools/godot-cli/dist/src/index.js');
const out=path.resolve('artifacts/playtest-enemy-steps');
mkdirSync(out,{recursive:true});
const binary=path.resolve('artifacts/export/enemy-steps/BattleDuty.exe');
const instance=`enemy-playtest-${process.pid}`;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const events=[];
async function call(args){
 const {stdout}=await execute(process.execPath,[cli,...args,'--project',process.cwd(),'--json'],{timeout:240000,maxBuffer:8e6});
 const reply=JSON.parse(stdout);assert.ok(reply.ok,reply.message);return reply.data;
}
async function input(payload){
 const file=path.join(out,'input.json');writeFileSync(file,JSON.stringify(payload));
 const result=await call(['game','window-input','--instance',instance,'--payload-file',file]);
 events.push({at:new Date().toISOString(),input:payload,result});
 await sleep(180);
}
async function consoleLine(text){await input({text});await input({key:13});}
let launch,logFile;
try{
 const inventory=await call(['game','ps','--all']);
 writeFileSync(path.join(out,'inventory.json'),JSON.stringify(inventory,null,2));
 launch=await call(['game','run','--binary',binary,'--instance',instance,'--fixture','roguelite','--offscreen','--offscreen-size','1920x1080']);
 writeFileSync(path.join(out,'launch.json'),JSON.stringify(launch,null,2));
 const logs=path.join(path.dirname(binary),'logs');
 let ready=false;
 for(let n=0;n<180;n++){
  logFile=existsSync(logs)?readdirSync(logs).map(f=>path.join(logs,f)).find(f=>f.endsWith(`-${launch.pid}.log`)):null;
  if(logFile && readFileSync(logFile,'utf8').includes('GODMODE_FIRST_PRESENTED_GAMEPLAY_FRAME=')){ready=true;break;}
  await sleep(1000);
 }
 assert.ok(ready,'export presents a loaded gameplay frame');
 await input({offscreen:true,size:[1920,1080]});
 await input({key:192});
 await consoleLine('stream hold on');
 await consoleLine('invincible on');
 await consoleLine('tp -404 -16.23 -414');
 await consoleLine('killall');
 for(const count of [20,20,20,5]) await consoleLine(`spawn rifleman ${count}`);
 events.push({at:new Date().toISOString(),consoleCapture:await call(['game','capture','--instance',instance,'--os-window','--allow-unchecked','--output',path.join(out,'console.png')])});
 await input({key:192});
 await input({mouseMove:[-900,0]});
 await sleep(22000);
 events.push({at:new Date().toISOString(),capture:await call(['game','capture','--instance',instance,'--os-window','--allow-unchecked','--output',path.join(out,'combat-a.png')])});
 await input({mouseMove:[1800,0]});
 await sleep(2500);
 events.push({at:new Date().toISOString(),capture:await call(['game','capture','--instance',instance,'--os-window','--allow-unchecked','--output',path.join(out,'combat-b.png')])});
 const log=readFileSync(logFile,'utf8');
 assert.ok(!/GODMODE_FRAME_ERROR|SCRIPT ERROR|Parse Error/.test(log),'no script errors in exported combat');
 const redacted=log.replace(/https?:\/\/[^\s]*?(?:token|key|secret)[^\s]*/gi,'[redacted-local-console-url]');
 writeFileSync(path.join(out,'client-redacted.log'),redacted);
 const hash=createHash('sha256');for await(const chunk of createReadStream(binary)) hash.update(chunk);
 writeFileSync(path.join(out,'verification.json'),JSON.stringify({result:'completed; inspect captures for combat and console responses',binary,sha256:hash.digest('hex'),launch,events},null,2));
 console.log('PLAYTEST_CAPTURE_COMPLETE',out);
}finally{
 if(launch) await call(['game','stop','--instance',instance]);
 writeFileSync(path.join(out,'events.json'),JSON.stringify(events,null,2));
}
