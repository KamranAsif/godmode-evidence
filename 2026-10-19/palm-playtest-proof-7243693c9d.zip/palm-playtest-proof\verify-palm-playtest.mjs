import assert from 'node:assert/strict';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {readFileSync,writeFileSync,mkdirSync,readdirSync,existsSync,createReadStream} from 'node:fs';
import {createHash} from 'node:crypto';
import path from 'node:path';
const execute=promisify(execFile),cli=path.resolve('tools/godot-cli/dist/src/index.js');
const out=path.resolve('artifacts/playtest-palm'),binary=path.resolve('artifacts/export/enemy-palms/BattleDuty.exe');
const instance=`enemy-palm-playtest-${process.pid}`,sleep=ms=>new Promise(r=>setTimeout(r,ms));
mkdirSync(out,{recursive:true});
const settings=path.join(out,'settings.cfg');
writeFileSync(settings,'[display]\nfullscreen=false\nresolution_width=1920\nresolution_height=1080\n[audio]\nvolume_percent=0\n[privacy]\nsend_crash_reports=false\n');
writeFileSync(path.join(path.dirname(binary),'override.cfg'),'[application]\nconfig/use_custom_user_dir=true\nconfig/custom_user_dir_name="BattleDuty-enemy-palms-'+process.pid+'"\n');
async function call(args){const {stdout}=await execute(process.execPath,[cli,...args,'--project',process.cwd(),'--json'],{timeout:240000,maxBuffer:4e6});const reply=JSON.parse(stdout);assert.ok(reply.ok,reply.message);return reply.data;}
let launch,logFile;const captures=[];
try{
 writeFileSync(path.join(out,'inventory.json'),JSON.stringify(await call(['game','ps','--all']),null,2));
 launch=await call(['game','run','--binary',binary,'--instance',instance,'--fixture','roguelite','--offscreen','--offscreen-size','1920x1080','--settings-path',settings]);
 writeFileSync(path.join(out,'launch.json'),JSON.stringify(launch,null,2));
 const logs=path.join(path.dirname(binary),'logs');let ready=false;
 for(let n=0;n<210;n++){
  logFile=existsSync(logs)?readdirSync(logs).map(f=>path.join(logs,f)).find(f=>f.endsWith(`-${launch.pid}.log`)):null;
  if(logFile&&readFileSync(logFile,'utf8').includes('GODMODE_FIRST_PRESENTED_GAMEPLAY_FRAME=')){ready=true;break;}
  await sleep(1000);
 }
 assert.ok(ready,'actual exported gameplay loaded');
 const input=path.join(out,'window.json');writeFileSync(input,JSON.stringify({offscreen:true,size:[1920,1080]}));
 await call(['game','window-input','--instance',instance,'--payload-file',input]);
 // No keyboard/mouse input: ordinary shipped spawns exercise the world palm fit.
 for(const [name,delay]of [['combat-a',8000],['combat-b',8000],['combat-c',10000]]){
  await sleep(delay);
  captures.push(await call(['game','capture','--instance',instance,'--os-window','--allow-unchecked','--output',path.join(out,name+'.png')]));
 }
 const client=readFileSync(logFile,'utf8'),engine=readFileSync(launch.logPath,'utf8');
 assert.ok(!/GODMODE_FRAME_ERROR|SCRIPT ERROR|Parse Error/.test(client+'\n'+engine),'no script errors in actual packaged combat');
 const redact=s=>s.replace(/https?:\/\/[^\s"'<>]+/gi,'[redacted-url]').split(/\r?\n/).filter(l=>!/(?:Authorization:|Bearer\s|access_token|refresh_token|api_key|apiKey|secret\s*[:=])/i.test(l)).join('\n');
 writeFileSync(path.join(out,'client-redacted.log'),redact(client));writeFileSync(path.join(out,'engine-redacted.log'),redact(engine));
 const states=client.split(/\r?\n/).filter(l=>l.includes(' STATE '));
 const steps=(client.match(/soldier-step/g)??[]).length,attacks=(client.match(/combat-enemy-rifle/g)??[]).length;
 assert.ok(states.some(l=>/enemies=[1-9]/.test(l))&&steps>0,'active moving enemies in the exported build');
 const hash=createHash('sha256');for await(const chunk of createReadStream(binary))hash.update(chunk);
 const result={result:'captures and log collected; primary agent must inspect before PASS',binary,sha256:hash.digest('hex'),launch,states,steps,attacks,captures,scriptErrors:0,notes:'Actual Windows Playtest executable, normal shipped spawns, capture cap30FPS. Not65-enemy performance evidence; that is measured separately in the verified development scenario.'};
 writeFileSync(path.join(out,'verification.json'),JSON.stringify(result,null,2));console.log('PLAYTEST_PALM_CAPTURE_COMPLETE',out);
}finally{if(launch)await call(['game','stop','--instance',instance]);}
