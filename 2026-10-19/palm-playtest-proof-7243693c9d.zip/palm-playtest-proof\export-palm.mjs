import assert from 'node:assert/strict';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {writeFileSync,mkdirSync} from 'node:fs';
import {packPath,readPackedPaths} from '../tests/export/pack.mjs';
const execute=promisify(execFile),out='artifacts/export/enemy-palms/BattleDuty.exe';
mkdirSync('artifacts/export/enemy-palms',{recursive:true});
const started=new Date().toISOString();
try{
 const {stdout,stderr}=await execute(process.execPath,['tools/godot-cli/dist/src/index.js','game','export','--project','.','--preset','Windows Playtest','--output',out,'--session',process.env.GODMODE_SESSION_ID,'--json'],{timeout:900000,maxBuffer:64e6});
 writeFileSync('artifacts/palm-export-raw.json',stdout);writeFileSync('artifacts/palm-export-stderr.log',stderr);
 const reply=JSON.parse(stdout);assert.ok(reply.ok,reply.message);const r=reply.data;
 assert.equal(r.debug,false);assert.equal(r.shaderBaker,true);assert.ok(r.d3d12Runtime.complete);
 assert.equal(packPath(out),out);const paths=readPackedPaths(out);
 const forbidden=paths.filter(p=>/^(res:\/\/)?tools\//.test(p)||/inspection_bridge|capture_runner|gameplay_capture_driver|study_lightmaps|waterfront_material_validation|enemy_palm_equivalence/.test(p));
 assert.deepEqual(forbidden,[]);
 for(const name of ['prebuilt/survival_client.scn','prebuilt/survival_server.scn','prestige_save','humanoid_aim_native'])assert.ok(paths.some(p=>p.includes(name)),name);
 const receipt={result:'PASS',started,completed:new Date().toISOString(),preset:r.preset,output:r.output,bytes:r.bytes,debug:r.debug,shaderBaker:r.shaderBaker,exportAttempts:r.exportAttempts,d3d12Runtime:r.d3d12Runtime,embeddedPack:true,packedPathCount:paths.length,forbiddenPaths:forbidden};
 writeFileSync('artifacts/palm-export-receipt.json',JSON.stringify(receipt,null,2));console.log('PALM_EXPORT_PASS',JSON.stringify(receipt));
}catch(error){if(error.stdout)writeFileSync('artifacts/palm-export-raw.json',error.stdout);if(error.stderr)writeFileSync('artifacts/palm-export-stderr.log',error.stderr);throw error;}
