import { readFileSync, writeFileSync, existsSync } from 'node:fs';
const report = [];
for (const label of process.argv.slice(2)) {
 const prefix = 'artifacts/enemy-cost/'+label+'/';
 const rows = [];
 for (const name of ['normal-1','normal-2']) {
  if(!existsSync(prefix+name+'-frames-raw.json')) continue;
  const raw = JSON.parse(readFileSync(prefix+name+'-frames-raw.json'));
  const summary = JSON.parse(readFileSync(prefix+name+'-frames.json'));
  const physics = JSON.parse(readFileSync(prefix+name+'-physics.json')).result;
  const state = JSON.parse(readFileSync(prefix+name+'-state.json'));
  const means=Object.fromEntries(Object.entries(raw.profile.totals).map(([key,value])=>[key,value/raw.profile.frames]));
  const sections=Object.fromEntries(Object.entries(physics.sections).map(([key,value])=>[key,value.totalMs/value.calls]));
  const frames = new Map();
  for(const hitch of physics.frameProfile.hitches) for(const frame of hitch.frames)
   if(frame.atMs>=raw.windowStartedMs && frame.atMs<=raw.windowEndedMs) frames.set(frame.frame,frame);
  const systems={};
  for(const frame of frames.values()) for(const [key,value] of Object.entries(frame.systems)) {
   const sum=systems[key]??={ms:0,calls:0}; sum.ms+=value.ms; sum.calls+=value.calls;
  }
  for(const sum of Object.values(systems)){sum.ms/=frames.size;sum.calls/=frames.size;}
  rows.push({name,frames:raw.frames,enemyCount:state.enemyCount,meanMs:summary.meanMs,medianMs:summary.medianMs,p95Ms:summary.p95Ms,p99Ms:summary.p99Ms,fps:summary.fps,means,sections,hitchFrames:frames.size,hitchSystems:systems});
 }
 const samples = rows.flatMap(row=>JSON.parse(readFileSync(prefix+row.name+'-frames-raw.json')).samplesMs).sort((a,b)=>a-b);
 const percentile = p=>samples[Math.max(0,Math.ceil(p*samples.length)-1)];
 const pooled={frames:samples.length,meanMs:samples.reduce((a,b)=>a+b,0)/samples.length,medianMs:percentile(.5),p95Ms:percentile(.95),p99Ms:percentile(.99)};
 report.push({label,pooled,rows});
 console.log(label,JSON.stringify(pooled));
}
writeFileSync('artifacts/enemy-cost-summary.json',JSON.stringify(report,null,2));
