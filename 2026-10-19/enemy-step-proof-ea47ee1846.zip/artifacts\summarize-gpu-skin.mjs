import {readFileSync,writeFileSync} from 'node:fs';
const label=process.argv[2]||'skin-attribution';
const dir='artifacts/enemy-cost/'+label+'/';
const names=label==='skin-attribution'?['normal-1','normal-2','no-skin-1','no-skin-2','restored-skin']:['normal-1','normal-2','no-grain-1','no-grain-2','grain-restored','no-shadow-1','no-shadow-2','shadow-restored'];
const result=[];
for(const name of names){
 const log=readFileSync(dir+name+'-engine.log','utf8');
 const blocks=[];let block;
 for(const line of log.split('\n')){
  const header=line.match(/^GPU PROFILE \(total ([\d.]+)ms\)/);
  if(header){block={totalMs:Number(header[1]),tasks:{}};blocks.push(block);continue;}
  const task=line.match(/^\s+-([^:]+): ([\d.]+)ms/);
  if(task&&block)block.tasks[task[1]]=Number(task[2]);
 }
 const samples=blocks.slice(-8);
 const averages={};
 for(const b of samples)for(const[k,v]of Object.entries(b.tasks))averages[k]=(averages[k]??0)+v/samples.length;
 const frames=JSON.parse(readFileSync(dir+name+'-frames.json'));
 const raw=JSON.parse(readFileSync(dir+name+'-frames-raw.json'));
 const state=JSON.parse(readFileSync(dir+name+'-state.json'));
 const means=Object.fromEntries(Object.entries(raw.profile.totals).map(([k,v])=>[k,v/raw.profile.frames]));
 result.push({name,meanMs:frames.meanMs,p95Ms:frames.p95Ms,caveats:frames.caveats,enemyCount:state.enemyCount,disableSkinning:state.detail.disableSkinning,gpuMs:means.renderGpuMs,cpuMs:means.renderCpuMs,visibleDraws:means.visibleDrawCalls,shadowDraws:means.shadowDrawCalls,blocks:samples.length,gpuStageMeans:averages});
}
writeFileSync('artifacts/'+label+'-summary.json',JSON.stringify(result,null,2));
for(const r of result)console.log(JSON.stringify({...r,gpuStageMeans:Object.fromEntries(Object.entries(r.gpuStageMeans).filter(([k])=>/Cull|Shadow|Depth Pre-Pass|Opaque Pass/.test(k)))}));
