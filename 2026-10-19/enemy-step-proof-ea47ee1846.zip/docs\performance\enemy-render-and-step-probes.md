# Follow-up enemy render attribution

Base main: 624ba6dcf (includes #2131 and #2138; #2139 not yet merged).
Same 65-rifleman seed/grid/camera as PR #2139, full 1920x1080 detail.
Short exclusive timing holds, released between runs. GPU stdout attribution uses
4096 timestamp-query elements. These settings are removed for headline A/B runs.
All enemies stay alive and animationFullRateDistance stays 30 m.

Skinning dispatch is inside the final directional-cull timestamp region in the
pinned native renderer. The last eight one-second GPU task averages show that
region at 0.072-0.074 ms before the diagnostic and 0.090 ms after restoration.
Detaching skeleton RIDs puts it below the profiler's 0.01 ms print threshold.
This is an enclosing region, not an isolated compute timer. Detachment also
removed about 65 visible body submissions and 160 shadow submissions, so the
whole-frame delta cannot be called pure skinning cost. Frame means were
44.47/44.28 ms before, 44.23/46.40 detached, and 47.50 restored; one detached
window has a warmup caveat. No frame improvement was established.

The body has 22,137 skinned vertices, 41 joints, one surface/material and native
indexed LODs (28,000 base triangles; reduced index counts 42,000/21,000/10,968).
Native compute skinning still touches all base vertices. Compact vertex LODs
could reduce that work, but the measured enclosing GPU cost is already small.
The visible world rifle has one material and existing native LODs. The normal
crowd therefore adds roughly two primary surface submissions per visible enemy,
with additional passes for body shadows. No material merge was justified.

Turning the shared body's fabric layer off retains base PBR maps, geometry and
draw counts. Opaque-pass GPU means were 12.07/11.94 ms before, 12.06/11.52 off,
11.77 restored. Whole GPU and CPU load also varied in the second off window;
the first off window shows no isolated gain. The grain sampler already filters
unresolved detail by pixel footprint. No fabric-quality change is shipping.

Held-weapon shadows are already disabled. Body shadows already stop at 30 m.
Disabling all character shadows reduced the GPU shadow stage from 7.55/7.48 ms
to 6.34/6.93 ms; restoration returned it to 7.51 ms. Shadow submissions fell
from about 15,478 to 15,288, with about 40 extra visible blob submissions. This
is the maximum all-character saving in this view, not a distant-only estimate.
The current near-character shadows are retained.

Remaining CPU priorities are hand/weapon fitting (about 6 ms/frame), AI actor
work including movement (about 4-6 ms/frame), and encounter support (about
1.4-1.9 ms/frame). AI movement already runs at 60 Hz within 8 m, 20 Hz through
45 m and 10 Hz beyond that. Reducing movement below snapshot cadence inside
30 m risks gait stutter even with a full-rate animation player. The next
candidate caches only unchanged grounded flat navigation probes between those
scheduled moves, retaining every climb, settling step and movement update.


## Flat-step probe reuse

Encounter support runs at 60 Hz even between scheduled AI movement ticks. The
change reuses a proven flat, grounded no-op while the exact body position,
horizontal velocity and probe direction remain unchanged. The navigation surface
is immutable. A body identity WeakMap avoids keeping dead enemies alive. Every
raised step, missing navigation result, airborne settle and pending route still
runs normally. Movement, snapshots and animation cadence are unchanged.

The same seed (1136293662), fixed 65-rifleman grid, camera, full 1920x1080 detail,
engine and cached arena were used before and after. Arena receipt SHA-256:
`70b12712bc54db1e3cc58927997fa4535fabb7d737bcfcf5d04bfcb77299085b`.
Each run used its own five-minute exclusive timing hold, released after stopping
the renderer. After 15 seconds settling, each of two windows discarded two
seconds of warmup and recorded eight seconds; 65 enemies stayed alive throughout.

| Measurement | Main 624ba6dcf | Flat-step reuse |
| --- | ---: | ---: |
| Step assist, 65 enemies per physics tick | 0.1060 ms | 0.0723 ms |
| Step assist per recorded draw frame | 0.3038 ms | 0.1925 ms |
| Whole frame mean, pooled | 55.124 ms | 49.206 ms |
| Whole frame p95, pooled | 73.700 ms | 75.477 ms |
| Recorded frames | 292 | 327 |

Normalized step-assist CPU fell 31.8%. CPU span counters include the warmup and
inspection interval, so their denominator differs from the frame sample windows.
The whole-frame mean varies substantially between live-fight windows and p95
increased: these numbers do not establish an overall FPS improvement. This is a
small redundant-query saving, roughly 0.11 ms per drawn frame in these runs.
PR #2139 was still pending, so both controls include its animation-cache bug;
these results must not be compared directly with that PR's fixed 41 ms result.

The actual compiled method is tested against an uncached control over 600 ticks
on flat ground, 0.25 m and 0.6 m risers, with turns, airborne settling, blocked
headroom and pending routes. Positions and movement calls match at every tick.
Repeated unchanged flat ticks reduce 240 snaps to two. Separate checks cover
every memo input, missing navigation and retrying previously blocked climbs.
The existing animation test retains 120 Hz updates inside 30 m. The nine targeted
checks and all 11 steps of `pnpm test` passed; `pnpm format` was run.

An independent default-FAIL visual auditor inspected all six play-distance
captures and passed enemy detail, proportions, equipment, poses and shadows.
Close-up cameras differ; still images cannot establish temporal smoothness.
The compiled-method equivalence tests cover movement semantics.
