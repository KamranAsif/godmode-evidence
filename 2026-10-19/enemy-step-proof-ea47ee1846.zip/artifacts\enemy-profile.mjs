import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
const execute = promisify(execFile);
const label = process.argv[2] || 'baseline';
const modes = process.argv.includes('--isolate');
const captures = process.argv.includes('--capture');
const skinProbe = process.argv.includes('--skin-probe');
const materialProbe = process.argv.includes('--material-probe');
const captureEnd = process.argv.includes('--capture-end');
const root = process.cwd();
const out = path.join(root, 'artifacts/enemy-cost', label);
mkdirSync(out, {recursive:true});
const cli = path.join(root,'tools/godot-cli/dist/src/index.js');
const instance = `enemy-${label}-${process.pid}`;
const env = {...process.env, GODMODE_FRAME_PROFILE:'1', GODMODE_GAMEPLAY_BENCHMARK_SEED:String(0x43ba771e)};
const sleep = ms => new Promise(r=>setTimeout(r,ms));
async function call(args) {
 const {stdout} = await execute(process.execPath,[cli,...args,'--project',root,'--json'],{env,timeout:300000,maxBuffer:60e6});
 const reply=JSON.parse(stdout); if(!reply.ok) throw Error(reply.message); return reply.data;
}
async function action(name,payload={}) { return call(['runtime','action','--instance',instance,'--name',name,'--payload',JSON.stringify(payload)]); }
const save=(name,data)=>writeFileSync(path.join(out,name+'.json'),JSON.stringify(data,null,2));
let launched=false;
try {
 const meta = {};
 for(const file of ['assets/maps/dumbo/prebuilt/receipt.json','scripts/presentation.ts','scripts/client/character_detail.ts','scripts/server/encounter_ai.ts']) meta[file]=createHash('sha256').update(readFileSync(file)).digest('hex');
 meta.commit=(await execute('git',['rev-parse','HEAD'])).stdout.trim();
 meta.session=env.GODMODE_SESSION_ID;
 meta.scenario={seed:0x43ba771e,enemies:65,resolution:[1920,1080],from:[-404,-15.58,-414],yaw:Math.PI,fov:75,warmupMs:15000,windowMs:8000};
 save('manifest',meta);
 save('gpu-status',await call(['gpu','status']));
 save('inventory',await call(['game','ps','--all']));
 const settings=path.join(out,'settings.cfg');
 writeFileSync(settings,'[display]\nfullscreen=false\nresolution_width=1920\nresolution_height=1080\nscreen_shake_percent=0\n[audio]\nvolume_percent=100\n[privacy]\nsend_crash_reports=false\n[stream]\nalerts=false\nemotes=false\nhype_train=false\nraids=false\npredictions=false\nclips=false\n');
 const launch=await call(['game','run','--instance',instance,'--fixture','roguelite','--scene','res://scenes/roguelite.tscn','--full','--offscreen','--offscreen-size','1920x1080','--inspect','--allow-actions','--settings-path',settings]);
 launched=true; save('launch',launch); console.log('launched',instance);
 let store;
 for(let i=0;i<180;i++) { try { store=(await call(['runtime','inspect','--instance',instance,'--store-only'])).store; } catch(e) { if(!e.stdout?.includes('bridge is unavailable')) throw e; } if(store?.roguelite?.run && !store.matchLoadingOpen) break; await sleep(500); }
 save('ready',store);
 const playerId=store.localPeerId;
 await action('debug_roguelite_seed',{seed:0x43ba771e});
 await action('debug_console',{invincible:true,open:false});
 await action('debug_survival_command',{playerId,command:'spawns-off'});
 await action('debug_survival_command',{playerId,command:'bench'});
 await action('debug_console',{run:'stream hold on'});
 await action('input',{hold:true,yaw:Math.PI,pitch:0});
 await action('debug_kill_admins');
 await action('debug_set_player_position',{playerId,x:-404,y:-16.23,z:-414});
 await action('debug_look',{playerId,yaw:Math.PI});
 await action('debug_console',{fov:75,freeFly:true,flyTo:[-404,-15.58,-414],lookAt:{yaw:Math.PI,pitch:0}});
 const points=Array.from({length:65},(_,i)=>[-404+(i%5-2)*2.1,-16.23,-414+9+Math.floor(i/5)*1.8]);
 for(let i=0;i<65;i+=24) save('spawn-'+i,await action('debug_spawn_encounter',{rifle:Math.min(24,65-i),fixed:true,points:points.slice(i,i+24)}));
 await sleep(15000);
 save('positions',await action('debug_admin_positions'));
 save('detail',await action('debug_character_detail'));
 async function measure(name) {
  if(/GODMODE_FRAME_ERROR|SCRIPT ERROR|Parse Error/.test(readFileSync(launch.logPath,'utf8'))) throw Error('Runtime script error; measurement invalid');
  const before=await call(['runtime','inspect','--instance',instance,'--store-only']);
  if(before.store.snapshot.systemAdmins.length!==65) throw Error('Expected 65 living enemies before '+name);
  await action('debug_physics_profile',{reset:true});
  const reading=await call(['runtime','frames','--instance',instance,'--window-ms','8000','--warmup-ms','2000','--output',path.join(out,name+'-frames-raw.json')]);
  save(name+'-frames',reading);
  save(name+'-physics',await action('debug_physics_profile',{census:true}));
  const after=await call(['runtime','inspect','--instance',instance,'--store-only']);
  save(name+'-state',{enemyCount:after.store.snapshot.systemAdmins.length,viewerHold:after.store.roguelite.run.survival.performance.viewersHeld,debugFreeFly:after.store.debugFreeFly,detail:(await action('debug_character_detail')).result});
  if(after.store.snapshot.systemAdmins.length!==65) throw Error('Expected 65 living enemies after '+name);
  writeFileSync(path.join(out,name+'-engine.log'),readFileSync(launch.logPath));
  console.log(name,JSON.stringify(reading).slice(0,1400));
 }
 async function captureViews() {
  save('wide-capture',await call(['game','capture','--os-window','--instance',instance,'--output',path.join(out,'wide.png')]));
  await action('debug_console',{frameSoldier:{kind:'rifle',bearingDegrees:0,distance:8,height:1.5,lookHeight:1,fov:75}});
  await sleep(500);
  save('play-distance-capture',await call(['game','capture','--os-window','--instance',instance,'--output',path.join(out,'play-distance.png')]));
  await action('debug_console',{frameSoldier:{kind:'rifle',bearingDegrees:25,distance:4,height:1.5,lookHeight:1.1,fov:75}});
  await sleep(500);
  save('grip-capture',await call(['game','capture','--os-window','--instance',instance,'--output',path.join(out,'grip.png')]));
 }
 if(captures) await captureViews(); else {
  await measure('normal-1'); await measure('normal-2');
  if(skinProbe){
   await action('debug_character_detail',{disableSkinning:true}); await measure('no-skin-1'); await measure('no-skin-2');
   await action('debug_character_detail',{disableSkinning:false}); await measure('restored-skin');
  }
  if(materialProbe){
   await action('debug_character_detail',{bodyGrain:false}); await measure('no-grain-1'); await measure('no-grain-2');
   await action('debug_character_detail',{bodyGrain:true}); await measure('grain-restored');
   await action('debug_character_detail',{shadowDistance:0}); await measure('no-shadow-1'); await measure('no-shadow-2');
   await action('debug_character_detail',{shadowDistance:30}); await measure('shadow-restored');
  }
 }
 if(captureEnd) await captureViews();
 if(modes) {
  await action('debug_character_detail',{freezeAnimations:true}); await measure('frozen');
  await action('debug_character_detail',{freezeAnimations:false,shadowDistance:0}); await measure('no-shadows');
  await action('debug_character_detail',{shadowDistance:30,weaponVisibleRange:1}); await measure('no-weapons');
  await action('debug_character_detail',{shadowDistance:0,soldierVisibleRange:1,weaponVisibleRange:1}); await measure('no-meshes');
 }
 save('final',await call(['runtime','inspect','--instance',instance,'--store-only']));
 writeFileSync(path.join(out,'engine.log'),readFileSync(launch.logPath));
} finally {
 if(launched) console.log(await call(['game','stop','--instance',instance]));
}

